const express = require('express');
const app = express();
const env = require('dotenv');
const cors = require('cors');
const fs = require('fs');
const https = require('https');
const routes = require('./src/routes/index')

env.config();
const bodyParser = require('body-parser');
const path = require("path");
const morgan = require('morgan');
const winston = require('./services/winston');
// const userRoutes = require('./src/users/users.routes');
// const officerRoutes = require('./src/officer/officer.routes');
// const masterDataRoutes = require('./src/masterData/masterData.routes');
// const castRoutes = require('./src/cast/cast.routes');
// const mrCertificateRoutes =require('./src/mrgCertificate/mrCer.routs');

const ContentSecurityPolicy = `
    default-src 'self' 'unsafe-inline' https://marriage.rs.ap.gov.in http://152.70.142.148 http://129.153.120.149;
    script-src 'self' 'unsafe-inline';
    child-src https://marriage.rs.ap.gov.in http://129.153.120.149 http://152.70.142.148;
    style-src 'self' 'unsafe-inline' https://marriage.rs.ap.gov.in http://129.153.120.149 http://152.70.142.148 https://fonts.googleapis.com https://www.gstatic.com;
    font-src 'self' 'unsafe-inline' https://fonts.gstatic.com;
    img-src * 'self' data: http:;
  `

const allowedOrigins = ['https://marriage.rs.ap.gov.in', 'https://117.254.87.83:4000',
    'http://152.70.142.148', 'http://129.153.120.149', 'http://129.153.213.67:8091'];
    
app.use(cors({
    origin: allowedOrigins
}));

app.disable('x-powered-by');
app.disable('etag');

app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (allowedOrigins.includes(origin) ) {
       res.setHeader('Access-Control-Allow-Origin', origin);
    }
    //res.setHeader('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Accept, Authorization, Content-Type, X-Requested-With, Range');
    res.header('Access-Control-Expose-Headers', 'Content-Length');
    res.header('X-XSS-Protection', '1; mode=block');
    res.header('X-Content-Type-Options', 'nosniff');
    res.header('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload');
    res.header('Content-Security-Policy', ContentSecurityPolicy.replace(/\s{2,}/g, ' ').trim());
    res.removeHeader("X-Powered-By");
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    } else {
        return next();
    }
});

app.use(morgan('combined', { stream: winston.stream }));

app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true, parameterLimit: 50000 }));
//app.use(express.static(path.join(__dirname, "public")));
//app.use('/pdfs', express.static(path.join(__dirname, 'pdf')));
app.use("/images", express.static(path.join(__dirname, "images")));
app.use("/assets", express.static(path.join(__dirname, "assets")));

app.use('/hmrService',routes);

// userRoutes.routesConfig(app);
// officerRoutes.routesConfig(app);
// masterDataRoutes.routesConfig(app);
// castRoutes.routesConfig(app);
// mrCertificateRoutes.routesConfig(app);

// Capture all erors
app.use((err,req,res,next) => {
    try{
        let errorJSON = {};
        if(err.statusCode!=undefined)
            errorJSON["statusCode"]=err.statusCode;
        else if(err.status!=undefined)
            errorJSON["statusCode"]=err.status;
        else
            errorJSON["statusCode"]=500;
        
        errorJSON["message"]=err.message;
        errorJSON["type"]=err.type;
        if(err.status===500 || err.statusCode===500)
        {
            errorJSON["status"]="Internal Server Error";
            res.status(500).send(errorJSON);
        }
        else if(err.status===400 || err.statusCode===400)
        {
            errorJSON["status"]="Bad Request";
            res.status(400).send(errorJSON);
        }
        else if(err.status===401 || err.statusCode===401)
        {
            errorJSON["status"]="Unauthorized";
            res.status(401).send(errorJSON);
        }
        else if(err.status===403 || err.statusCode===403)
        {
            errorJSON["status"]="Forbidden";
            res.status(403).send(errorJSON);
        }
        else if(err.status===404 || err.statusCode===404)
        {
            errorJSON["status"]="Not Found";
            res.status(404).send(errorJSON);
        }
        else if(err.status===412 || err.statusCode===412)
        {
            errorJSON["status"]="Precondition Failed";
            res.status(412).send(errorJSON);
        }
    }catch(err){
        winston.error("error in index :::: ", err);
    }
    let completeUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
	winston.error(`${err.status || err.statusCode} - ${res.statusMessage} - ${err.message} - ${completeUrl} - ${req.method} - ${req.ip}`,);
})
/*
const server = https.createServer({
    
 	key:fs.readFileSync('./certificates/localhost_key.pem'),
 	cert:fs.readFileSync('./certificates/localhost.pem')
 },app).listen(process.env.PORT,()=>{
    console.log("deploying mode :: "+process.env.NODE_ENV);
 	console.log('Server is listening at ' + process.env.API_URL +':%s', process.env.PORT); 
 })
*/

app.listen(process.env.PORT, () => { 
    console.log('Server is listening at ' + process.env.API_URL +':%s', process.env.PORT); 
});

