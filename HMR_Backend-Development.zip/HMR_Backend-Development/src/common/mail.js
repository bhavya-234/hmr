const nodemailer = require("nodemailer");
let transporter = nodemailer.createTransport({
    host: "smtp-mail.outlook.com",
    port: 587,
    //secure: false,
    ssl: true,
    auth: {
        user: "support.igrs@criticalriver.com",
        pass: "Rockstar@1234",
    },
});

exports.sentMail = async (data) => {
    try {
        var info = await transporter.sendMail({
            from: '"HMR" <support.igrs@criticalriver.com>', // sender address
            to: data.toMail, // list of receivers
            subject: data.subject, // Subject line
            text: "Hi user, ", // plain text body
            html: `<b>${data.message}</b>`
        });
        var mailInfo = info.messageId;
        console.log("mail sent id",data.toMail);
        return("Mail Send Succesfully");
    } catch (error) {
        console.log('Mail sent failed. Error: ',error)
        throw new Error('Mail sent failed');
    }
    
};

// exports.sentmail = sentmail;

