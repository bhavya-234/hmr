const express = require('express');
const handler = require('./officer.handler');
const userHandler = require('../users/users.handler');
const userController = require('../users/users.controller');
const jwt = require('../services/auth.service');
const officer = require('./officer.controller');
const fileUpload = require('../common/fileUpload');
const router = express.Router();

// exports.routesConfig = (app) => {
//     //app.post('/api/officer/signup', [handler.signUp]);
//     app.post('/api/officer/login', officer.login);
// 	app.put('/api/officer/resetPassword',jwt.verifyOfficerJwt,[handler.reset])
//     app.post('/api/officer/updateSro/:loginId' ,jwt.verifyOfficerJwt,[handler.updateSro])
// }


router.post('/login', officer.login);
router.get('/getsearchList',jwt.verifyOfficerJwt,officer.globalCompletedData)
router.put('/resetPassword',jwt.verifyOfficerJwt,[handler.reset])
router.post('/updateSro/:loginId' ,jwt.verifyOfficerJwt,[handler.updateSro])
router.post('/saveUser',jwt.verifyOfficerJwt, [userHandler.saveUser]);
router.get('/sampleRegistration', jwt.verifyOfficerJwt, [userHandler.sampleRegistration]);
router.get('/userbyAppNo/:id', jwt.verifyOfficerJwt, [userHandler.getUserByAppNo]);
router.get('/certificateRequestsbyAppNo/:id', jwt.verifyOfficerJwt, [userHandler.getCertificateRequestsbyAppNo]);
router.delete('/removeFileUpload/:appNo/:fileName', jwt.verifyOfficerJwt, userController.removeFileUploadByAppNoAndFileName);
router.post('/fileUpload/:registrationId/:fileName',jwt.verifyOfficerJwt, fileUpload.uploadStore.fields([
    { name: 'image' }]), [userHandler.fileUpload]);



 
module.exports = router;