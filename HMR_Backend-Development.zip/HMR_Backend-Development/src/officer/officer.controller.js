const officerModel = require('./model/officer.model');
const jwt = require('../services/auth.service');
const dbHelper = require('../utils/helper');
const sysConstants = require('../utils/sysConstanst');
const registrationModel = require('../users/model/registration.model');
const moment = require('moment');

const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[a-zA-Z\d@$!%*#?&]{8,}$/;

exports.getUser = (data) => {
    try {
        return new Promise(function (resolve, reject) {
            officerModel.find()
                .then(response => resolve(response))
                .catch(err => reject(err));
        });
    } catch (err) {
        console.log("Process Error" + err.message);
    }
};

exports.signUp = (req) => {
    try {
        let reqObj= req.body;
        return new Promise((resolve, reject) => {
            officerModel.find({loginEmail:reqObj.loginEmail})
                .then(response => {
                    if (response.length>0){
                        reject("Email ID already exists.")
                    } else{
                        officerModel.create(reqObj)
                            .then(response => {
                                resolve(response instanceof officerModel);
                            }).catch(err => reject(err));
                    }
                    
                })
                .catch(err => reject(err));
        });
    } catch (err) {
        console.log("Process Error" + err.message);
    }
};

exports.login =async (req,res) => {
	const reqBody = req.body;
	try{
		if(reqBody.loginEmail == null || reqBody.loginPassword == null){
			res.status(404).send({Success:false,message:"Validation error"})
		}
		//block login untill that timestamp
		const findOfficerQuery = { "loginEmail": reqBody.loginEmail };
		const officer = await officerModel.findOne(findOfficerQuery);
		if (officer && officer.loginAttemptsLeft === 0) {
			if (moment().isBefore(moment(officer.loginBlockedUntil))) {
				return res.status(403).send({
				Success: false,
				message: `Login is blocked until ${moment(officer.loginBlockedUntil).format('MMM DD YYYY hh:mm:ss A')}`
				});
			} else {
				officer.loginAttemptsLeft = 5;
				officer.loginBlockedUntil = null;
				await updateUserLoginTrials(findOfficerQuery,5, null);
			}
		}
		else if(officer == null)
			return res.status(404).send({Success:false,message:`Email ID/Password incorrect.`});

		let query = {
			loginEmail : reqBody.loginEmail,loginPassword:reqBody.loginPassword
		}
		var date = new Date();
		var dateStr =
		("00" + date.getDate()).slice(-2) + "-" +
		("00" + (date.getMonth() + 1)).slice(-2) + "-" +
		date.getFullYear() + " " +
		("00" + date.getHours()).slice(-2) + ":" +
		("00" + date.getMinutes()).slice(-2) + ":" +
		("00" + date.getSeconds()).slice(-2);
		let lastLoginUpdate = {lastLogin: dateStr};
		let loginUser = await officerModel.findOne(query);
		if(loginUser==undefined || loginUser == null)
		{
			// Update user login attempts count
			let loginAttemptsLeft = null;
			let loginBlockedUntil = null;
			if(officer.loginAttemptsLeft==undefined)
				officer.loginAttemptsLeft=5;

			if (officer && officer.loginAttemptsLeft > 0 ) {
				loginAttemptsLeft = officer.loginAttemptsLeft - 1;
				if (loginAttemptsLeft === 0) { // Set user blocking time
					loginBlockedUntil = new Date(moment().add('5', 'minutes'));
				}
				updateUserLoginTrials(findOfficerQuery,loginAttemptsLeft, loginBlockedUntil);
				return res.status(404).send({Success:false,message:`Email ID/Password incorrect. ${loginAttemptsLeft > 0 ? `${loginAttemptsLeft} attempts left.` : `Login is blocked for 5 minutes.`}`});
			}
		}
	
		await updateUserLoginTrials(findOfficerQuery,5, null);
		let origin = req.headers['Origin'];
		if(origin == null)
			origin= "";

		let user= {
			userId:loginUser._id,
			loginId:loginUser._id,
			loginType:loginUser.loginType,
			loginName:loginUser.loginName,
			lastLogin : loginUser.lastLogin,
			role:loginUser.role,
			loginEmail:loginUser.loginEmail,
			origin:origin
		}
		await officerModel.updateOne(query, {$set: lastLoginUpdate},{upsert:false, multi:false});
		let tokenUrl = req.protocol + "://" + req.get("host") + "/api/token/"+loginUser._id  
		const token =await jwt.createToken(user,tokenUrl);
		if(loginUser.role==="SRO" || loginUser.role==="VR")
		{
			user.sroDistrict = loginUser.sroDistrict;
			user.sroOffice =loginUser.sroOffice;
			user.sroNumber = loginUser.sroNumber;
			if(loginUser.role==="VR")
			{
				user.villageName=loginUser.villageName;
				user.villageCode=loginUser.villageCode;
				user.villageScretariatCode=loginUser.villageScretariatCode;
				user.villageScretariatName=loginUser.villageScretariatName;
			}
		}
		else{
			user.district = loginUser.district;
			user.subDistrict = loginUser.subDistrict;
		}
		user.token = token;
		return res.status(200).send(
		{
		// success:true,
		// data:user
		status: true,
			message: "",
			code: 200,
			data: user
		})
	}catch(ex){
		console.log(" ex :::: ", ex);
		return res.status(500).send({success: false,message:'Something went wrong. Please try again later.',error: ex.message});
	}
};

const updateUserLoginTrials = async (findOfficerQuery, loginAttemptsLeft, loginBlockedUntil) => {
	await officerModel.findOneAndUpdate(findOfficerQuery,
	{ $set: { loginAttemptsLeft: loginAttemptsLeft, loginBlockedUntil: loginBlockedUntil } }, { upsert: false, multi:false }
	);
}

exports.resetPswrd =async (req)=>{
	try{
		const reqBody = req.body;
		if(reqBody.loginEmail)
		{
			return ({success:false,status:400,message:"Bad request."})
		}

		if(!passwordPattern.test(req.body.newPassword))
            return ({status:false,message:"Password should meet the password policy."});

		let loginUserMailId = req.user.loginEmail;
		const fndQuery ={"loginEmail":loginUserMailId, "loginPassword":reqBody.oldPassword};
		const updateQuery ={"loginPassword":reqBody.newPassword};
		//let oldPassword = reqBody.oldPassword;

		let loginUserData = await officerModel.findOne(fndQuery);
		if(loginUserData!=undefined && loginUserData!=null)
		{
			const data = await dbHelper.fAndUpdateMethod(sysConstants.Col_Officers,fndQuery,updateQuery)
			if(data.value !== null){
				return ({success:true,status:200,message:"Reset password has been updated sucessfully."})
			}else{
				return ({success:false,status:400,message:sysConstants.Error_400})
			}
		}else{
			return ({success:false,status:200,message:"Invalid old password."})
		}
	}catch(ex){
		console.log(" ex ", ex);
		return ({success:false,status:500,message:ex.message})
	}
}


exports.updateSro =async (req)=>{
	try{
		await officerModel.findOneAndUpdate({ _id: req.params.loginId }, { $set: req.body })
        return ({success:true,status:200,message:"Password updated succesfully."})
	}catch(ex){
		return ({success:false,status:500,message:ex.message})
	}
}

exports.globalCompletedData = async(req, res) => {
    try {
        const husbandName = req.query.husbandName;
        const wifeName = req.query.wifeName;
        const documentNumber = req.query.documentNumber;
        let searchQuery = { status:"COMPLETED"}
        if (documentNumber!=undefined && documentNumber!=null && documentNumber.length>0) 
			searchQuery['documentNumber'] = {'$regex': documentNumber, '$options': 'i'} ;
		if (husbandName!=undefined && husbandName!=null && husbandName.length>0) 
			searchQuery['husbandName'] = {'$regex': husbandName, '$options': 'i'} ;
		if (wifeName!=undefined && wifeName!=null && wifeName.length>0) 
			searchQuery['$or'] = [
				{ wifeName_beforeMarriage: {'$regex': wifeName, '$options': 'i'} },
				{ wifeName_afterMarriage: {'$regex': wifeName, '$options': 'i'} }
			];
        
        const results = await registrationModel.find(searchQuery);
        const filteredResults = results.map(result => ({ husbandName: result.husbandName, wifeName_beforeMarriage:result.wifeName_beforeMarriage, wifeName_afterMarriage: result.wifeName_afterMarriage, appNo:result.appNo, updatedAt:moment(result.updatedAt).format('DD-MM-YYYY'), documentNumber:result.documentNumber, status:result.status, regDate:result.regDate,
		assignedTo: (result.villageScretariatName && result.villageScretariatName.trim().length > 0)
		        ? "VSWS-" + result.villageScretariatName
		        : "SRO-" + result.sroOffice
	    }));
        res.status(200).send({status:true,data:filteredResults, message:"Data fetched"})
    } catch (error) {
        console.log("error :::: ", error);
        res.status(500).send({status:false, message:"Internal Server Error."})
    }
}