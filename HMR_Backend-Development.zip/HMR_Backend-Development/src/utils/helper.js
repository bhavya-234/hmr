const mongoose = require("mongoose");
const {ackAndSlotStyles} = require('./pdfStyles/ackAndSlot')

const findOneMethod = async (collectionName, query)=>{
	try{

		const data =await mongoose.connection.db
		.collection(collectionName).
		findOne(query).then((err,fdata)=>{
			if(err){
				throw err
			}
			return fdata
		})
		return data;
	}catch(ex){
		return ex;
	}
}

const fAndUpdateMethod = async (clName,identify,query)=>{
	try{
	const data =await mongoose.connection.db
		.collection(clName).findOneAndUpdate(identify,{$set:query}).then((err,fData)=>{
			if(err){
				throw err;
			}
			return fData;
		})
		return data;
	}catch(ex){
		return ex;
	}
}

const generateReport = async (data,type)=>{
	try {
		
		let [year,month,date] = data.slotDate.split("-");
		let slotDate =`${date}/${month}/${year}`;
		if(type == 'acknowledgement'){
			ackAndSlotStyles.watermark.text ="HINDU MARRIAGE"
			let ackTable ={
				widths:[450],
				body:[
					[	{	
							columns:[
								{
									text:"Application Number  ",fontSize:12,bold:true,alignment:'right',margin:[20,10,-50,0]
								},
								{
									text:" : ",alignment:"center",margin:[0,10,0,0]
								},
								{text:`  ${data.appNo}`,fontSize:12,alignment:'left',margin:[-50,10,0,0]}
							]
							
						}
						// {text:"Application ID:",fontSize:13,bold:true,alignment:'right',margin:[0,10,0,0]},{text:`${data.applicationId}`,fontSize:12,alignment:'left',margin:[0,10,0,0]}
					],
					[
						{
							columns:[
								{
									text:"Wife Name  ",fontSize:12,bold:true,alignment:'right',margin:[20,10,-50,0]
								},
								{
									text:" : ",alignment:"center",margin:[0,10,0,0]
								},
								{text:`  ${data.wifeName_beforeMarriage}`,fontSize:12,alignment:'left',margin:[-50,10,0,0]}
							]
						}
					],
					[
						{
							columns:[
								{
									text:"Husband Name  ",fontSize:12,bold:true,alignment:'right',margin:[20,10,-50,0]
								},
								{
									text:" : ",alignment:"center",margin:[0,10,0,0]
								},
								{text:`  ${data.husbandName}`,fontSize:12,alignment:'left',margin:[-50,10,0,0]}
							]
						}
					],
					
				]
			}

			let registrarNameBody;
			if(data.villageScretariatName!==null && 
				data.villageScretariatName!=undefined && 
				data.villageScretariatName!="")
			{
				
				registrarNameBody = [
					{
						columns:[
							{
								text:"VSWS Office  ",fontSize:12,bold:true,alignment:'right',margin:[20,10,-50,0]
							},
							{
								text:" : ",alignment:"center",margin:[0,10,0,0]
							},
							{text:`  ${data.villageScretariatName}`,fontSize:12,alignment:'left',margin:[-50,10,0,0]}
						]
					}
				]
			}
			else
			{
				registrarNameBody = [
					{
						columns:[
							{
								text:"Sub Registrar Office  ",fontSize:12,bold:true,alignment:'right',margin:[20,10,-50,0]
							},
							{
								text:" : ",alignment:"center",margin:[0,10,0,0]
							},
							{text:`  ${data.sroOffice}`,fontSize:12,alignment:'left',margin:[-50,10,0,0]}
						]
					}
				]
			}
			
			ackTable.body.push(registrarNameBody);
			let slotDataBody = [
				{
					columns:[
						{
							text:"Slot Date & Time  ",fontSize:12,bold:true,alignment:'right',margin:[20,10,-50,0]
						},
						{
							text:" : ",alignment:"center",margin:[0,10,0,0]
						},
						{text:`  ${slotDate}, ${data.slotTime}`,fontSize:12,alignment:'left',margin:[-50,10,0,0]}
					]
				}
			]
			ackTable.body.push(slotDataBody);

			ackAndSlotStyles.content.map((ac)=>{
				if(ac.style ==="table1")
					ac.table = ackTable;
			})
			return ackAndSlotStyles;
		}
	} catch (error) {
		console.log(" error ::: ",  error)
		throw error;
	}
}


module.exports = { 
  fAndUpdateMethod,findOneMethod,generateReport
};
