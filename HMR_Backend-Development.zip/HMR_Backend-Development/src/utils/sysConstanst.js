module.exports = {
	Col_Officers : 'officers',
	Col_users :    'registrations',
	Error_400:"Something Went Wrong",
	Col_OTP:"otp",
	Col_user_table:'users'
	
};