 let stylingDocs = {
	background:  ()=> {
		return [
			{
				canvas: [
					// { type: 'line', x1: 20, y1: 20, x2: 575, y2: 20, lineWidth: 0.7 }, //Up line
					// { type: 'line', x1: 20, y1: 20, x2: 20, y2: 820, lineWidth: 0.7 }, //Left line
					// { type: 'line', x1: 20, y1: 820, x2: 575, y2: 820, lineWidth: 0.7 }, //Bottom line
					// { type: 'line', x1: 575, y1: 20, x2: 575, y2: 820, lineWidth: 0.7 }, //Rigth line

					// { type: 'line', x1: 23, y1: 23, x2: 572, y2: 23, lineWidth: 0.4 },
					// { type: 'line', x1: 23, y1: 23, x2: 23, y2: 817, lineWidth: 0.4 },
					// { type: 'line', x1: 23, y1: 817, x2: 572, y2: 817, lineWidth: 0.4 },
					// { type: 'line', x1: 572, y1: 23, x2: 572, y2: 817, lineWidth: 0.4 }

					{type: 'rect',x: 9,y: 9,w: 580,h: 827,r: 4,lineColor: 'black'},
					{type: 'rect',x: 12,y: 12,w: 574,h: 821,r: 2,lineColor: 'grey'}
				],

			}
		]
	},
	pageOrientation: 'landscape',
	content: [
		{
			
			
			text: `NOTICE OF INTENDED MARRIAGE`, style:'p1Header',
				// { text: `Date`, style:'dist'},
				// { text: `Time`, style:`tblText`},
				// { text: `Date`, style:'table'},
				// { text: `Time`, style:`postTbale`},
				// { text: `Date`, style:'last text'},
						
		},
		{ text: `THE SECOND SECHDULE`+'\n'+`(SEE SECTION 5)`, style:`p1sideHeaders`},
		{ text: `To,`+'\n'+`THE MARRIAGE OFFICER`, style:`p1Adress`},
		{
			columns:[
				{text:"FOR THE",style:'p1Name'},
				{text:"DISTRICT",style:'p1Dist'}
			]
		},
		{text:`We hereby give you notice that a marriage under the Special marriage ACT, 1954 is intended to be solemnized between us within three calendar months from the data hereof.`,style:'p1Text'},
		{
			style: 'tableExample',
			heights: 20,
			widths: [100, '*', 200, '*'],
			table: {
				
				body: [
					['NAME', 'CONDITION', 'OCCUPATION', 'AGE','DWELLING PLACE', 'PERMANENT DWELLING','LENGTH OF RESIDENT'],
					['1', '2', '3','4','5','6','7'],
					['1', '2', '3','4','5','6','7'],
					['1', '2', '3','4','5','6','7'],
					['1', '2', '3','4','5','6','7'],
					['1', '2', '3','4','5','6','7'],
					['1', '2', '3','4','5','6','7']
				]
			}

		},
		{
			columns:[
				{text:"Witness our hands this",style:'p1PostTable1'},
				{text:`20          There is no prohibited relationship between us..`,style:'p1PostTable2'}
			]
		},
		{
			
			columns:[
				{text:"BRIDEGROOM",style:'bdSign'},
				{text:`BRIDE`,style:'bSign'},
				{text:`MARRIAGE OFFICER`,style:'ofcerSign'}
			]
				
			
		},
		{
			text: 'FORM - || (Rule 7 (1)',
			style:'p2Header',
			pageBreak: 'before',
			pageOrientation: 'portrait',
			
		},
		{
			text: 'APPLICATION FOR REGISTRATION OF A MARRIAGE UNDER SECTION 16 OF THE'+'\n'+'SPECIAL MARRIAGE ACT, 1954(CENTRAL ACT,XLIII/1954)',
			style:'p2SubHeader'
			
		},
		{
			columns:[
				{
					text: '1. Name of Parties',
					style:'p2NameKey'
				},
				{
					text: ':',
					style:'p2NameCenter'
				},
				{
					text: '                       (Husband)',
					style:'p2NameValue'
				}
			]

			
		},
		{	
			columns:[
				{
					text: '2. Age of Date of Birth',
					style:'p2AgeKey'
				},
				{
					text: ':',
					style:'p2AgeCenter'
				},
				{
					text: '                       (Husband)'+'\n'+'\n'+'                       (Wife)',
					style:'p2AgeValue'
				}

			]
		},
		{
			columns:[
				{
					text: '3. Permanent Dwelling place, If any',
					style:'p2PAdress1Key'
				},
				{
					text: ':',
					style:'p2PAdress1Center'
				},
				{
					text: '',
					style:'p2PAdress1Value'
				}

			]

			
		},
		{
			columns:[
				{
					text: '4. Present Dwelling place, If any',
					style:'p2PAdress2Key'
				},
				{
					text: ':',
					style:'p2PAdress2Center'
				},
				{
					text: '',
					style:'p2PAdress2Value'
				}

			]

			
		},
		{
			columns:[
				{
					text: '5. Relationship, If any of Parties before marriage.',
					style:'p2PRelationKey'
				},
				{
					text: ':',
					style:'p2PRelationCenter'
				},
				{
					text: '',
					style:'p2PRelationValue'
				}

			]
			
		},
		{
			columns:[
				{
					text: '5. A Ceremony of marriage was performed between'+'\n'+'__________________________________________________ and _________________________________________________on'+'\n'+'\n'+'__________________________________________________ at _________________________________________________and'+'\n'+'we declare that we have been living together as husband and wife over/since the date noted above.',
					style:'p2text1'
				}

			]

		},
		{
			text:'WE HEREBY DECLARE THAT :',style:"p2SubHeader2"
		},
		{
			text:
			'i)       Neither of us has more than one spouse living on the date mentioned in this application;'+'\n'+'\n'+
			'ii)      Neither of us in an idiot or lunatic;'+'\n'+'\n'+
			'iii)     Both of us have completed the age of twenty-one years on the date of this application;'+'\n'+'\n'+
			'iv)      We are not within the degrees of a prohibited relationship.',
			style:"p2Points"
		},
		{
			text:
			'          Our Marriage was celebrated before the commencement of the Special Marriage Act, of 1954',
			style:"p2PointFour1"
		},
		{
			text:
			'(Central Act XLIII of 1954) and according to the law, custom or usage having the force of law, governing us,'+'\n'+
			'marriage  between us is  permitted through we are within the degree of  prohibited each  relationship'+'\n'+
			'according to the Act aforesaid.'+'\n'+'\n'+
			'Note:  Score out whichever is not applicable.',
			style:"p2PointFour2"
		},
		{
			text:
			'v)        We have been residing within the jurisdiction of the marriage officer'+'\n'+
			'         ____________________________________________________'+'\n'+
			'         for a period of not less than thirty days immediately preceding the date of the application.'+'\n'+
			'         We also declare that all the above particulars are true to the best of our knowledge and belief.',
			style:"p2PointFive"
		},

		{
			columns:[
				{
					text:
					'Station :',
					style:"p2Station1"
				},
				{
					text:'(Husband)    Signature:',
					style:"p2Station2"
				}
			]

		},
		{
			columns:[
				{
					text:
					'Date :',
					style:"p2Date1"
				},
				{
					text:'(Wife)    Signature:',
					style:"p2Date2"
				}
			]

		}
	],
	
	styles: {
		p1Header: {
			
			alignment: 'center',
			fontSize: 12,
			fontFamily:'segoe UI, Helvetica Neue, Helvetica, Arial, sans-serif;',
    		bold: true,
			decoration:'underline',
			margin: [-20, -20, 0, 20]
		},
		p1sideHeaders: {
			
			alignment: 'center',
			fontSize: 10,
			margin: [-20, -20, 0, 20]
			
		},
		p1Adress:{
			alignment: 'left',
			fontSize: 9,
			margin: [10, 20, 0, 20]
		},
		p1Name: {
			fontSize: 9,
			alignment:'left',
			margin: [200, 20, 0, 20]
		},
		p1Dist: {
			fontSize: 9,
			alignment:'right',
			margin: [10, 20, 200, 20]
		},
		tableExample:{
			margin: [30, 10, 0, 0]
		},
		p1Text:{
			fontSize:10,
			alignment:'left',
			margin: [10, -2, 20, 0]
		},
		p1PostTable1:{
			fontSize: 9,
			alignment:'left',
			margin: [10, 20, 0, 20]

		},
		p1PostTable2: {
			fontSize: 9,
			alignment:'right',
			margin: [10, 20, 150, 20]
		},
		bdSign:{
			fontSize: 9,
			alignment:'left',
			margin: [10, 20, 0, 20]

		},
		bSign: {
			fontSize: 9,
			alignment:'center',
			margin: [10, 20, 0, 20]
		},
		ofcerSign: {
			fontSize: 9,
			alignment:'right',
			margin: [10, 20, 30, 20]
		},
		p2Header:{
			alignment: 'center',
			fontSize: 12,
    		bold: true,
			margin: [-20, 0, 0, 20]

		},
		p2SubHeader:{
			alignment: 'center',
			fontSize: 12,
    		bold: true,
			decoration:'underline',
			margin: [-20, -20, 0, 20]
		},
		p2NameKey:{
			alignment: 'left',
			fontSize: 10,
			margin: [10, 0, 0, 5]
		},
		p2NameCenter:{
			alignment: 'center',
			fontSize: 10,
			margin: [10, 0, 0, 5]
		},
		p2NameValue:{
			fontSize: 9,
			alignment:'right',
			margin: [10, 0, 30, 5]
		},
		p2AgeKey:{
			alignment: 'left',
			fontSize: 10,
			margin: [10, 5, 0, 5]
		},
		p2AgeCenter:{
			alignment: 'center',
			fontSize: 10,
			margin: [10, 0, 0, 5]
		},
		p2AgeValue:{
			fontSize: 9,
			alignment:'right',
			margin: [10, 0, 30, 5]
		},
		p2PAdress1Key:{
			alignment: 'left',
			fontSize: 10,
			margin: [10, 5, 0, 5]
		},
		p2PAdress1Center:{
			alignment: 'center',
			fontSize: 10,
			margin: [10, 0, 0, 5]
		},
		p2PAdress1Value:{
			fontSize: 9,
			alignment:'right',
			margin: [10, 0, 30, 5]
		},
		p2PAdress2Key:{
			alignment: 'left',
			fontSize: 10,
			margin:[10, 5, 0, 5]
		},
		p2PAdress2Center:{
			alignment: 'center',
			fontSize: 10,
			margin: [10, 0, 0, 5]
		},
		p2PAdress2Value:{
			fontSize: 9,
			alignment:'right',
			margin: [10, 0, 30, 5]
		},
		p2PRelationKey:{
			alignment: 'left',
			fontSize: 10,
			margin: [10, 5, 0, 5]
		},
		p2PRelationCenter:{
			alignment: 'center',
			fontSize: 10,
			margin: [10, 0, 0, 5]
		},
		p2PRelationValue:{
			fontSize: 9,
			alignment:'right',
			margin: [10, 0, 30, 5]
		},
		p2text1:{
			fontSize:10,
			alignment:'left',
			margin: [10, -2, 20, 0]
		},
		p2SubHeader2:{
			alignment: 'left',
			fontSize: 10,
    		bold: true,
			margin: [10, 15, 20, 0]
		},
		p2Points:{
			fontSize:10,
			alignment:'left',
			margin: [10, 10, 20, 0]
		},
		p2PointFour1:{
			fontSize:10,
			alignment:'left',
			margin: [100, 10, 20, 0]
		},
		p2PointFour2:{
			fontSize:10,
			alignment:'left',
			margin: [10, 0, 20, 0]
		},
		p2PointFive:{
			fontSize:10,
			alignment:'left',
			margin: [10, 10, 20, 0]
		},
		p2Station1:{
			fontSize:10,
			alignment:'left',
			margin: [10, 20, 20, 0]
		},
		p2Station2:{
			fontSize:10,
			alignment:'right',
			margin: [10, 20, 20, 0]
		},
		p2Date1:{
			fontSize:10,
			alignment:'left',
			margin: [10, 10, 20, 0]
		},
		p2Date2:{
			fontSize:10,
			alignment:'right',
			margin: [10, 10, 20, 0]
		},
	}

}

let brideAndGroomDocs = {
	background:  ()=> {
		return [
			{
				canvas: [
					{type: 'rect',x: 9,y: 9,w: 580,h: 827,r: 4,lineColor: 'black'},
					{type: 'rect',x: 12,y: 12,w: 574,h: 821,r: 2,lineColor: 'grey'}
				],

			}
		]
	},
	content: [
		{
			text: `DECLARATION TO BE MADE BY THE BRIDEGROOM`,
			 style:'p1Header',
			pageOrientation: 'portrait',
			
		},
		{ text: `THE THIRD SECHDULE`+'\n'+`(SEE SECTION - II)`, style:`p1sideHeaders`},
		{
			text:`I, _________________________________________________________ S/O___________________________________________`+'\n'+
			'hereby declare as follows :',style:'p1Text'
		},
		{
			text:
			'1.       I am at the presesnt time unmarried/widower/diverse as the case may be.         '+'\n'+'\n'+
			'2.      I have completed _______________________ years of age.'+'\n'+'\n'+
			'3.      I am not related to ________________________________________________________________ (the bride) within'+'\n',
			style:"p1Points"
		},
		{
			text:
			'the degrees of prohibited relationship.'+'\n',
			style:"p1Points1"
		},
		{
			text:
			'4.      I am aware that If any statement in this declaration is false and if in making such statement I either ',
			style:"p1Points2"
		},
		{
			text:
			'know or belive it to be false or do not belive it to be true.'+'\n'+'\n'+'I am liable to imprisonment also to be fine.',
			style:"p1Points1"
		},
		{
			text:
			'BRIDEGROOM',
			style:"sign"
		},

		{
			text: `DECLARATION TO BE MADE BY THE BRIDE`,
			style:'p1Header',
			
		},
		{
			text:`I, _________________________________________________________ D/O___________________________________________`+'\n'+
			'hereby declare as follows :',style:'p1Text'
		},
		{
			text:
			'1.       I am at the presesnt time unmarried/widower/diverse as the case may be.         '+'\n'+'\n'+
			'2.      I have completed _______________________ years of age.'+'\n'+'\n'+
			'3.      I am not related to ___________________________________________________(the bridegroom) within'+'\n',
			style:"p1Points"
		},
		{
			text:
			'the degrees of prohibited relationship.'+'\n',
			style:"p1Points1"
		},
		{
			text:
			'4.      I am aware that If any statement in this declaration is false and if in making such statement I either ',
			style:"p1Points2"
		},
		{
			text:
			'know or belive it to be false or do not belive it to be true.'+'\n'+'\n'+'I am liable to imprisonment also to be fine.',
			style:"p1Points1"
		},
		{
			text:
			'BRIDE      ',
			style:"signBride"
		},
		{
			text:
			'Signed in our presence by the above named.',
			style:"p1Points"
		},
		{
			columns:[
				{
					text:
					'',
					style:"p1PointsStart"
				},
				{
					text:'and',
					style:"p1PointsCenter"
				}
			]

		},
		{
			columns:[
				{
					text:
					'',
					style:"p1PointsStart"
				},
				{
					text:'so far as we aware there is no lawful impediment to the marriage.',
					style:"p2Pointsright"
				}
			]

		},
		{
			text:'WITNESSES',
			style:"witness"
		},
		{
			columns:[
				{
					text:
					'1.',
					style:"witness1"
				},
				{
					text:'COUNTER SIGNED',
					style:"signed"
				}
			]

		},
		{
			columns:[
				{
					text:
					'2.',
					style:"witness1"
				},
				{
					text:'',
					style:"signed"
				}
			]
		},
		{
			columns:[
				{
					text:
					'3.',
					style:"witness1"
				},
				{
					text:'Dated the               20',
					style:"signed"
				}
			]
		},
		{
			text:'MARRIAGE OFFICER',
			style:"ofcrSign"
		},
	],
	
	styles: {
		p1Header: {
			
			alignment: 'center',
			fontSize: 12,
			fontFamily:'segoe UI, Helvetica Neue, Helvetica, Arial, sans-serif;',
    		bold: true,
			decoration:'underline',
			margin: [-20, 10, 0, 20]
		},
		p1sideHeaders: {
			
			alignment: 'center',
			fontSize: 10,
			margin: [-20, -20, 0, 20]
			
		},
		p1Text:{
			fontSize:10,
			alignment:'left',
			margin: [10, -2, 20, 0]
		},
		p1Points:{
			fontSize:10,
			alignment:'left',
			margin: [10, 10, 20, 0]
		},
		p1Points1:{
			fontSize:10,
			alignment:'left',
			margin: [32, 0, 20, 0]
		},
		p1Points2:{
			fontSize:10,
			alignment:'left',
			margin: [10, 10, 20, 0]
		},
		p2PointFour1:{
			fontSize:10,
			alignment:'left',
			margin: [100, 10, 20, 0]
		},
		p2PointFour2:{
			fontSize:10,
			alignment:'left',
			margin: [10, 0, 20, 0]
		},
		p2PointFive:{
			fontSize:10,
			alignment:'left',
			margin: [10, 10, 20, 0]
		},
		
		p2Station1:{
			fontSize:10,
			alignment:'left',
			margin: [10, 20, 20, 0]
		},
		p2Station2:{
			fontSize:10,
			alignment:'right',
			margin: [10, 20, 20, 0]
		},
		p2Date1:{
			fontSize:10,
			alignment:'left',
			margin: [10, 10, 20, 0]
		},
		p2Date2:{
			fontSize:10,
			alignment:'right',
			margin: [10, 10, 20, 0]
		},
		sign:{
			fontSize:10,
			bold:true,
			alignment:'right',
			margin: [10, 30, 40, 0]
		},
		signBride:{
			fontSize:10,
			bold:true,
			alignment:'right',
			margin: [10, 30, 70, 0]
		},
		p1PointsStart:{
			fontSize:10,
			alignment:'left',
			margin: [10, 10, 20, 0]
		},
		p1PointsCenter:{
			fontSize:10,
			alignment:'center',
			margin: [0, 20, 180, 0]
		},
		p2Pointsright:{
			fontSize:10,
			alignment:'left',
			margin: [-40, 10, 0, 0]
		},
		witness:{
			alignment: 'left',
			fontSize: 10,
			fontFamily:'segoe UI, Helvetica Neue, Helvetica, Arial, sans-serif;',
    		bold: true,
			decoration:'underline',
			margin: [10, 5, 0, 20]
		},
		witness1:{
			alignment: 'left',
			fontSize: 10,
			margin: [10, 5, 0, 2]
		},
		signed:{
			alignment: 'right',
			fontSize: 10,
			margin: [0, 5, 30, 2]
		},
		ofcrSign:{
			alignment: 'right',
			fontSize: 10,
			margin: [0, 5, 25, 2]
		}
	}

}


module.exports ={stylingDocs,brideAndGroomDocs}