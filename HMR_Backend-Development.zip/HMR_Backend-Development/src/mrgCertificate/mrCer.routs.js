const express = require('express')
const handler = require('./mrCer.handler');
const jwt = require('../services/auth.service');
const mrCer = require('../mrgCertificate/mrgCertificate.controller');
const router = express.Router();

// exports.routesConfig = (app) => {
//     app.get('/api/pdf/:sroNumber/:id',jwt.verifyOfficerJwt, [handler.getPdf]);
// 	app.get('/api/downloadDocument/:docType/:appNo',jwt.verifyUserjwt, mrCer.downloadDocument);
// 	app.get('/api/officerDownloadDocument/:docType/:appNo',jwt.verifyOfficerJwt, mrCer.downloadDocument);
// 	// app.get('/api/splMrg/:type',mrCer.splMrgPdf);
// 	app.put('/api/printACK/:type/:appNo',jwt.verifyUserjwt,mrCer.ackAndSlot);
// }


router.get('/pdf/:sroNumber/:id',jwt.verifyOfficerJwt, [handler.getPdf]);
router.get('/downloadDocument/:docType/:appNo',jwt.verifyUserjwt, mrCer.downloadDocument);
router.get('/officerDownloadDocument/:docType/:appNo',jwt.verifyOfficerJwt, mrCer.downloadDocument);
// app.get('/api/splMrg/:type',mrCer.splMrgPdf);
router.put('/printACK/:type/:appNo',jwt.verifyUserjwt,mrCer.ackAndSlot);

module.exports = router;