const PDFDocument = require('pdfkit');
const fs = require('fs');
const Path = require('path');
//const User = require('../users/model/registration.model');
const helper = require('../utils/helper');
const pdfMake = require('pdfmake')
const {stylingDocs,brideAndGroomDocs} = require('../utils/splMrg');
const sysConstanst = require('../utils/sysConstanst');
const {generateReport} =require('../utils/helper');
const moment = require('moment');
const sequenceModel = require('../users/model/sequenc.model');
const registrationModel = require('../users/model/registration.model');
const officerModel = require('../officer/model/officer.model');
const certificateRequestModel = require('../sso/model/certificateRequest.model')
const ObjectId = require('mongoose').Types.ObjectId;
var Mutex = require('async-mutex').Mutex;

const mutex = new Mutex();
const delay = ms => new Promise(res => setTimeout(res, ms));
//let sroNumberList = [];

exports.makePdf =async (req,res) => {
	let doc;
	let seqNumberVal;
	try{
		let userLoginData = req.user;
		const reqParams = req.params;
		const reqQuery = req.query;
		const Userdata = await registrationModel.find({ _id: reqParams.id });
		if(Userdata.length === 0){
			return({status:400,Success:false,message:"registration data not found."})
		}

		let documentsArray = Userdata[0].documents;
		if(documentsArray!=undefined && documentsArray != null && documentsArray.length > 5)
		{
			console.log("Inside IF Block");
			let requiredDocs = ["doc_husbandBirthProof", "doc_wifeBirthProof", "doc_marriagePhoto",
								"doc_wifeResidenceProof", "doc_weddingCard", "doc_husbandResidenceProof"];
			let imageExist = false;
			let imagePathNotExist = false;
			let isValidImage = true;
			documentsArray.map((d)=>{
				const [name,rest]=d.fileName.split(".");
				const index = requiredDocs.indexOf(name);
				if (index > -1) {
					requiredDocs.splice(index, 1);
				}
				if(name === 'doc_marriagePhoto'){
					console.log("d.filePath ::::::::::::::::::::::::::", d.filePath);
					imagePathNotExist = true;
					const path = Path.join(__dirname, '../../' +d.filePath);
					if (fs.existsSync(path)) {
						imageExist = true;
						//Test doc is to verify the whether marriage photo is valid or not.
						let testDoc = new PDFDocument({ size: 'A4',autoFirstPage: true });
						try{
							testDoc.image(path);
						}catch(error)
						{
							console.log(" error :::: ", error);
							isValidImage = false;
						}
						testDoc.end();
						testDoc = null;
					}
				}	
			});
			
			if(requiredDocs.length!=0)
				return({status:403,Success:false,message:"Mandatory documents are missing."});
			if(!imagePathNotExist)
				return({status:403,Success:false,message:"Marriage photo is required to generate the certificate."});
			if(!imageExist)
				return({status:403,Success:false,message:"Marriage photo not found in the system. Please reupload it."});
			if(!isValidImage)
				return({status:403,Success:false,message:"Marriage photo is not a valid format. Please reupload it."});
		}else
		{
			console.log("Inside else Block");
			return({status:403,Success:false,message:"Mandatory documents are missing."});
		}
			
	
		let data = await helper.findOneMethod(sysConstanst.Col_Officers, { _id: ObjectId(userLoginData.userId)});
		if(data==null)
			data = await officerModel.findOne({ _id: ObjectId(userLoginData.userId)});

		if(data==null)
		{
			return({status:500,Success:false,message:"Something went wrong. Please try again after sometime."});
		}
				
		let sroNumberVal;
		let sroSequenCeQuery = { }
		Userdata[0].loginName =data.loginName;
		if(data.role==="SRO")
		{
			sroNumberVal = parseInt(reqParams.sroNumber);
			sroSequenCeQuery["sroNumber"] = sroNumberVal;
			Userdata[0].sroLoginName = data.sroOffice;
		}
		else{
			//sroNumberVal = data.villageScretariatCode;
			//sroSequenCeQuery["vswsNumber"] = sroNumberVal;
			sroNumberVal = parseInt(reqParams.sroNumber);
			sroSequenCeQuery["sroNumber"] = sroNumberVal;
			Userdata[0].sroLoginName = data.villageScretariatName;
			
		}		
		const [local, rest] = req.get("host").split(":");
		const isCertificateGenerated = Userdata[0].cert_form;

		
		let SRNO;

		let release = await mutex.acquire();
		try{
			SRNO = await synchronousExecutionBlock(sroSequenCeQuery, data, isCertificateGenerated, sroNumberVal);
			seqNumberVal = parseInt(SRNO.sequence)+1;
		}finally{
			if(release!=undefined)
				release();
		}
		
		console.log(" after update seqNumberVal ::: ", seqNumberVal);
		let documentNumber;
		if(!isCertificateGenerated){
			if(sroNumberVal==7777)
				Userdata[0].seqNumber = `HM/SRTTD/${seqNumberVal}` ;
			else
				Userdata[0].seqNumber = `HM/SR${SRNO.sroNumber}/${seqNumberVal}` ;
			/*
			if(data.role==="SRO")
			{
				if(sroNumberVal==7777)
					Userdata[0].seqNumber = `HM/SRTTD/${seqNumberVal}` ;
				else
					Userdata[0].seqNumber = `HM/SR${SRNO.sroNumber}/${seqNumberVal}` ;
			}
			else
				Userdata[0].seqNumber = `HM/VSWS${SRNO.vswsNumber}/${seqNumberVal}` ;
			*/
			documentNumber = Userdata[0].seqNumber;
			
			let d= new Date();
			Userdata[0].currDate= d.getDate().toString().padStart(2, "0")+"/"+(d.getMonth()+1).toString().padStart(2, "0")+"/"+d.getFullYear();
		}

		if(documentNumber!=undefined)
		{
			let Url =
			local === "localhost"
			? req.protocol + "://" + req.get("host") + "/pdfs"
			: "http://" + req.get("host") + "/pdfs";
			const path = Path.join(__dirname, "../../" + "pdf");
			if (!fs.existsSync(path)) {
				fs.mkdirSync(path);
			}
			
			// const doc = new PDFDocument({size: 'A4'});
			doc = new PDFDocument({ size: 'A4',autoFirstPage: false });
			const fileNameValue = "Cer_" + reqParams.id
		
			doc.pipe(fs.createWriteStream(`${path}/${fileNameValue}.pdf`));
			await writeContent(doc,Userdata,reqQuery.q, documentNumber);
			doc.end();
			await delay(300);
			doc = null;
		
			let update = await registrationModel.findOneAndUpdate({_id: reqParams.id},{$set:{documentNumber:documentNumber, cert_form:true,cert_url: `${Url}/${fileNameValue}.pdf`}});
			const bitmap = fs.readFileSync(`${path}/${fileNameValue}.pdf`);
			let convertBase64 = bitmap.toString('base64');
				
			return ({status:200, Success:true, Url:`${Url}/${fileNameValue}.pdf`, 
					dataBase64:convertBase64, fileName:fileNameValue+'.pdf', 
					documentNumber:documentNumber});
		}
		else
		{
			console.log("Document number is not generated due to server side issue.");
			return({status:500,Success:false,message:"Something went wrong. Please try again after sometime."});
		}
		
	}catch(ex){
		if(doc != undefined && doc != null)
			doc.end();
		console.log(" error in pdf generate ::: ", ex);
		if(ex.message!=undefined && ex.message!=null)
			return({status:500,Success:false,message:ex.message});
		else
			return({status:500,Success:false,message:"Something went wrong. Please try again after sometime."});
	}
}

async function synchronousExecutionBlock(sroSequenCeQuery, data, isCertificateGenerated, sroNumberVal)
{
	try {
		//console.log("sroSequenCeQuery :::: ", sroSequenCeQuery);
		let SRNO = await sequenceModel.findOne(sroSequenCeQuery);
		if(SRNO==null)
		{
			SRNO = {};
			SRNO.sroDistrict = data.sroDistrict;
			SRNO.sroName = data.loginName;
			SRNO.sequence = 0;

			SRNO.sroOffice = data.sroOffice;
			SRNO.sroNumber = sroNumberVal;
			/*
			if(data.role==="SRO")
			{
				SRNO.sroOffice = data.sroOffice;
				SRNO.sroNumber = sroNumberVal;
			}
			else
			{
				SRNO.vswsName = data.sroOffice;
				SRNO.vswsNumber = sroNumberVal;
			}
			*/
			let sroSequenceData = new sequenceModel(SRNO);
			await sroSequenceData.save();
		}

		console.log(" seqNumberVal ::: ", SRNO.sequence);
		let seqNumberVal = parseInt(SRNO.sequence)+1;
		console.log(" after increment seqNumberVal ::: ", seqNumberVal);
		if(!isCertificateGenerated)
			await sequenceModel.findOneAndUpdate(sroSequenCeQuery,{$set:{sequence:seqNumberVal}})

		return SRNO;
	}catch(error)
	{
		console.log("Error occurred while updating sequence ::: ", error);
		throw error;
	}
}

async function writeContent(doc,UserData,query, documentNumber){
	try {
		console.log("Inside of writeContent ::: ");
		query = query || "";
		if(query == ""){
			doc.addPage({
				size: 'LEGAL',
				layout: 'landscape'
			});
			await pdfFirstPage(doc, UserData, documentNumber);
			await pdfSecondPage(doc, UserData, documentNumber);
			await createMarriageCertificate(UserData, doc, "", documentNumber);
		}else{
			doc.addPage({
				size: 'LEGAL',
				layout: 'portrait'
			});
			createMarriageCertificate(UserData,doc,query, documentNumber);
		}
	} catch (error) {
		console.log("Error occurred inside of writeContent ::: ", error);
		throw error;
	}
	console.log("End of writeContent ::: ");
}

async function pdfFirstPage(pdfkit, user, documentNumber)
{	
	console.log("Inside of pdfFirstPage ::: ");
	try {
		let regDate = moment(user[0].regDate,["MM-DD-YYYY", "YYYY-MM-DD"]).format('DD/MM/YYYY');
		let mrgDate = moment(user[0].marriageDate,["MM-DD-YYYY", "YYYY-MM-DD"]).format('DD/MM/YYYY');
		//left, top, right, bottom
		// doc.rect(20, 20, width-38, height-38).lineWidth(1).stroke();
		// doc.rect(24, 24, width-46, height-46).lineWidth(3).stroke();
		// doc.rect(28, 28, width-54, height-54).lineWidth(1).stroke();
		const husData = await caluculateLength(user[0].husbandName,'name');
		const wifeData = await caluculateLength(user[0].wifeName_beforeMarriage,'name');
		const husAddress = await caluculateLength(user[0].husbandAddress,'address');
		const husFathrName = await caluculateLength(user[0].husbandFatherName,'name');
		const husMotherName = await caluculateLength(user[0].husbandMotherName,'name');
		const wifeFathrName = await caluculateLength(user[0].wifeFatherName,'name');
		const wifeMotherName = await caluculateLength(user[0].wifeMotherName,'name');
		const husCaste = await caluculateLength(user[0].husbandReligion,'address');
		const wifeAddress = await caluculateLength(user[0].wifeAddress,'address');
		// consr marriageAddress = await caluculateLength(user[0].marriageAddress,)
		let heightCal1 ;
		let heightCal2 ;
		heightCal1 = husData.height >= husAddress.height ? husData.height : husAddress.height;
		heightCal2 = wifeData.height >= wifeAddress.height ? wifeData.height : wifeAddress.height;

		const d = new Date();
		const hmnAnddateText = 'H.M.No.: '+ (documentNumber) +' of '+ (d.getFullYear())
		
		const height = parseFloat(pdfkit.page.height);
		const width = parseFloat(pdfkit.page.width);
		const sNo = 'Sl.No';
		const name ='Full Name'
		pdfkit.font('Times-Roman').fontSize(18).fillColor('black').text('FORM - H', 20, 30, {align: 'center' });
		pdfkit.font('Times-Roman').fontSize(12).fillColor('black').text(hmnAnddateText, 20, 30, {align: 'right' });


		pdfkit.font('Times-Roman').fontSize(18).fillColor('black').text('THE HINDU MARRIAGE REGISTER', 20, 50, {align: 'center' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('SEE RULE 4(1)', 30, 70, {align: 'center' });
		pdfkit.font('Times-Roman').fontSize(18).fillColor('black').text('__________________________________________________________________________________________________', 47, 69);
		pdfkit.font('Times-Bold').fontSize(10).fillColor('#000000').text(`${sNo}`, 47, 90, {align: 'left' }).text('Full Name'+'\n'+'of Parties', 100, 90).text('Religion &'+'\n'+'Caste of the Party', 190, 90).text('Age at the time of'+'\n'+ 'Solemnization'+'\n'+'of the Marriage', 300, 90).text('Rank of'+'\n'+'Profession', 400, 90).text('Permanent Place of'+'\n'+'Residence(at the time of)'+'\n'+'Solemnization of Marriage', 500, 90).text('Date of'+'\n'+'Birth', 700, 90).text('Place with the Names of'+'\n'+'Tq. & Dist. at which the'+'\n'+' Marriage was Solemnized', 770, 90,{align:'justify'})

		// .text('Full name of parties', 30, 80).text('Religion &'+'/n'+'Cast of the party', 50, 80).text('Marriage Registrar', 70, 80);
		pdfkit.font('Times-Roman').fontSize(18).fillColor('black').text('__________________________________________________________________________________________________', 47, 110);
		pdfkit.font('Times-Bold').fontSize(10).fillColor('#000000').text(`1`, 57, 128, {align: 'left' }).text('2', 110, 128).text('2A', 220, 128).text('3', 320, 128).text('4', 420, 128).text('5', 530, 128).text('6', 720, 128).text('7', 820, 128)
		pdfkit.font('Times-Roman').fontSize(18).fillColor('black').text('__________________________________________________________________________________________________', 47, 125);
		let prvsHight = 150;
		pdfkit.font('Times-Bold').fontSize(9).fillColor('black').text(`1`, 57, prvsHight, {align: 'left' }).text(`${husData.data}`, 100, prvsHight).text(`${husCaste.data}`+','+`${user[0].husbandCaste}`, 190, prvsHight).text(`${user[0].husbandMarriageAge}`, 315, prvsHight).text(`${user[0].husbandRankorProfession}`,400, prvsHight).text(`${husAddress.data}`, 510, prvsHight).text(moment(`${user[0].husbandDateofBirth}`,["MM-DD-YYYY", "YYYY-MM-DD"]).format("DD/MM/YYYY"), 700, prvsHight).text(`${user[0].marriageAddress}`, 780, prvsHight)
		
		let heights = prvsHight + heightCal1;

		pdfkit.font('Times-Bold').fontSize(9).fillColor('black').text(`2`, 57, heights, {align: 'left' }).text(`${wifeData.data}`, 100, heights).text(`${user[0].wifeReligion}`+','+`${user[0].wifeCaste}`, 190, heights).text(`${user[0].wifeMarriageAge}`, 315, heights).text(`${user[0].wifeRankorProfession}`,400, heights).text(`${wifeAddress.data}`, 510, heights).text(moment(`${user[0].wifeDateofBirth}`,["MM-DD-YYYY", "YYYY-MM-DD"]).format('DD/MM/YYYY'), 700, heights).text(`${user[0].marriageAddress}`, 780, heights);
		heights = heights +heightCal2;
		
		pdfkit.font('Times-Roman').fontSize(18).fillColor('black').text('__________________________________________________________________________________________________', 47, heights-10);
		heights = heights;
		pdfkit.font('Times-Bold').fontSize(10).fillColor('#000000').text('Date of Solemnization'+'\n'+'of Marriage', 47, heights+8,{align:"justify"}).text('                    Name in full of                 ', 200, heights+8, {underline:true }).text('Information to be Furnished incase of Divorced', 450, heights+8).text('Remarks', 780, heights+8)

		heights = heights + 15
		pdfkit.font('Times-Bold').fontSize(10).fillColor('#000000').text('  Father                                   Mother', 200, heights+8, {align: 'left' }).text('         Persons who may marry again(see Sec.15)         ', 450, heights,{underline:true});
		heights = heights + 15
		pdfkit.font('Times-Bold').fontSize(10).fillColor('#000000').text('Date of Decree'+'\n'+'in the Court',430,heights).text('Whether the period of one year has elapsed'+'\n'+'from the date noted in col.(11) to the date of'+'\n'+'the application(See Provision to Sec.15)',520,heights,{align:'justify'})
		heights = heights +20;

		pdfkit.font('Times-Roman').fontSize(18).fillColor('black').text('__________________________________________________________________________________________________', 47, heights);
		heights = heights + 20;
		pdfkit.font('Times-Bold').fontSize(10).fillColor('#000000').text(`8`,55, heights, {align: 'left' }).text('9', 210, heights).text('10', 330, heights).text('11', 450, heights).text('12', 580, heights).text('13', 800, heights);
		heights= heights -5;
		pdfkit.font('Times-Roman').fontSize(18).fillColor('black').text('__________________________________________________________________________________________________', 47, heights);
		heights = heights+20;
		if(user[0].remarks){
			pdfkit.font('Times-Bold').fontSize(9).fillColor('black').text(`${mrgDate}`, 55, heights).text(`${husFathrName.data}`, 190, heights).text(`${husMotherName.data}`, 320, heights).text(``, 520, 360).text('', 660, heights).text(`${user[0].remarks}`, 790, heights);

			heights= heights+30;

			pdfkit.font('Times-Bold').fontSize(9).fillColor('black').text(`${mrgDate}`, 55, heights).text(`${wifeFathrName.data}`, 190, heights).text(`${wifeMotherName.data}`, 320, heights).text(``, 520, heights).text('', 660, heights).text(`${user[0].remarks}`, 790, heights)
		}else{
			
			pdfkit.font('Times-Bold').fontSize(9).fillColor('black').text(`${mrgDate}`, 55, heights).text(`${husFathrName.data}`, 190, heights).text(`${husMotherName.data}`, 320, heights).text(``, 520, heights).text('', 660, heights).text(``, 790, heights);

			heights= heights+30;
			
			pdfkit.font('Times-Bold').fontSize(9).fillColor('black').text(`${mrgDate}`, 55, heights).text(`${wifeFathrName.data}`, 190, heights).text(`${wifeMotherName.data}`, 320, heights).text(``, 520, heights).text('', 660, heights).text(``, 790, heights)
		}
		heights= heights+10;
		pdfkit.font('Times-Roman').fontSize(18).fillColor('black').text('__________________________________________________________________________________________________', 47, heights);

		pdfkit.font('Times-Bold').fontSize(14).fillColor('#000000').text(`1st Page No.of Corrections:`, 25, 520, {align: 'center' })
		pdfkit.addPage({
			size: 'LEGAL',
			layout: 'landscape'
		});
	} catch (error) {
		console.log("Error occurred inside of pdfFirstPage ::: ", error);
		throw error;
	}
	console.log("End of pdfFirstPage ::: ");
}

async function caluculateLength(data,type){
	data = type === 'name'  ?  data.split(" "): data.split(",");
	let fData ={} ;
	fData.data='';
	fData.height =data.length * 13;
	for(let i in data){
		if(type === 'name'){
			fData.data = fData.data === '' ? data[i]  : fData.data +'\n'+data[i];
		}
		else if(type === 'address'){
			const index = i/2
			if(index === 0){
				fData.data = fData.data === '' ? data[i]  : fData.data +data[i];
			}else{
				fData.data = fData.data === '' ? data[i]  : fData.data +',\n'+data[i];
			}
		}	
	}
	return fData;
}

async function pdfSecondPage(pdfkit, user, documentNumber){
	console.log("Inside of pdfSecondPage ::: ");
	try {
		let regDate = moment(user[0].regDate,["DD-MM-YYYY", "YYYY-MM-DD"]).format('DD/MM/YYYY');
		let mrgDate = moment(user[0].marriageDate,["MM-DD-YYYY", "YYYY-MM-DD"]).format('DD/MM/YYYY');
		let contettext = `We here by declare that the particulars mentioned above are correct and the best of our knowledge and belief,that our marriage is on Hindu Marriage Act. 1955(Central Act. XXV of 1955) applies and that we have fulfilled the condition laid in section 5 or 15 Wherever necessary.` 
		const d = new Date();
		const hmnAnddateText = `H.M.No.: ${documentNumber} of ${d.getFullYear()}`
		pdfkit.font('Times-Roman').fontSize(12).fillColor('black').text(hmnAnddateText, 10, 30, {align: 'right' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text(contettext, 20, 60, {align: 'left' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('HUSBAND', 100, 150, {align: 'right' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('SIGNATURE', 400, 180, {align: 'right' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('WIFE', 200, 210, {align: 'right' });

		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('SIGNATURE OF THREE WITNESSES WITH ADDRESSES:', 20, 230, {align: 'left' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('1.', 20, 250, {align: 'left' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('2.', 20, 280, {align: 'left' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('3.', 20, 310, {align: 'left' });
		let [day,rest] = user[0].currDate.split('/');
		//let month = new Date(user[0].regDate).toLocaleString('default', { month: 'long' });
		let year = new Date().getFullYear();
		var monthNames = ["January", "February", "March", "April", "May","June","July", "August", "September", "October", "November","December"];
		let dummyMonth = new Date()
		let month = monthNames[dummyMonth.getMonth()];
		day = await ordinal_suffix_of(day);
		let content2 = 'The marriage between the above parties this '+' ' +day+ ' '+'day of'+' '+month+' '+year+","+'marriage has been registered under that Hindu marriage Act. 1955(central Act. XXV to 1955 as No.'+'    '+user[0].seqNumber+' of '+year+')'
		
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text(content2, 20, 340, {align: 'left' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('2nd Page Corrections:', 50, 380, {align: 'center' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('Total Corrections:', 50, 400, {align: 'center' });
		if(user[0].villageScretariatCode)
			pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('VSWS:'+`${user[0].villageScretariatName}`+'\n'+'Dated:'+`${user[0].currDate}`, 20, 450, {align: 'left' });
		else
			pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('S.R.O:'+`${user[0].sroOffice}`+'\n'+'Dated:'+`${user[0].currDate}`, 20, 450, {align: 'left' });
		pdfkit.font('Times-Roman').fontSize(14).fillColor('black').text('SIGNATURE OF THE REGISTRAR', 0, 450, {align: 'right' });
		pdfkit.addPage();
	} catch (error) {
		console.log("Error occurred inside of pdfSecondPage ::: ", err);
		throw error;
	}
	console.log("End of pdfSecondPage ::: ");
}

async function ordinal_suffix_of(i) {
    var j = i % 10,
        k = i % 100;
    if (j == 1 && k != 11) {
        return i + "st";
    }
    if (j == 2 && k != 12) {
        return i + "nd";
    }
    if (j == 3 && k != 13) {
        return i + "rd";
    }
    return i + "th";
}

async function createMarriageCertificate(user, doc, query, documentNumber)
{	
	console.log("Inside of createMarriageCertificate ::: ");
	try {
		let couplePic;
		user[0].documents.map((d)=>{
			const [name,rest]=d.fileName.split(".");
			if(name === 'doc_marriagePhoto'){
				const path = Path.join(__dirname, '../../' +d.filePath);
				if (fs.existsSync(path)) {
					couplePic =path;
					return false;
				}
			}	
		})
		let regDate = moment(user[0].regDate,["DD-MM-YYYY", "YYYY-MM-DD","DD-MM-YYYY"]).format('DD/MM/YYYY');
		let mrgDate = moment(user[0].marriageDate,["DD-MM-YYYY", "YYYY-MM-DD"]).format('DD/MM/YYYY');
		// const doc = new PDFDocument({size: 'A4'});
		const d = new Date();
		let currDate = 'Date: '+d.getDate()+"/"+(d.getMonth()+1)+"/"+d.getFullYear();

		// Saving the pdf file in root directory.
		// doc.pipe(fs.createWriteStream('example.pdf'));

		const width = parseFloat(doc.page.width);
		const height = parseFloat(doc.page.height);

		//left, top, right, bottom
		doc.rect(20, 20, width-38, height-38).lineWidth(1).stroke();
		doc.rect(24, 24, width-46, height-46).lineWidth(3).stroke();
		doc.rect(28, 28, width-54, height-54).lineWidth(1).stroke();
		
		// Adding an image in the pdf.
		doc.image('ap_logo.jpg', (width/2)-40, 40, { fit: [90, 90], align: 'center', valign: 'center'}).stroke();

		doc.font('Times-Roman').fontSize(35).fillColor('#27AE60').text('Certificate of Marriage', 60, 160, {align: 'center' });

		doc.font('Times-Bold').fontSize(14).fillColor('#000000').text('(UNDER THE HINDU MARRIAGE ACT, 1955)', 60, 195, {align: 'center' });
		doc.font('Times-Bold').fontSize(14).fillColor('#000000').text('(ACT NO. XXV OF 1955)', 60, 215, { align: 'center' });

		let hmnAnddateText = 'H.M.No.: ' +documentNumber+' of '+d.getFullYear();

		doc.font('Times-Bold').fontSize(14).fillColor('#000000').text(hmnAnddateText, 60, 255, { underline: true, align: 'center' });

		let currD = user[0].currDate;
		let marriageAddress = user[0].marriageAddress.split(",").join(", ");
		let contentText = `        I, `+user[0].loginName.toUpperCase()+' Marriage Registrar, hereby certify that '+user[0].husbandName.toUpperCase()+' and '+user[0].wifeName_beforeMarriage+' (BEFORE MARRIAGE) '+user[0].wifeName_afterMarriage+' (AFTER MARRIAGE) appeared before me on this '+currD+' and that each of them, in my presence and in the presence of three witnesses has declared that a ceremony of marriage has been performed between them on '+mrgDate+' at '+marriageAddress+' and that in accordance with their desire to have their marriage registered under Hindu Marriage Act, the said marriage has, this '+user[0].currDate+' Registered';

		doc.font('Times-Roman').fontSize(14).fillColor('#000000').text('',40,300).text(contentText, 40, 300, { lineGap: 4 ,align:'justify'});

		
		if(couplePic !== undefined){
			console.log(" couplePic path :::: ", couplePic);
			doc.image(couplePic, 42, 517, { fit: [227, 138], align: 'center', valign: 'center'}).rect(42, 517, 227, 138).stroke();
		}
		// if(wifePhoto != undefined){
		// 	doc.image(wifePhoto, 169, 520, { fit: [120, 140], align: 'center', valign: 'center'}).stroke();
		// }
		if(couplePic === undefined ){
			doc.font('Times-Roman').fontSize(14).fillColor('#000000').text("Paste Your Picture Here", 100, 570, { lineGap: 4 });
		}
		
		if(query == "docs"){
			doc.font('Times-Bold').fontSize(14).fillColor('#000000').text('No of Corrections:', 40, height-320, {align: 'left' });
		}else{
			doc.font('Times-Bold').fontSize(14).fillColor('#000000').text('No of Corrections:', 40, height-150, {align: 'left' });
		}

		doc.font('Times-Bold').fontSize(14).fillColor('#000000').text('Marriage Registrar', 400, 685, {align: 'right' });
		// doc.rect(400, 700, 140, 50,{align:'right'}).fill('#d7ffcb');
		// doc.image('tick.png', 460, 705, { fit: [50, 50], align: 'right', valign: 'right'}).stroke()
		// doc.image('digi.png', 485, 735, { fit: [50, 50], align: 'right', valign: 'right'}).stroke()
		
		// doc.image('tick.png', 40, 675, { fit: [20, 20], align: 'right', valign: 'right'}).stroke().image('digi.png', 40, 675, { fit: [20, 20], align: 'right', valign: 'right'}).stroke().text(`Sudhakar`+'\n'+'(Deputy Inspector Genaral)', 40, 675, {align: 'right' })
		let stationName;
		let registrarName;
		if(user[0].villageScretariatCode)
		{
			stationName = `Station: ${user[0].villageScretariatName}`;
			registrarName = `VSWS, ${user[0].sroLoginName}`;
		}
		else
		{
			stationName = `Station: ${user[0].sroOffice}`;
			registrarName = `Sub Registrar, ${user[0].sroLoginName}` ;
		}
		doc.font('Times-Bold').fontSize(10).fillColor('#000000').text(registrarName, 0, 705, {align: 'right' });
		// doc.font('Times-Bold').fontSize(10).fillColor('#000000').text(`(Deputy Inspector General)`, 50, 715, {align: 'right' });
		if(query == "docs"){
			//let stationName = `Station: ${user[0].sroOffice}`;
			doc.font('Times-Bold').fontSize(14).fillColor('#000000').text(stationName, 40, height-300, {align: 'left' })

			//let currDate = 'Date: '+d.getDate()+"/"+(d.getMonth()+1)+"/"+d.getFullYear();
			doc.font('Times-Bold').fontSize(14).fillColor('#000000').text(`Dated: ${user[0].currDate}`, 40, height-285, {align: 'left' });
		}else{
			//let stationName = `Station: ${user[0].sroOffice}`;
			doc.font('Times-Bold').fontSize(14).fillColor('#000000').text(stationName, 40, height-130, {align: 'left' })
		
			//let currDate = 'Date: '+d.getDate()+"/"+(d.getMonth()+1)+"/"+d.getFullYear();
			doc.font('Times-Bold').fontSize(14).fillColor('#000000').text(`Dated: ${user[0].currDate}`, 40, height-115, {align: 'left' });
		}
		// Finalize PDF file
		// doc.end();
	} catch (error) {
		console.log("Error occurred inside of createMarriageCertificate ::: ");
		throw error;
	}
	console.log("End of createMarriageCertificate ::: ");
}


exports.downloadDocument = async (req,res)=>{
	try{
		const reqParams = req.params;
		let docType = reqParams.docType;
		let appNoVal = reqParams.appNo;
		const userDataArray = await registrationModel.find({ appNo: appNoVal});

		let userData = userDataArray[0];
		if(docType === 'doc_docForm' )
		{
			if(userData.cert_form === true)
			{
				let docFormPdf = "Cer_" + userData._id+".pdf";
				
				const path = Path.join(__dirname, "../../" + "pdf/"+docFormPdf);
				const bitmap = fs.readFileSync(path);
				let convertBase64 =  bitmap.toString('base64');
				return res.status(200).send({
					Success:true,
					dataBase64:convertBase64,
					fileName: docFormPdf
				});
			}
			else
				return res.status(200).send({
					Success:false,
					message:"File not found in server."
				});
		}
		else
		{
			let documentsArray = userData.documents;
			var docPath;
			var docFileName;
			let userLoginData = req.user;
			for(var i=0;i<documentsArray.length;i++)
			{
				let document = documentsArray[i];
				if(docType === document.fileName)
				{
					docPath = document.filePath;
					let docPathArray = docPath.split(".");
					docFileName = document.fileName+"."+docPathArray[docPathArray.length-1];
					break;
				}
			}
			if(docPath!=undefined)
			{
				const path = Path.join(__dirname, "../../" + docPath);
				const bitmap = fs.readFileSync(path);
				let convertBase64 = bitmap.toString('base64');
				if(userLoginData.loginType.toUpperCase() === "SSO" && docType === "doc_final_regForm")
				{
					let findQuery = {createdBy: userLoginData.userId, appNumber:appNoVal,status:"COMPLETED"};
					await certificateRequestModel.findOneAndUpdate(findQuery, {$set:{status : "PROCESSED"}});
				}
				return res.status(200).send({
					Success:true,
					dataBase64:convertBase64,
					fileName: docFileName
				});
			}
			else
				return res.status(200).send({
					Success:false,
					message:"File not found in server."
				});
		}
	}catch(ex){
		console.log(" error ", ex);
		return res.status(500).send({
			Success:false,
			message:'Something went wrong. Please try again after sometime.'
		})
	}
}


exports.ackAndSlot = async (req,res)=>{
	try{
		const reqParams = req.params;
		var fonts = {
			Roboto: {
			  normal:
				"node_modules/roboto-font/fonts/Roboto/roboto-regular-webfont.ttf",
			  bold: "node_modules/roboto-font/fonts/Roboto/roboto-bold-webfont.ttf",
			  italics:
				"node_modules/roboto-font/fonts/Roboto/roboto-italic-webfont.ttf",
			  bolditalics:
				"node_modules/roboto-font/fonts/Roboto/roboto-bolditalic-webfont.ttf",
			}
		};
		const [local, rest] = req.get("host").split(":");
		let Url =
		  local === "localhost"
			? req.protocol + "://" + req.get("host") + "/pdfs"
			: "http://" + req.get("host") + "/pdfs";

		const path = Path.join(__dirname, "../../" + "pdf/");
		let sampleObj= await  registrationModel.findOne({"appNo":reqParams.appNo});
		//(" reqParams :::: ", reqParams);
		const finalReport = await generateReport(sampleObj,reqParams.type)
		//  pdfMaker(sampleObj,reqParams.type);
		let pdf = new pdfMake(fonts);
		let pdfDoc = pdf.createPdfKitDocument(finalReport,{});
		const fileName = reqParams.appNo+"_" + reqParams.type
		const filePath = `${path}${fileName}.pdf`;
		pdfDoc.pipe(fs.createWriteStream(filePath));
		
		pdfDoc.end();
		await delay(300);
		console.log(" filePath ::: ", filePath);
		const bitmap = fs.readFileSync(filePath);
		let convertBase64 = bitmap.toString('base64');

		try{
			fs.unlinkSync(filePath);
		}
		catch(err)
		{
			console.log("Error ::: ", ex);
		}
		return res.status(200).send({
			Success:true,
			Url: `${Url}/${fileName}.pdf`,
			dataBase64:convertBase64, 
			fileName:`${fileName}.pdf`
		})
	}catch(ex){
		console.log("Error ::: ", ex);
		return res.status(500).send({
			Success:false,
			message:'Something went wrong. Please try again after sometime.'
		})
	}
}
