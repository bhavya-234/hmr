const service = require('./mrgCertificate.controller');
const { Handler,reqHandler } = require('../common/requestHandler');

//FORMAT:  exports.<action>=(req,res)=>Handler(req,res,service.<function>,<successMessage>,<failMessage>);
exports.getPdf = (req, res) => reqHandler(req, res, service.makePdf);
