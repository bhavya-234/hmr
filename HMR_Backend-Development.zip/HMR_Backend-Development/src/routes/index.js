const express = require('express');
const router = express.Router();

const users = require('../users/users.routes');
const officer = require('../officer/officer.routes');
const mrgCertificate = require('../mrgCertificate/mrCer.routs');
const masterData = require('../masterData/masterData.routes');
const cast = require('../cast/cast.routes');
const payment = require('../paymentModule/payment.routes');
const ssoRoutes = require('../sso/ssoUser.routes');


router.use('/api/users',users);
router.use('/api/officer',officer);
router.use('/api/mrgCertificate',mrgCertificate);
router.use('/api/masterData',masterData);
router.use('/api/cast',cast);
router.use('/api/payment',payment);
router.use('/api/sso',ssoRoutes);

module.exports = router;



