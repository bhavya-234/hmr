const moment = require('moment');
const request = require("request");
const paymentReceiptsModel = require('../paymentModule/model/paymentReceipts.Model');
const officerModel = require('../officer/model/officer.model');
const registrationModel = require('../users/model/registration.model');
const certificateRequestModel = require('../sso/model/certificateRequest.model')
const { ObjectId } = require('mongodb');

exports.verifyTransactionStatus = async (req, res) => {
    try {
        let paymentFrom = req.body.type;
        let deptTransID = req.body.deptTransID;
        const verifiedTranscation = await paymentReceiptsModel.findOne({ departmentTransID: deptTransID });
        if (verifiedTranscation != null && verifiedTranscation.isUtilized) {
            return res.status(500).send({ status: false, message: "Department transaction ID is already used for " + (verifiedTranscation.applicationNumber) + ". Please try with a valid department transaction ID." });
        }
        let loginUser = req.user;
 		let officerData = await officerModel.findOne({ _id: ObjectId(loginUser.userId)});
 		let sroNumber = officerData.sroNumber;

        let regModel;
        if(paymentFrom === "certRequest"){
            regModel = await certificateRequestModel.findOne({ appNumber: verifiedTranscation.applicationNumber, sroNumber: parseInt(sroNumber) });
        }else{
            regModel = await registrationModel.findOne({ appNo: verifiedTranscation.applicationNumber, sroNumber: parseInt(sroNumber) });
        }
        if (regModel == null || regModel == undefined) {
            return res.status(500).send({ status: false, message: "Payment is not done for SRO - " + (officerData.sroOffice) + ". Please reinitiate the payment with valid selections or try with a valid department transaction ID." });
        }

        let encodeDeptId = Buffer.from(deptTransID).toString('base64');
        let reqData = { deptTransactionID: encodeDeptId };
        let requestOptions = {
            uri: process.env.CFMS_URL + "verifyCfmsTransactionByDepartmentID",
            method: 'POST',
            json: true,
            contentType: "application/json",
            body: reqData,
            rejectUnauthorized: false,
            requestCert: false,
            agent: false
        };
        const { data } = request.post(requestOptions, (err, response, body) => {
            if (err) {
                console.log(" error :: ", err);
                return res.status(400).send({ status: false, message: "Something went wrong" });
            }
            if (body.status === "Success") {
                let Obj = {
                    amount: body.data.totalAmount,
                    paymentMode: body.data.paymentMode,
                    cfmsTransID: body.data.cfmsTransactionId,
                    departmentTransID: body.data.departmentTransactionId,
                    transactionStatus: body.data.status
                };
                return res.status(200).send({ status: true, message: "Transaction details are verified successfully.", data: Obj });
            } else {
                return res.status(body.statusCode).send({ status: false, message: body.message });
            }
        });
    } catch (error) {
        console.log(" error : ", error);
        return res.status(500).send({ status: false, message: "Internal server error." });
    }
};

exports.defaceTransaction = async (req, res) => {
	try {
		const deptTransID = req.params.deptTransID;
		const verifiedTranscation = await paymentReceiptsModel.findOne({ departmentTransID: deptTransID});		
		if (verifiedTranscation) {
			if(!verifiedTranscation.isUtilized)
				await paymentReceiptsModel.findOneAndUpdate({ departmentTransID: deptTransID }, {$set:{isUtilized:true}});
			else
				return res.status(500).send({ status: false, message: "Department transaction ID is already used for "+(verifiedTranscation.applicationNumber)+". Please try with valid department transaction ID." })
		}
		let encodeDeptId = Buffer.from(deptTransID).toString('base64');
		let reqData = { deptTransactionID: encodeDeptId };
		
		let requestOptions = {
			uri: process.env.CFMS_URL+"defaceCfmsTransactionByDepartmentID",
			method: 'POST',
			json: true,
			contentType: "application/json",
			body: reqData,
			rejectUnauthorized: false,
			requestCert: false,
			agent: false
		}
		//console.log("requestOptions :::: ", requestOptions);
		const { data } = request.post(requestOptions, (err, response, body) => {
			if (err) {
				return res.status(400).send({ status: false, message: "Something went wrong" })
			}

			if (body.status == "Success") {
				return res.status(200).send({ status: true, message: "Transaction defaced successfully." });
			}
			else {
				return res.status(body.statusCode).send({ status: false, message: body.message });
			}
		});
	} catch (error) {
		console.log("ERROR :::", error);
		return res.status(500).send({ status: false, message: "Internal server error. Please try after sometime." })
	}
}


exports.verifyPaymentByAppNumber = async(req, res)=>{
    try {
      const reqParams = req.params;
	  let appNum = reqParams.applicationNumber;
	  let paymentTransQuery;
	  if(appNum.indexOf("--"))
	  {
		let [appNumbr, paidAmount] = appNum.split("--");
		paymentTransQuery = {applicationNumber:appNumbr, totalAmount:parseFloat(paidAmount), transactionStatus:"Success",isUtilized:false};
	  }
	  else
	  	paymentTransQuery = {applicationNumber:appNum, transactionStatus:"Success"};
	  
	  let paymentDetailsList = await paymentReceiptsModel.find(paymentTransQuery);
	  let paymentDetails;
	  
	  if(paymentDetailsList!=null && paymentDetailsList!=undefined && paymentDetailsList.length>0)
	  	paymentDetails=paymentDetailsList[0];

	  if(paymentDetails===undefined || paymentDetails===null){
        return res.status(404).send({status:false, message:"Your payment is not yet completed. Please complete the payment process."})
      }else{
		let Obj ={
			cfmsTransID:paymentDetails.cfmsTransID,
			deptTransID:paymentDetails.departmentTransID,
			paymentMode:paymentDetails.paymentMode,
			amount:paymentDetails.totalAmount
		}
		//console.log("paymentDetails ::::",Obj);
		return res.status(200).send({status:true, data: Obj, message:"Data Fetched!"});
      }
    } catch (error) {
      console.log("ERROR :::",error);
	  return res.status(500).send({status:false, message:"Internal Server Error"})
    }
  }