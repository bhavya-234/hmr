const mongoose = require("mongoose");

const paymentReceiptsSchema = new mongoose.Schema({
 applicationNumber: { type: String },
 departmentTransID: { type: String },
 cfmsTransID: { type: String },
 transactionStatus: { type: String },
 amount: { type: Number },
 totalAmount: { type: Number },
 paymentMode: { type: String },
 isUtilized: { type: Boolean },
});

module.exports = mongoose.model("paymentreceipts", paymentReceiptsSchema);

