const express = require('express')
const jwt = require('../services/auth.service');
const paymentController = require('./payment.controller');
const router = express.Router();

router.post('/verifyTransactionStatus', jwt.verifyOfficerJwt, paymentController.verifyTransactionStatus)
router.get('/defaceTransaction/:deptTransID', jwt.verifyOfficerJwt, paymentController.defaceTransaction)
router.get('/verifyPayment/:applicationNumber',jwt.verifyUserjwt, paymentController.verifyPaymentByAppNumber)

module.exports = router;