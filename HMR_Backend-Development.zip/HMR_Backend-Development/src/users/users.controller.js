const userModel = require('./model/users.model');
const registrationModel = require('./model/registration.model');
const officerModel = require('../officer/model/officer.model');
const masterDataModel = require('../masterData/model/masterData.model');
const castModel = require('../cast/model/cast.model');
const otpModel = require('../otp/model/otp.model');
const jwt = require('../services/auth.service');
const nodemailer = require("nodemailer");
const fs = require('fs');
//const SMSurl = "http://igrs.ap.gov.in:7004/SMS_Service/SmsService";
const moment = require('moment');
const IP = require('ip');
//const helper = require('../utils/helper');
//const sysConstants = require('../utils/sysConstanst');
const ObjectId = require('mongoose').Types.ObjectId
const mailUtil = require("../common/mail");
let Validator = require('validatorjs');
const paymentReceiptsModel = require('../paymentModule/model/paymentReceipts.Model');
const tokenModel = require('../services/model/tokenModel');
const ssoUserModel = require('../sso/model/ssoUser.model');
const certificateRequestModel = require('../sso/model/certificateRequest.model')
const ssoController = require('../sso/ssoUser.controller')

const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[a-zA-Z\d@$!%*#?&]{8,}$/;
const mobilePattern = /^\d{10}$/;
const signs = ['>', '<', `'`, `"`, '%'];

Validator.register('mobileStrict', value =>
 mobilePattern.test(value), 'Please enter valid mobile number.');

 Validator.register('yesAndNoeCheck', value => {
    if(value.toUpperCase()=="YES" || value.toUpperCase()=="NO")
        return true;
    return false;
 }, 'Please enter valid value.');

 Validator.register('radioCountryCheck', value => {
    if(value.toUpperCase()=="INDIA" || value.toUpperCase()=="OTHER")
        return true;
    return false;
 }, 'Please enter valid country value.');

 Validator.register('radioStateCheck', value => {
    
    if(value==undefined || value=="" || value.toUpperCase()=="ANDHRA PRADESH" || value.toUpperCase()=="OTHER")
        return true;
    return false;
 }, 'Please select valid state value.');

 Validator.register('religionCheck', value => {
    if(value.toUpperCase()=="HINDU" || value.toUpperCase()=="SIKH" || 
      value.toUpperCase()=="BOUDHA" || value.toUpperCase()=="JAIN" || 
      value.toUpperCase()=="OTHERS")
        return true;
    return false;
 }, 'Please select valid religion value.');
 
 Validator.register('trueOrFalseCheck', value => {
    if(value.toUpperCase()=="TRUE" || value.toUpperCase()=="FALSE")
        return true;
    return false;
 }, 'Please enter valid value.');

 Validator.register('casteTypeCheck', value => {
    if(value.toUpperCase()=="SAME CASTE" || value.toUpperCase()=="DIFFERENT CASTE")
        return true;
    return false;
 }, 'Please select valid caste type value.');

Validator.register('maleDOB', dobString => {
    return testDOBData(dobString, 21);
}, 'Please enter valid date.');

Validator.register('femaleDOB', dobString => {
    return testDOBData(dobString, 18);
}, 'Please enter valid date.');

Validator.register('husbandAgeValidator', value => {
    return ageValidator(value, 21);
}, 'Husband age should be minimum 21years.');

Validator.register('wifeAgeValidator', value => {
    return ageValidator(value, 18);
}, 'Wife age should be minimum 18years.');

function ageValidator(ageString, minimumAge)
{
    if(parseInt(ageString) >= minimumAge)
        return true;
    return false;
}

Validator.register('mrigeDate', dateString => {
    return testDOBData(dateString, 0);
}, 'Please enter valid date.');

Validator.register('regDate', dateString => {
    var parts = dateString.split('-');
    var mydate;
    if(parts[2].length==4)
        mydate = new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]),0,0,0); 
    else
        mydate = new Date(dateString); 
    return validateDate(mydate.toDateString(), -1);
}, 'Please enter valid registration date.');

Validator.register('slotDate', dateString => {
    return validateDate(dateString, 1);
}, 'Please enter valid slot date.');

function validateDate(dateString, limit)
{
    var dateObj = new Date(dateString); 
    var curDate = new Date();
    if(curDate.getFullYear()==dateObj.getFullYear() && 
        dateObj.getMonth()==curDate.getMonth() && curDate.getDate()==dateObj.getDate())
        return true;
    else if(limit<0 && curDate.getTime()>dateObj.getTime())
        return true;
    else if(limit>0 && (curDate.getTime()<dateObj.getTime() || curDate.getTime()>dateObj.getTime()))
        return true;
    else
        return false;
}

function testDOBData(dateString, limit)
{
    var dateObj = new Date(dateString); 
    var month_diff = Date.now() - dateObj.getTime(); 
    let ageVal = month_diff/(365*24*60*60*1000);  
    if(ageVal>limit)
        return true;
    else
        return false;
}

const registerValidationRule = {
    "husbandName": "required|string",
    "husbandReligion": "required|string|religionCheck",
    "husbandCaste": "required|string",
    "husbandDateofBirth": "required|string|maleDOB",
	"husbandMarriageAge": "required|husbandAgeValidator",
    "husbandMobile": "required|string|mobileStrict",
	"husbandCountry": "required|string",
	"radio_husbandCountry": "required|string|radioCountryCheck",
	"husbandState": "string",
	"radio_husbandState": "string|radioStateCheck",
	"husbandAddress": "required|string",
	"husbandRelationship": "required|string",
	"husbandFatherName": "required|string",
	"husbandMotherName": "required|string",
	"radio_isHusbandDivorcee": "required|string|yesAndNoeCheck",
	"isHusbandWidower": "required|string|yesAndNoeCheck",
    "wifeName_beforeMarriage": "required|string",
	"change_wifeName_to_afterMarriage": "required|string",
    "wifeReligion":"required|string|religionCheck",
    "wifeCaste":"required|string",
    "wifeDateofBirth": "required|string|femaleDOB",
    "wifeMobile": "required|string|mobileStrict",
	"wifeMarriageAge": "required|wifeAgeValidator",
    "marriageDate":"required|string|mrigeDate",
	"wifeCountry": "required|string",
	"radio_wifeCountry": "required|string|radioCountryCheck",
	"wifeState": "string",
	"radio_wifeState": "string|radioStateCheck",
	"wifeAddress": "required|string",
	"wifeRelationship": "required|string",
	"wifeFatherName": "required|string",
	"wifeMotherName": "required|string",
	"radio_isWifeDivorcee": "required|string|yesAndNoeCheck",
	"isWifeWidow": "required|string|yesAndNoeCheck",
	"regDate": "required|string|regDate",
	"status": "required|string",
	"sroOffice": "required|string",
	"slotDate": "required|string|slotDate",
	"slotTime": "required|string",
	"casteType": "required|string|casteTypeCheck",
	"district": "required|string",
    "certificateCopies":"required|numeric|min:1|max:5"
}

exports.singup =async (req, res) => {

	const reqBody = req.body;
	if(reqBody?.loginEmail == null){
		return res.status(200).send({status:false,message:"Email ID is required."});
	};

    if(!mobilePattern.test(req.body.loginMobile))
        return res.status(200).send({status:false,message:"Please enter valid mobile number."});

    if(!passwordPattern.test(req.body.loginPassword))
        return res.status(200).send({status:false,message:"Please enter valid password."});
	/*
    if(req.body.loginPassword != req.body.loginRPassword)
   	   return res.status(404).send({Success:false,message:"Password and confirm password should be same."});
    */
   let filter = {loginEmail:reqBody.loginEmail, otp:reqBody.otp, isValidated:true};
	let otpVerify=await otpModel.findOne(filter);
	if(otpVerify == null){
		return res.status(200).send({status:false,message:"Email ID should be validated to complete signup process."});
	}
    try {
		const findUser = await userModel.findOne({"loginEmail":reqBody.loginEmail});
		if(findUser){
			return res.status(200).send({status:false,message:"Email ID already exists."});
		}else{
            if(reqBody.loginRPassword)
                delete reqBody.loginRPassword;
                
			const userData = new userModel(reqBody);
			const saveUser = await userData.save();
            await otpModel.findOneAndUpdate(filter,{$set:{isCount:5, "otp":"",otpType:"", isValidated:false}});
			let obj = {
				"loginEmail":saveUser.loginEmail,
				"loginMobile" :saveUser.loginMobile,
				"LoginName":saveUser.loginName,
				_id:saveUser._id
			}
			if(saveUser){
				return res.status(200).send({status:true,data:obj,message:`User created successfully.`});
			}else{
				return res.status(200).send({status:false,data:null,message:`Something went wrong.`});
			}
		}
    } catch (err) {
        res.status(200).send({status:false,data:null,message:`Something went wrong. Error: ${err.message}`})
    }
};


exports.logout = async(req,res) => {
    try {
        return res.status(200).json({ success: true, message: 'Token invalidated' });
    } catch (error) {
        
    }
}


exports.login = async(req,res) => {
    try {
        const reqBody = req.body;
        //block login untill that timestamp
        const findUserQuery = { "loginEmail": reqBody.loginEmail };
        const user = await userModel.findOne(findUserQuery).collation( { locale: 'en', strength: 2 } );
        if (user && user.loginAttemptsLeft === 0) {
            if (moment().isBefore(moment(user.loginBlockedUntil))) {
                return res.status(403).send({
                Success: false,
                message: `Login is blocked until ${moment(user.loginBlockedUntil).format('MMM DD YYYY hh:mm:ss A')}`
                });
            } else 
                await updateUserLoginTrials(findUserQuery, 5, null);
        }
        else  if (user == null)
            return res.status(404).send({Success:false,message:`Email ID/Password incorrect.`});

        
        let findQuery = {"loginEmail":reqBody.loginEmail,"loginPassword":reqBody.loginPassword};

        var date = new Date();
        var dateStr = ("00" + date.getDate()).slice(-2) + "-" +
            ("00" + (date.getMonth() + 1)).slice(-2) + "-" +
            date.getFullYear() + " " +
            ("00" + date.getHours()).slice(-2) + ":" +
            ("00" + date.getMinutes()).slice(-2) + ":" +
            ("00" + date.getSeconds()).slice(-2);

        let lastLoginUpdate = {lastLogin: dateStr};
        const loginUser = await userModel.findOne(findQuery ).collation( { locale: 'en', strength: 2 } );
        if(loginUser === undefined || loginUser==null){ //Login failure
            // Update user login attempts count
            let loginAttemptsLeft = null;
            let loginBlockedUntil = null;
            if(user.loginAttemptsLeft==undefined)
                user.loginAttemptsLeft=5;
            if (user &&  user.loginAttemptsLeft > 0 ) {
                loginAttemptsLeft = user.loginAttemptsLeft - 1;
                if (loginAttemptsLeft === 0) { // Set user blocking time
                    loginBlockedUntil = new Date(moment().add('5', 'minutes'));
                }
                await updateUserLoginTrials(findUserQuery,loginAttemptsLeft, loginBlockedUntil);
            }
            return res.status(404).send({Success:false,message:`Email ID/Password incorrect. ${loginAttemptsLeft > 0 ? `${loginAttemptsLeft} attempts left.` : `Login is blocked for 5 minutes.`}`});
        }else{
            //login sucessful
            //user unblock & reset
            await updateUserLoginTrials(findUserQuery, 5, null);
            let origin = req.headers['Origin'];
            if(origin == null)
                origin= "";
            let user= {
                userId:loginUser._id,
                loginEmail:loginUser.loginEmail,
                lastLogin:loginUser.lastLogin,
                loginType:loginUser.loginType,
                origin:origin
            }
            await userModel.findOneAndUpdate(findQuery, {$set: lastLoginUpdate},{upsert:false, multi:false}).collation( { locale: 'en', strength: 2 } );
            let tokenUrl = req.protocol + "://" + req.get("host") + "/api/token/"
            const token =await jwt.createToken(user,tokenUrl);
            
            /*
            const sort = { created_at: -1 };
            let regDetails = await registrationModel.find({createdBy: user.userId,husbandName:{$ne:""}}).sort(sort);
            var regDetails1 = [];
            if(regDetails){
                regDetails.filter(x => {
                    let data = {}
                    data.id = x._id;
                    data.husbandName = x.husbandName;
                    data.wifeName_beforeMarriage = x.wifeName_beforeMarriage;
                    data.regDate = x.regDate;
                    data.status = x.status;
                    data.appNo = x.appNo;
                    if(x.villageScretariatName && x.villageScretariatName.trim().length>0)
                        data["assignedTo"] = "VSWS-"+x.villageScretariatName;
                    else
                        data["assignedTo"] = "SRO-"+x.sroOffice;
                    regDetails1.push(data);
                })
                user.registrationDetails=regDetails1;
            };
            */
            user.loginId =loginUser._id,
            user.loginEmail =loginUser.loginEmail,
            user.loginName =loginUser.loginName,
            user.lastLogin = loginUser.lastLogin,
            user.token =token;
            return res.status(200).send({
            status: true,
                message: "",
                code: 200,
                data: user
            })
        }
    } catch (ex) {
        // console.log("ERROR ::", ex);
        res.status(500).send({
            success: false,
            message:'Something went wrong.',
            data: "",
            error: ex.message
        });
    }
};


const updateUserLoginTrials = async (findOfficerQuery, loginAttemptsLeft, loginBlockedUntil) => {
    let setQuery = { loginAttemptsLeft: loginAttemptsLeft, loginBlockedUntil: loginBlockedUntil };
    await userModel.findOneAndUpdate(findOfficerQuery, { $set: setQuery }, { upsert: false, multi:false });
}


exports.forgotPassword = async (req,res) => {
    try {
        let transporter = nodemailer.createTransport({
            host: "smtp-mail.outlook.com",
            port: 587,
            //secure: false,
            ssl: true,
            auth: {
                user: "support.igrs@criticalriver.com",
                pass: "Rockstar@1234",
            },
        });
		const identify = {loginEmail:req.body.loginEmail}
        const findUser = await userModel.findOne(identify);
		if(findUser == undefined){
			return res.status(200).send({status:false,message:`Invalid Email ID.`})
		}else{
			const reqBody = req.body;
			let identify2 = {loginEmail:reqBody.loginEmail };
            let otpTypeObject = await otpModel.findOne({loginEmail:reqBody.loginEmail, otpType:"forgotOtp"});
            let otpCount = validateOtpCount(otpTypeObject);
            if(otpCount < 1)
                return res.status(200).send({status:false, message:"Send OTP limit is exceeded. Please try after "+(process.env.SEND_OTP_TIME_LIMIT)+"mins."});
			
            let otp = Math.floor(1000 + Math.random() * 9000);
			var info = await transporter.sendMail({
				from: '"IGRS" <support.igrs@criticalriver.com>', // sender address
				to: req.body.loginEmail, // list of receivers
				subject: "Reset password", // Subject line
				text: "Hi user, ", // plain text body
				html: `<b>OTP to verify the user ${otp} </b>`
            });
            
			let query = {otp:String(otp),status:true,otpType:'forgotOtp',isCount:5, isValidated:false, sendOtpCount:otpCount}
			const otpVerify = await otpModel.findOneAndUpdate(identify2,query)
			if(otpVerify){
				return res.status(200).send({status:true,message:"OTP sent to your Email ID successfully."})
			}
            else {
                const newOtpDocument = new otpModel({ ...identify2, ...query });
			    const otpSave = await newOtpDocument.save();
                if (otpSave) 
                    return res.status(200).send({ status: true, message: "OTP sent to your Email ID successfully." })
                else
                    return res.status(200).send({ status: false, message: "Something went wrong." })
            }   
		}
    } catch (err) {
        console.log("Process Error", err);
        return res.status(200).send({status:false,message:"Something went wrong."})
    }
};

function validateOtpCount(otpTypeObject)
{
    let otpCount = 5;
    if(otpTypeObject!=null && otpTypeObject!=undefined)
    {
        if(otpTypeObject.sendOtpCount!=undefined || otpTypeObject.sendOtpCount!=null)
            otpCount = parseInt(otpTypeObject.sendOtpCount)-1;

        if(otpTypeObject.updatedAt!=undefined && otpTypeObject.updatedAt != null)
        {
            let lastUpdated = new Date(otpTypeObject.updatedAt).getTime();
            let presentTime = new Date().getTime();
            let timeLimit = parseInt(process.env.SEND_OTP_TIME_LIMIT);
            lastUpdated = lastUpdated+(timeLimit*60*1000);
            if(presentTime>=lastUpdated)
                otpCount = 5;  
        }
    }
    return otpCount;
}

exports.otpValidation = async (req,res) => {
    try {
       	const reqParams = req.params;
		const reqBody = req.body;
		const filters = {loginEmail:reqBody.loginEmail, otp:reqBody.otp, otpType:reqParams.otpType, isValidated:false};
		const query1 = {loginEmail:reqBody.loginEmail,status:false, isValidated:true, sendOtpCount:5 }
        const otpVerify = await otpModel.findOne(filters);
		if(otpVerify !== null && otpVerify.isCount>1){
			verify = await otpModel.findOneAndUpdate(filters,{$set:query1})
			res.status(200).send({status:true,message:"OTP verified successfully."})
		}else{
			let countDown = await otpModel.findOne({loginEmail:reqBody.loginEmail});
            if(countDown.otp==undefined || countDown.otp==null || countDown.otp=="")
                return res.status(200).send({status:false,message:`Provide valid OTP to verify.`})			
			let cDown = parseInt(countDown.isCount -1);

			if(cDown === 0){
				return res.status(200).send({status:false,message:`You have exceeded OTP verification attempts.Please try again with send OTP.`});			
			}else{
				await otpModel.findOneAndUpdate({loginEmail:reqBody.loginEmail},{$set:{isCount:cDown}});
				return res.status(200).send({status:false,message:	`OTP is invalid, you have only ${cDown} attempts.`})
			}
		}
    } catch (err) {
        console.log("Process Error" , err);
        return res.status(200).send({status:false,message:	`Internal server error. Please try after sometime.`})
    }
};

exports.emailVerification =async (req,res) => {
    try {
        let transporter = nodemailer.createTransport({
            host: "smtp-mail.outlook.com",
            port: 587,
            //secure: false,
            ssl: true,
            auth: {
                user: "support.igrs@criticalriver.com",
                pass: "Rockstar@1234",
            },
        });
		let findUser = await userModel.find({loginEmail:req.body.loginEmail},{_id:1,loginEmail:1,app:1})
		if(findUser.length >0){
			return res.status(200).send({status:false,message:"Email ID already exists."})
		}else{            
            let otpData = await otpModel.findOne({loginEmail:req.body.loginEmail, otpType:"regOtp"});
            let otpCount = validateOtpCount(otpData);
            if(otpCount < 1)
                return res.status(200).send({status:false, message:"Send OTP limit is exceeded. Please try after "+(process.env.SEND_OTP_TIME_LIMIT)+"mins."});
            
			var otp = Math.floor(1000 + Math.random() * 9000);
			var info = await transporter.sendMail({
				from: '"IGRS" <support.igrs@criticalriver.com>', // sender address
				to: req.body.loginEmail, // list of receivers
				subject: "Email verification", // Subject line
				text: "Hi user, ", // plain text body
				html: `<b>OTP to verify the email ${otp} </b>`
			});
			const reqData = {loginEmail:req.body.loginEmail,otp:otp,status:true,isCount:5, sendOtpCount:otpCount, isValidated:false, otpType:"regOtp"};
			await otpModel.findOneAndUpdate({ loginEmail: req.body.loginEmail },{ $set: reqData },{ upsert: true });
			delete reqData.otp;
			return res.status(200).send({status:true,message:"OTP sent to your Email ID successfully."})
		}
    } catch (err) {
        console.log("Process Error", err);
        return res.status(200).send({status:false,message:	`Internal server error. Please try after sometime.`})
    }
};

exports.getUserAll = () => {
    try {
        return new Promise((resolve, reject) => {
            userModel.find()
                .then(response => resolve(response))
                .catch(err => reject(err));
        });
    } catch (err) {
        console.log("Process Error", err);
    }
};

exports.resetPassword = (req) => {
        return new Promise((resolve, reject) => {
        try {
            if(!passwordPattern.test(req.body.loginPassword))
                reject('Password should meet the password policy.');

            if (req.body.loginType == "USER" || req.body.loginType == "sso" ) {
                userModel.findOneAndUpdate({ _id: req.body.loginId }, { $set: { loginPassword: req.body.loginPassword } })
                    .then(details => resolve("Password changed successfully."))
                    .catch(err => reject(err));
            } else {
                officerModel.findOneAndUpdate({ _id: req.body.loginId }, { $set: { loginPassword: req.body.loginPassword } })
                    .then(details => resolve("Password changed successfully."))
                    .catch(err => reject(err));
            }
    } catch (err) {
            console.log("Process Error :: ",  err.message);
            reject(err);
    }
    });
    
};

exports.resetPasswordByMail =async (req,res) => {
    try {
        if(!passwordPattern.test(req.body.loginPassword))
            return res.status(200).send({status:false,message:"Password should meet the password policy."});

        let filter = {loginEmail:req.body.loginEmail, otp:req.body.otp, isValidated:true};
        let otpData = await otpModel.findOne(filter);
		if(otpData){
			await userModel.findOneAndUpdate({loginEmail: req.body.loginEmail},{$set:{loginPassword: req.body.loginPassword}});
            await otpModel.findOneAndUpdate(filter,{$set:{isCount:5, "otp":"",otpType:"", isValidated:false}});
			return res.status(200).send({status:true,message:"Password changed successfully."});
		}else{
            return res.status(200).send({status:false,message:"Email ID should be validated to change the password."})
        }
    } catch (err) {
        console.log("Process Error", err);
        return res.status(200).send({status:false,message:"Internal server error. Please try after sometime."})
    }
};

exports.getUserById = (data) => {
    return new Promise((resolve, reject) => {
        try {
        userModel.find({ _id: data })
            .then(response => resolve(response))
            .catch(err => reject(err));
        } catch (err) {
            console.log("Process Error", err);
            reject(err);
        }
    });
    
};

exports.getUserByAppNo = (req) => {
    return new Promise(async(resolve, reject) => {
        try {
            let userData = req.user;
            let dataFilter;  
            if(userData.loginType == "officer")
            {
                let officerData = await officerModel.findOne({ _id: ObjectId(userData.userId)});
                if(userData.role=="SRO" || userData.role == "VR")
                {
                    let findRegQuery = {_id: ObjectId(req.params.id), status:"NEW"};
                    dataFilter = { _id: ObjectId(req.params.id), sroNumber:  officerData.sroNumber};
                    if(userData.role=="SRO")
                        findRegQuery["villageScretariatCode"]={$in:["", null]};
                    else
                        findRegQuery["villageScretariatCode"]={$nin:["", null]};

                    let regModelData = await registrationModel.findOneAndUpdate(findRegQuery, {$set: { status: "PENDING" } });
                    if(regModelData!=null && regModelData.requestId!=null && regModelData.requestId!=undefined && regModelData.requestId!="")
                        ssoController.updateStatusToAPSevaWithDetails(regModelData.appNo, "MarrigaeRegistration", "HMR Marriage registration updated status", 2, "SRO");
                } 
                else if(userData.role=="DR")
                    dataFilter = { _id: ObjectId(req.params.id), district:  officerData.district};
                else if(userData.role=="DIG")
                    dataFilter = { _id: ObjectId(req.params.id), district: {$in : officerData.subDistrict}};
                else if(userData.role=="IG")
                    dataFilter = { _id: ObjectId(req.params.id)};
            }
            else
                dataFilter = { _id: ObjectId(req.params.id), createdBy:  userData.userId}; 
                        
            registrationModel.findOne(dataFilter).then( async response => {
                if(response.transactionId!="" && response.transactionId!=undefined 
                        && response.transactionId!=null)
                {
                    let paymentData = await paymentReceiptsModel.findOne({departmentTransID:response.transactionId} )
                    console.log("paymentData ::: ", paymentData);
                    if(paymentData!=null && paymentData!=undefined)
                    {
                        response.paidAmount = paymentData.totalAmount;
                        response.payStatus = paymentData.isUtilized;
                    }
                }
                //console.log(" response Data ::; ", response);
                resolve(response)
            }).catch(err => reject(err));   
        } catch (err) {
            console.log("Process Error",  err);
            reject(err);
        }
    });
};

exports.getCertificateRequestsbyAppNo = (req) => {
    return new Promise(async(resolve, reject) => {
        try {
            let userData = req.user;
            let dataFilter;  
            if (userData.loginType == "officer" && userData.role == "SRO") {
                let officerData = await officerModel.findOne({ _id: ObjectId(userData.userId) });
                dataFilter = { _id: ObjectId(req.params.id), sroNumber:  officerData.sroNumber };
            } else
                dataFilter = { _id: ObjectId(req.params.id), createdBy:  userData.userId }; 

            const certificateData = await certificateRequestModel.findOne(dataFilter).lean();
            if (!certificateData) {
                return resolve(null);
            }
            let registrationData;
            if (certificateData.appNumber) {
                registrationData = await registrationModel.findOne({ appNo: certificateData.appNumber }).lean();
            }
            if (registrationData) {
                const formattedResponse = {
                    ...registrationData,
                    ...certificateData,
                    createdAt: moment(certificateData.createdAt).format('DD-MM-YYYY'),
                    updatedAt: moment(certificateData.updatedAt).format('DD-MM-YYYY')
                };
                if (formattedResponse.departmentTransaction) {
                    const paymentData = await paymentReceiptsModel.findOne({ departmentTransID: formattedResponse.departmentTransaction });
                    if (paymentData != null && paymentData != undefined) {
                        formattedResponse.paidAmount = paymentData.totalAmount;
                        formattedResponse.payStatus = paymentData.isUtilized;
                    }
                }
                resolve(formattedResponse);
            } else {
                const formattedResponse = {
                    ...certificateData,
                    createdAt: moment(certificateData.createdAt).format('DD-MM-YYYY'),
                    updatedAt: moment(certificateData.updatedAt).format('DD-MM-YYYY')
                };
                if (formattedResponse.departmentTransaction) {
                    const paymentData = await paymentReceiptsModel.findOne({ departmentTransID: formattedResponse.departmentTransaction });
                    if (paymentData != null && paymentData != undefined) {
                        formattedResponse.paidAmount = paymentData.totalAmount;
                        formattedResponse.payStatus = paymentData.isUtilized;
                    }
                }
                resolve(formattedResponse);
            }
        } catch (err) {
            console.log("Process Error", err);
            reject(err);
        }
    });
};

exports.UpdateCertitificateRequestDatabySRO = (req) => {
    return new Promise(async(resolve, reject) => {
        try {
            let userData = req.user;
            if (userData.loginType === "officer" && userData.role === "SRO") {
                let officerData = await officerModel.findOne({ _id: ObjectId(userData.userId)});
                let findRegQuery = {_id: ObjectId(req.params.id), status: "PENDING", sroNumber: officerData.sroNumber};
                let updatedRegQuery = {_id: ObjectId(req.params.id), status: "COMPLETED", sroNumber: officerData.sroNumber};
                
                certificateRequestModel.findOneAndUpdate(findRegQuery, {$set: { status: "COMPLETED" } }).then(async response => {
                    if (!response) {
                        reject("No pending registration found for this SRO.");
                    } else {
                        let updatedData = await certificateRequestModel.findOne(updatedRegQuery);
                        if (!updatedData) {
                            reject("Something went wrong during update. Please try again.");
                        } else {
                            resolve("Request certificate process completed successfully.");
                        }
                    }
                }).catch(err => reject(err));
            } 
        } catch (err) {
            console.log("Process Error",  err);
            reject(err);
        }
    });
};

exports.fileUpload = async (req) => {
    return new Promise(async (resolve, reject) => {
        try {
            let registration_Id = req.params.registrationId;
            let userRegData = await registrationModel.findOne({_id:registration_Id, status:{$ne:"COMPLETED"}})
            if(userRegData==null )
            {
                reject("Something went wrong. Please try with new registartion.");
            }
            else
            {
                let reqParamfileName = req.params.fileName;
                const ipAddress = IP.address();
                const [local, rest] = req.get("host").split(":");
                let Url =
                    local === "localhost"
                        ? req.protocol + "://" + req.get("host") + "/uploads"
                        : "http://" + req.get("host") + "/uploads";
                let tempObj = {
                    fileName: reqParamfileName,
                    filePath: req.files.image[0].path,
                    downloadLink: req.files.image[0].mimetype === "application/pdf" ?
                        `${Url}/${registration_Id}/${reqParamfileName}.pdf` : `${Url}/${registration_Id}/${reqParamfileName}.png`,
                    timeStamp: new Date()
                }
                try{
                    const query = { "_id": registration_Id };
                    const findUserDocs = await  registrationModel.findOne(query);
                //  const findUserDocs = await helper.findOneMethod(sysConstants.Col_users, query);
                    if (findUserDocs.documents  == undefined || findUserDocs.documents==null || findUserDocs.documents.length === 0) {
                        registrationModel.findOneAndUpdate({ _id: registration_Id, documents: { $nin: tempObj } }, { $push: { documents: tempObj } })
                            .then(details => resolve("Image added successfully."))
                            .catch(err => reject(err));
                    }
                    else {
                        const fileExist = await findUserDocs.documents.some(doc => doc.fileName === reqParamfileName);
                        if (fileExist) {
                            registrationModel.findOneAndUpdate
                            (
                                {
                                    _id: registration_Id,
                                    documents: { $elemMatch: { fileName: { $eq: reqParamfileName } } }
                                },
                                {
                                    $set: { "documents.$": tempObj }
                                },
                                { upsert: true }
                            )
                            .then(details => resolve("Image added successfully."))
                            .catch(err => reject(err));
                        } else {
                            registrationModel.findOneAndUpdate
                            (
                                {
                                    _id: registration_Id,
                                    documents: { $elemMatch: { fileName: { $ne: reqParamfileName } } }
                                },
                                {
                                    $push: { "documents": tempObj }
                                }
                            )
                            .then(details => resolve("Image added successfully."))
                            .catch(err => reject(err))
                        }
                    }
                }catch(err){
                    console.log("Process Error ::: ", err);
                    reject(err);
                }
            }
            
        } catch (err) {
            console.log("Process Error :: ", err);
            reject(err);
        }
    });
    
};



exports.GetRevenueDetailsofHMR = async (req) => {
    return new Promise(async (resolve, reject) => {
        try {
            let srnumber = parseInt(req.query.sroNumber); 
            let startdate = new Date(req.query.startdate);
            let enddate = new Date(req.query.enddate);

            const query = {
                cert_form: true,
                sroNumber: srnumber,
                updatedAt: { $gte: startdate, $lte: enddate }
            };

            let userRegData = await registrationModel.find(query);

            if (!userRegData) {
                reject("No registration data found for the provided SRO number and date range.");
            } else {
                let resultArray = userRegData.map(data => ({
                    appNo: data.appNo,
                    payat: data.paymentType,
                    amount: data.paidAmount,
                    cert_url:data.cert_url,
                    cert_form:data.cert_form,
                    updatedAt:data.updatedAt
                }));
                resolve(resultArray);
            }
        } catch (err) {
            console.log("Process Error", err);
            reject(err);
        }
    });
};




// {cert_form:true,sroNumber:623,updatedAt:{$gte:ISODate("2024-05-23"),$lte: ISODate("2024-05-25") }}
// {cert_form:true,updatedAt:{$gte:ISODate("2024-05-23"),$lte: ISODate("2024-05-25") }}

exports.sampleRegistration =async (req) => {
    return new Promise(async (resolve, reject) => {
        try {
            let loginUser = req.user;
            /*
            let data = await registrationModel.find({createdBy:loginUser.userId,tempApplication:true})
            if(data.length>0){
                await registrationModel.findOneAndUpdate({ _id: data[0]._id }, { $set: {documents:[]} })
                resolve({registrationId:data[0]._id, appNo:data[0].appNo})
            }else{
                */
                let appNo = Date.now();
                let userData = await registrationModel.find({"appNo":appNo});
                if(userData!=null &&  userData.length>0)
                    appNo = Date.now();
                registrationModel.create({createdBy:loginUser.userId,appNo:appNo})
                .then(details => resolve({registrationId:details._id,appNo: details.appNo}))
                .catch(err => reject(err));
            //}
        } catch (err) {
            console.log("Process Error" , err);
            reject(err);
        }
    }); 
}

exports.removeFileUploadByAppNoAndFileName = async(req,res) => {
    try {
        let fileName = req.params.fileName;
        let applicationNumber = req.params.appNo;
        let registartion = await registrationModel.findOne({appNo:applicationNumber})
        if(registartion!=null && registartion!=undefined)
        {
            let docArray = registartion.documents;
            let index = -1;
            docArray.map((data, i)=>{
                const [name,rest]=data.fileName.split(".");
                if(name === fileName){
                    index = i;
                    return false;
                }	
            });
            if(index>-1)
            {
                docArray.splice(index, 1);
                registartion = await registrationModel.findOneAndUpdate({appNo:applicationNumber}, {$set:{documents:docArray}});
                if(registartion!=null && registartion!=undefined)
                    return res.status(200).json({ success: true, message: 'File removed successfully.' });
                else
                    return res.status(200).json({ success: false, message: 'Something went wrong. Please try after sometime.' });
            }
            else
                return res.status(200).json({ success: false, message: 'Data not found.' });
        }
        else
            return res.status(200).json({ success: false, message: 'Data not found.' });
    } catch (error) {
        return res.status(200).json({ success: false, message: 'Something went wrong. Please try after sometime.' });
    }
}


exports.saveRegistrationAsDraft = async (req) => {
    return new Promise(async (resolve, reject) => {
        try{
            let registrationId = req.body.registrationId;
            let userRegData = await registrationModel.findOne({_id:registrationId, status:{$ne:"COMPLETED"}})
            if(userRegData==null )
            {
                reject("Something went wrong. Please try with new registartion.");
            }
            
            const reqBody = req.body;
            if(Object.keys(reqBody).filter(o => {
                let flag = false;
                signs.forEach(ob => {
                    if(typeof reqBody[o] === 'string' && reqBody[o].includes(ob)){
                        flag = true;
                    }
                });
                return flag
            }).length>0){
                let validationError = {
                    message:"Form fields should not contain any of these special characters [>, <, ', \", %].",
                    status:412,
                    Success:false
                }
                reject(validationError);
            }else{    
                let validation = new Validator(req.body, registerValidationRule);
                if(validation.fails())
                {
                    let validationError = {
                        message:"Validation failed.",
                        status:412,
                        Success:false,
                        data:validation.errors.errors
                    }
                    reject(validationError);
                }
                else
                {
                    try{
                        let validationError = null;
                        let husbCountry = req.body.husbandCountry;
                        let radio_husbCountry = req.body.radio_husbandCountry;
                        validationError = this.validateCountrySelection (husbCountry, radio_husbCountry, "Husband's country selection is invalid.");
                        
                        let wifCountry = req.body.wifeCountry;
                        let radio_wifCountry = req.body.radio_wifeCountry
                        validationError = this.validateCountrySelection (wifCountry, radio_wifCountry, "Wife's country selection is invalid.");
                        
                        let husDistrict = req.body.husbandDistrict;
                        let husMandal = req.body.husbandMandal;
                        let husVillWard = req.body.husbandVillageWard;
                        let wifDistrict = req.body.wifeDistrict;
                        let wifMandal = req.body.wifeMandal;
                        let wifVillWard = req.body.wifeVillageWard;
                        let marrDistrict = req.body.marriageDistrict;
                        let marrMandal = req.body.marriageMandal;
                        let marrVillWard = req.body.marriageVillageWard;

                        if((husDistrict!=undefined && husDistrict!=null && husDistrict.trim().length>0) || 
                            (husMandal!=undefined && husMandal!=null && husMandal.trim().length>0) || 
                            (husVillWard!=undefined && husVillWard!=null && husVillWard.trim().length>0) )
                            validationError = await this.validateDistrictAndMandalAndVillage (husDistrict, husMandal, husVillWard, "Husband Address");
                            
                        if(validationError==null && ((wifDistrict!=undefined && wifDistrict!=null && wifDistrict.trim().length>0) || 
                            (wifMandal!=undefined && wifMandal!=null && wifMandal.trim().length>0) || 
                            (wifVillWard!=undefined && wifVillWard!=null && wifVillWard.trim().length>0)) )
                            validationError = await this.validateDistrictAndMandalAndVillage (wifDistrict, wifMandal, wifVillWard, "Wife Address");

                        if(validationError==null && ((marrDistrict!=undefined && marrDistrict!=null && marrDistrict.trim().length>0) || 
                            (marrMandal!=undefined && marrMandal!=null && marrMandal.trim().length>0) || 
                            (marrVillWard!=undefined && marrVillWard!=null && marrVillWard.trim().length>0)) )
                            validationError = await this.validateDistrictAndMandalAndVillage (marrDistrict, marrMandal, marrVillWard, "Marriage Address");
                    
                        /*
                        let husCaste = req.body.husbandCaste;
                        let wifCaste = req.body.wifeCaste;
                        if(validationError==null && husCaste!=undefined && husCaste!=null && husCaste.trim().length>0)
                            validationError = await this.validateCaste(husCaste, "Husband caste");

                        if(validationError==null && wifCaste!=undefined && wifCaste!=null && wifCaste.trim().length>0)
                            validationError = await this.validateCaste(wifCaste, "Wife caste");
                        */
                        if(validationError!=null)
                            reject(validationError);
                        else
                        {
                            let users = req.body;

                            if(userRegData!=null && userRegData!=undefined && 
                                userRegData.husbandName=="" &&  req.body.husbandName!="")
                            {
                                users.status="NEW";
                            }         
                            //users.tempApplication=false;
                            if (req.body.marriageDate) {
                                var husbentDate = req.body.husbandDateofBirth.split("-");
                                var wifeDate = req.body.wifeDateofBirth.split("-");
                                var marriageDate = req.body.marriageDate.split("-");
                                var a = moment([parseInt(husbentDate[0]), parseInt(husbentDate[1])]);
                                var b = moment([parseInt(wifeDate[0]), parseInt(wifeDate[1])]);
                                var c = moment([parseInt(marriageDate[0]), parseInt(marriageDate[1])]);
                                var hubendAge = c.diff(a, 'years');       // 1
                                var wifeAge = c.diff(b, 'years');
                            }

                            if(users.husbandAddress!=undefined && users.husbandAddress!=null)
                            {
                                let husbandAddress = users.husbandAddress;
                                let wifeAddress = users.wifeAddress;
                                let marriageAddress = users.marriageAddress;
                    
                                users.husbandAddress = husbandAddress.replace(/\n/gm," ");
                                users.wifeAddress = wifeAddress.replace(/\n/gm," ");
                                users.marriageAddress = marriageAddress.replace(/\n/gm," ");
                            }
                            
                            users.status="DRAFT";
                            let loginUser = req.user;
                            let userRegDocuments = userRegData.documents;
                            if(userRegDocuments!=undefined && userRegDocuments.length>0)
                            {
                                users.documents = userRegDocuments;
                            }
                            if(req.body.sroOffice === "TIRUMALA"){
                                users.sroNumber = 7777;
                            } else if(loginUser.role==='SRO' || loginUser.role==='VR')
                            {
                                let officerData = await officerModel.findOne({ _id: ObjectId(loginUser.userId)});
                                users.sroNumber = officerData.sroNumber;
                            }
                            else {
                                let query ={"districtName":users.district,"sroName": users.sroOffice };
                                let SRNO = await masterDataModel.findOne(query);
                                users.sroNumber = SRNO.parentSroCode;
                            }
                            
                            if(users.appNo!=undefined && users.appNo!=null && (users.appNo).indexOf("HM")==-1)
                            {
                                let appNumber = users.appNo;
                                users.appNo = "HM"+users.sroNumber+appNumber;
                                await paymentReceiptsModel.findOneAndUpdate({applicationNumber:appNumber, transactionStatus:"Success"}, { $set: { applicationNumber:users.appNo } });
                            }
                                
                            delete users.registrationId;
                            registrationModel.findOneAndUpdate({ _id: registrationId }, { $set: users })
                            .then(async details =>{
                                resolve({appNo:users.appNo ,statusMessage: "Registration details saved as draft successfully."})
                            }).catch(err => reject(err));
                        
                        }
                    }catch(err){
                        console.log("Error ::: ", err);
                        reject(err);
                    }
                }
            }            
        }catch(err){
            console.log("Error ::: ", err);
            reject(err);
        }
    });
}



exports.saveUser = async (req) => {
    return new Promise(async (resolve, reject) => {
        try{
            let registrationId = req.body.registrationId;
            let userRegData = await registrationModel.findOne({_id:registrationId, status:{$ne:"COMPLETED"}})
            
            if(userRegData==null )
            {
                reject("Something went wrong. Please try with new registartion.");
            }
            if(req.body.status !== undefined && req.body.status === "COMPLETED"){
                await registrationModel.updateOne({ _id: registrationId }, { $set: {status:req.body.status} });
                if(req.body.requestId!=null && req.body.requestId!=undefined && req.body.requestId!="")
                    ssoController.updateStatusToAPSevaWithDetails(userRegData.appNo, "MarrigaeRegistration", "HMR Marriage registration completed", 2, "SRO");
                resolve("Registration process completed successfully.");
            }
            else
            {
                const reqBody = req.body;
                if(Object.keys(reqBody).filter(o => {
                    let flag = false;
                    signs.forEach(ob => {
                        if(typeof reqBody[o] === 'string' && reqBody[o].includes(ob)){
                            flag = true;
                        }
                    });
                    return flag
                }).length>0){
                    let validationError = {
                        message:"Form fields should not contain any of these special characters [>, <, ', \", %].",
                        status:412,
                        Success:false
                    }
                    reject(validationError);
                }else{    
                    let validation = new Validator(req.body, registerValidationRule);
                    if(validation.fails())
                    {
                        let validationError = {
                            message:"Validation failed.",
                            status:412,
                            Success:false,
                            data:validation.errors.errors
                        }
                        reject(validationError);
                    }
                    else
                    {
                        try{
                            let loginUser = req.user;
                            let validationError = null;
                            let husbCountry = req.body.husbandCountry;
                            let radio_husbCountry = req.body.radio_husbandCountry;
                            validationError = this.validateCountrySelection (husbCountry, radio_husbCountry, "Husband's country selection is invalid.");
                            
                            let wifCountry = req.body.wifeCountry;
                            let radio_wifCountry = req.body.radio_wifeCountry
                            validationError = this.validateCountrySelection (wifCountry, radio_wifCountry, "Wife's country selection is invalid.");
                            
                            let husDistrict = req.body.husbandDistrict;
                            let husMandal = req.body.husbandMandal;
                            let husVillWard = req.body.husbandVillageWard;
                            let wifDistrict = req.body.wifeDistrict;
                            let wifMandal = req.body.wifeMandal;
                            let wifVillWard = req.body.wifeVillageWard;
                            let marrDistrict = req.body.marriageDistrict;
                            let marrMandal = req.body.marriageMandal;
                            let marrVillWard = req.body.marriageVillageWard;

                            if(loginUser.loginType === 'USER' || loginUser.loginType === 'sso' ){
                            if((husDistrict!=undefined && husDistrict!=null && husDistrict.trim().length>0) || 
                                (husMandal!=undefined && husMandal!=null && husMandal.trim().length>0) || 
                                (husVillWard!=undefined && husVillWard!=null && husVillWard.trim().length>0) )
                                validationError = await this.validateDistrictAndMandalAndVillage (husDistrict, husMandal, husVillWard, "Husband Address");
                                
                            if(validationError==null && ((wifDistrict!=undefined && wifDistrict!=null && wifDistrict.trim().length>0) || 
                                (wifMandal!=undefined && wifMandal!=null && wifMandal.trim().length>0) || 
                                (wifVillWard!=undefined && wifVillWard!=null && wifVillWard.trim().length>0)) )
                                validationError = await this.validateDistrictAndMandalAndVillage (wifDistrict, wifMandal, wifVillWard, "Wife Address");

                            if(validationError==null && ((marrDistrict!=undefined && marrDistrict!=null && marrDistrict.trim().length>0) || 
                                (marrMandal!=undefined && marrMandal!=null && marrMandal.trim().length>0) || 
                                (marrVillWard!=undefined && marrVillWard!=null && marrVillWard.trim().length>0)) )
                                validationError = await this.validateDistrictAndMandalAndVillage (marrDistrict, marrMandal, marrVillWard, "Marriage Address");
                            }
                            /*
                            let husCaste = req.body.husbandCaste;
                            let wifCaste = req.body.wifeCaste;
                            if(validationError==null && husCaste!=undefined && husCaste!=null && husCaste.trim().length>0)
                                validationError = await this.validateCaste(husCaste, "Husband caste");

                            if(validationError==null && wifCaste!=undefined && wifCaste!=null && wifCaste.trim().length>0)
                                validationError = await this.validateCaste(wifCaste, "Wife caste");
                            */
                            if(validationError!=null)
                                reject(validationError);
                            else
                            {
                                let users = req.body;

                                if(userRegData!=null && userRegData!=undefined && 
                                    (userRegData.status.toUpperCase() == "DRAFT" ||
                                    (userRegData.husbandName=="" &&  req.body.husbandName!=""))
                                )
                                {
                                    users.status="NEW";
                                }         
                                //users.tempApplication=false;
                                if (req.body.marriageDate) {
                                    var husbentDate = req.body.husbandDateofBirth.split("-");
                                    var wifeDate = req.body.wifeDateofBirth.split("-");
                                    var marriageDate = req.body.marriageDate.split("-");
                                    var a = moment([parseInt(husbentDate[0]), parseInt(husbentDate[1])]);
                                    var b = moment([parseInt(wifeDate[0]), parseInt(wifeDate[1])]);
                                    var c = moment([parseInt(marriageDate[0]), parseInt(marriageDate[1])]);
                                    var hubendAge = c.diff(a, 'years');       // 1
                                    var wifeAge = c.diff(b, 'years');
                                }

                                if(users.husbandAddress!=undefined && users.husbandAddress!=null)
                                {
                                    let husbandAddress = users.husbandAddress;
                                    let wifeAddress = users.wifeAddress;
                                    let marriageAddress = users.marriageAddress;
                        
                                    users.husbandAddress = husbandAddress.replace(/\n/gm," ");
                                    users.wifeAddress = wifeAddress.replace(/\n/gm," ");
                                    users.marriageAddress = marriageAddress.replace(/\n/gm," ");
                                }
                                
                                if(users.status !== undefined && users.status!== "COMPLETED"){
                                    let loginUser = req.user;
                                    let userRegDocuments = userRegData.documents;
                                    if(userRegDocuments!=undefined && userRegDocuments.length>0)
                                    {
                                        users.documents = userRegDocuments;
                                    }
                                    if(req.body.sroOffice === "TIRUMALA"){
                                        users.sroNumber = 7777;
                                    } else if(loginUser.role==='SRO' || loginUser.role==='VR')
                                    {
                                        let officerData = await officerModel.findOne({ _id: ObjectId(loginUser.userId)});
                                        users.sroNumber = officerData.sroNumber;
                                        users.sroOffice = officerData.sroOffice;
                                        if (loginUser.role === 'VR') {
                                            if (users.registrationAddress != "" && users.registrationAddress != null
                                                && users.registrationAddress !== undefined) {
                                                if (users.registrationAddress == "MARRIAGE PLACE")
                                                    users.marriageVillageWard = officerData.villageCode;
                                                else if (users.registrationAddress == "HUSBAND PLACE")
                                                    users.husbandVillageWard = officerData.villageCode;
                                                else if (users.registrationAddress == "WIFE PLACE")
                                                    users.wifeVillageWard = officerData.villageCode;
                                            }
                                            users.villageScretariatCode = officerData.villageScretariatCode;
                                            users.villageScretariatName = officerData.villageScretariatName;
                                            users.villageCode = officerData.villageCode;
                                            users.villageName = officerData.villageName;
                                        }
                                    }
                                    else {
                                        let query ={"districtName":users.district,"sroName": users.sroOffice };
                                        let SRNO = await masterDataModel.findOne(query);
                                        users.sroNumber = SRNO.parentSroCode;
                                    }
                                }
                                
                                if (registrationId) {
                                    let emailBody;
                                    if(users.appNo!=undefined && users.appNo!=null && (users.appNo).indexOf("HM")==-1)
                                    {
                                        let appNumber = users.appNo;
                                        users.appNo = "HM"+users.sroNumber+appNumber;
                                        await paymentReceiptsModel.findOneAndUpdate({departmentTransID:users.transactionId, applicationNumber:appNumber}, { $set: { applicationNumber:users.appNo } });
                                        if(req.body.sentMail) {
                                            emailBody = (req.body.mailMessage).replace(appNumber, users.appNo);
                                        }
                                    }
                                    else
                                        emailBody = req.body.mailMessage;
                                        
                                    delete users.registrationId;
                                    registrationModel.findOneAndUpdate({ _id: registrationId }, { $set: users })
                                        .then(async details =>{
                                            if(users.status=="NEW")
                                            if(users.requestId!=null && users.requestId!=undefined && users.requestId!="")
                                                ssoController.updateStatusToAPSevaWithDetails(users.appNo, "MarrigaeRegistration", "HMR Marriage registration initiated", 1, "SRO");
                                            if(req.body.sentMail ) {
                                                let userDetails;
                                                if(loginUser.loginType!="sso")
                                                    userDetails = await userModel.find({ _id: details.createdBy });
                                                else
                                                    userDetails = await ssoUserModel.find({ _id: details.createdBy });
                                                                           
                                                //await complaintModel.updateMany({ createdAt: { "$lte": fifteenDaysAgo }, complaintStatus: "Submitted", actionUnder: "DR" }, { $set: { actionUnder: "DIG", updatedAt: new Date() } });
                                                let reqObj = {};
                                                reqObj.toMail = userDetails[0].loginEmail;
                                                reqObj.subject = "Hindhu Marriage Registration";
                                                reqObj.message = emailBody;
                                                await mailUtil.sentMail(reqObj);
                                            }
                                            resolve("Registration details updated successfully.")
                                        })
                                        .catch(err => { 
                                            console.log("err :::: ", err);
                                            reject(err);}
                                        );
                                } else {
                                    if(users.appNo!=undefined && users.appNo!=null && (users.appNo).indexOf("HM")==-1)
                                        users.appNo = "HM"+users.sroNumber+users.appNo;
                                    registrationModel.create(users)
                                        .then(details => resolve("Registration details updated successfully."))
                                        .catch(err => { 
                                            console.log("err :::: ", err);
                                            reject(err);}
                                        );
                                }
                            }
                        }catch(err){
                            console.log("Error ::: ", err);
                            reject(err);
                        }
                    }
                }
            }            
        }catch(err){
            console.log("Error ::: ", err);
            reject(err);
        }
    });
}

exports.validateCaste = async (caste,casteType) =>{
    let casteDataObj = await castModel.find({"subCastName":caste}).collation( { locale: 'en', strength: 2 } );
    if(casteDataObj===null || casteDataObj===undefined || casteDataObj.length==0)
    {
        let validationError = {
            message:"Invalid "+casteType+" Selction.",
            status:412,
            Success:false
        }
        return validationError;
    }
    return null;
}

exports.validateCountrySelection = (countryVal, radioCountryVal, message) => {
    let validationError = null;
    if(radioCountryVal=="INDIA" && countryVal!="INDIA")
    {
        validationError = {
            message:message,
            status:412,
            Success:false
        }
    }
    return validationError;
}

exports.validateDistrictAndMandalAndVillage = async (district, mandal, villageCode, addressType) => {
    let findQueryM = {"districtName":district, "mandalName":mandal, "revVillageCode":villageCode};
    let husMasterData = await masterDataModel.find(findQueryM);
    if(husMasterData===null || husMasterData===undefined || husMasterData.length==0)
    {
        let validationError = {
            message:"Invalid District/Mandal/Village selection of "+addressType,
            status:412,
            Success:false
        }
        return validationError;
    }
    return null;
}

exports.getUserList = async (req) => {
    try {
        
        let userData = req.user;
        let query;
        let  slotDateQuery = {
            $lte: moment().format('YYYY-MM-DD')
        }
        let searchvalue = req.query.search;
        let page = req.query.page;
        let limit = req.query.limit;
        let status = req.query.status;
        let regex;
        if(searchvalue!=undefined && searchvalue!=null && searchvalue.length>0)
        {
            searchvalue = searchvalue.split("/").join("\\\/");
            regex = new RegExp("^" + searchvalue, "g");
        }
                
        if(userData.loginType == "officer" && (userData.role=="SRO" || userData.role=="VR") )
        {
            let officerData = await officerModel.findOne({ _id: ObjectId(userData.userId)});
            if(regex!=undefined)
            {
                if(status.toUpperCase()==="COMPLETED")
                {
                    query = {$or:[{husbandName:regex}, {wifeName_beforeMarriage:regex}, {wifeAadhar:regex},{husbandAadhar:regex},
                        {wifeName_afterMarriage:regex}, {documentNumber:regex}, {appNo:regex}], 
                        status: req.query.status, slotDate:slotDateQuery};
                }
                else{
                    query = {$or:[{husbandName:regex}, {wifeName_beforeMarriage:regex},  {wifeAadhar:regex},{husbandAadhar:regex},
                        {wifeName_afterMarriage:regex}, {appNo:regex}], status: req.query.status, 
                        slotDate:slotDateQuery};
                }
            }
            else
                query = { status: req.query.status, slotDate:slotDateQuery};

            if(userData.role==="SRO")
            {
                query["sroNumber"] = officerData.sroNumber;
                //query["villageScretariatCode"] = {"$in":["",null]};
            }
            else if(userData.role==="VR")
            {
                query["$or"] = [{husbandVillageWard:officerData.villageCode}, 
                                {wifeVillageWard:officerData.villageCode}, 
                                {marriageVillageWard:officerData.villageCode}];
                                query["villageScretariatCode"] = officerData.villageScretariatCode;
            }
        }
        else if(userData.loginType == "USER" || userData.loginType == "sso")
        {
            query={createdBy:ObjectId(userData.userId), status:{$nin:["", null]}};
        }
       
        if(query!=undefined)
        {
            let response = [];
            let data;
            if(userData.loginType == "USER" || userData.loginType == "sso")
                data = await registrationModel.find(query).sort({updatedAt: -1});
            else
                data = await registrationModel.find(query).skip(page * limit)
                            .limit(limit).sort({updatedAt: -1});

            const count = await registrationModel.countDocuments(query);
            if(data!=null && data.length>0)
            {
                data.map((d) => {
                    let amOrPm = d.slotTime.replace(/(?:AM|PM)/g, '')
                    let [hrs, rest] = amOrPm.split(":");
                    if (hrs < 9) {
                        hrs = Number(hrs) + 12;
                    }
        
                    let completedDate = new Date(d.updatedAt);
                    let monthVal = (completedDate.getMonth()+1)+"";
                    monthVal = monthVal.length>1?monthVal:("0"+monthVal)
        
                    let dayVal = (completedDate.getDate())+"";
                    dayVal = dayVal.length>1?dayVal:("0"+dayVal)
                    let completedDateString = completedDate.getFullYear()+"-"+monthVal+"-"+dayVal;
        
                    amOrPm = `${hrs}:${rest}`
                    const Obj = {};
                    Obj["totalRecords"] = count;
                    Obj["id"] = d._id;
                    Obj["appNo"] = d.appNo;
                    Obj["status"] = d.status;
                    Obj["husbandName"] = d.husbandName;
                    Obj["wifeName_beforeMarriage"] = d.wifeName_beforeMarriage;
                    Obj["wifeName_afterMarriage"] = d.wifeName_afterMarriage;
                    Obj["change_wifeName_to_afterMarriage"] = d.change_wifeName_to_afterMarriage;
                    Obj["marriageType"] = d.marriageType;
                    Obj["regDate"] = moment(d.regDate).format('DD-MM-YYYY');
                    Obj["slotDate"] = d.slotDate;
                    Obj["slotTime"] = amOrPm;
                    if(d.villageScretariatName && d.villageScretariatName.trim().length>0)
                        Obj["assignedTo"] = "VSWS-"+d.villageScretariatName;
                    else
                        Obj["assignedTo"] = "SRO-"+d.sroOffice;
                    Obj["sroOffice"] = d.sroOffice;
                    Obj["vswsName"] = d.villageScretariatName;
                    Obj["updatedAt"] = moment(completedDateString).format('DD-MM-YYYY');
                    Obj["documentNumber"] = d.documentNumber;
                
                    response = [...response, Obj]
                });
        
                response = await sortBytime(response);
                response.map((t) => {
                    let [hrs, rest] = t.slotTime.split(":");
                    if (hrs > 12) {
                        hrs = Number(hrs) - 12;
                        rest = rest + 'PM';
                    } else {
                        rest = rest + 'AM';
                    }
                    t.slotTime = `${hrs}:${rest}`;
                })
            }
            return response;
        }
        return null;
    } catch (err) {
        console.log("Process Error  ::: ", err);
        return null;
    }
}

async function sortBytime(data) {
    await data.sort((a, b) => {
        if (a.slotDate == b.slotDate) {
            if (Number(a.slotTime.substring(0, 2)) == Number(b.slotTime.substring(0, 2))) {
                const [aRest, aMnts] = a.slotTime.split(": ");
                const [bRest, bMnts] = b.slotTime.split(": ");
                if (aMnts >= bMnts) {
                    return b.slotTime.localeCompare(a.slotTime)
                } else {
                    return a.slotTime.localeCompare(b.slotTime)
                }
            } else {
                return b.slotTime.localeCompare(a.slotTime)
            }
        } else {
            return b.slotDate.localeCompare(a.slotDate)
        }
    });
    return data
}


exports.getValidReg= (req) => {
    
    return new Promise((resolve, reject) => {
        try {
        registrationModel.find({ husbandName:{ $ne: "" }})
            .then(async response => {
                resolve(response);
            })
            .catch(err => reject(err));
        } catch (err) {
            console.log("Process Error" + err.message);
            reject(err);
        }
    });
    
};

exports.officerStatistics = (req) => {
    const reqBody = req.body;
    let pageFrom = reqBody.page;
    let limit = reqBody.limit;
    let searchvalue = reqBody.search;
    let officerId = reqBody.officerId;

    return new Promise(async(resolve, reject) => {
        try{
            let userData = req.user;
            let createdData=await registrationModel.find({created_at:null});
            if(createdData.length>0)
            {
                for (let index = 0; index < createdData.length; index++) {
                    await registrationModel.findOneAndUpdate({_id:createdData[index]._id},{$set:{created_at:createdData[index].createdAt}})
                }
            }
            
            var regex;
            if(searchvalue!=undefined && searchvalue!=null && searchvalue.length>0)
                regex = new RegExp("^" + searchvalue, "g");
            
            let officerData =await officerModel.find({_id:userData.userId});
            let sroList=[];
            let tempSroList;
            if (officerData.length>0){
                if(officerData[0].role =="SRO") {
                    tempSroList = [];
                    let tempSROData = {"totalCount":1, "districtName":officerData[0].sroDistrict,"parentSroCode":officerData[0].sroNumber, 
                                        "sroName":officerData[0].sroOffice};
                    tempSroList.push(tempSROData);
                    sroList.push(parseInt(officerData[0].sroNumber));
                }else if(officerData[0].role =="DR") {
                    let dataListQuery;
                    if(regex)
                        dataListQuery = {districtName:officerData[0].district, sroName:regex, parentSroCode:{$ne:null}}
                    else
                        dataListQuery = {districtName:officerData[0].district, parentSroCode:{$ne:null}}

                    tempSroList= await masterDataModel.aggregate([
                        {"$match" : dataListQuery}, 
                        {"$group" : {_id : {districtName:"$districtName", sroName:"$sroName", parentSroCode:"$parentSroCode"}}}, 
                        {"$project" : {_id:0, districtName:"$_id.districtName", sroName:"$_id.sroName", parentSroCode:"$_id.parentSroCode"}},
                        { "$sort" : { districtName:1, sroName : 1 } },
                        {$setWindowFields: {output: {totalCount: {$count: {}}}}},
                        { "$skip" : (limit * pageFrom) },
                        {"$limit": limit }]);
                    sroList = [...new Set(tempSroList.map(item => parseInt(item["parentSroCode"])))];
                }else if(officerData[0].role =="DIG") {
                    let dataListQuery;
                    if(regex)
                        dataListQuery = {$or:[{sroName:regex}, {districtName:regex}], districtName:{$in:officerData[0].subDistrict}, parentSroCode:{$ne:null}}
                    else
                        dataListQuery = {districtName:{$in:officerData[0].subDistrict}, parentSroCode:{$ne:null}}

                    tempSroList= await masterDataModel.aggregate([
                        {"$match" : dataListQuery}, 
                        {"$group" : {_id : {districtName:"$districtName", sroName:"$sroName", parentSroCode:"$parentSroCode"}}}, 
                        {"$project" : {_id:0, districtName:"$_id.districtName", sroName:"$_id.sroName", parentSroCode:"$_id.parentSroCode"}},
                        { "$sort" : { districtName:1, sroName : 1 } },
                        {$setWindowFields: {output: {totalCount: {$count: {}}}}},
                        { "$skip" : (limit * pageFrom) },
                        {"$limit": limit }]);
                    sroList = [...new Set(tempSroList.map(item => parseInt(item["parentSroCode"])))];
                }else if(officerData[0].role =="IG") {
                    let dataListQuery;
                    if(regex)
                        dataListQuery = {$or:[{sroName:regex}, {districtName:regex}], parentSroCode:{$ne:null}}
                    else
                        dataListQuery = {parentSroCode:{$ne:null}}
                        
                    tempSroList= await masterDataModel.aggregate([
                        {"$match" : dataListQuery}, 
                        {"$group" : {_id : {districtName:"$districtName", sroName:"$sroName", parentSroCode:"$parentSroCode"}}}, 
                        {"$project" : {_id:0, districtName:"$_id.districtName", sroName:"$_id.sroName", parentSroCode:"$_id.parentSroCode"}},
                        { "$sort" : { districtName:1, sroName : 1 } },
                        {$setWindowFields: {output: {totalCount: {$count: {}}}}},
                        { "$skip" : (limit * pageFrom) },
                        {"$limit": limit }]);
                    sroList = [...new Set(tempSroList.map(item => parseInt(item["parentSroCode"])))];
                }
            }

            let finalResult=[];
            if(tempSroList!=undefined && tempSroList.length>0)
            {
                let  slotDateQuery = {
                    $lte: moment().format('YYYY-MM-DD')
                }

                let numOfDays = reqBody.noOfDays;
                const fromDate = new Date();
                fromDate.setDate(fromDate.getDate()-numOfDays);
                                
                let totalMatchCondition = {sroNumber : {$in:sroList}, slotDate:slotDateQuery, status:{$nin:["DRAFT", "", null]}};
                if(numOfDays!="0")
                    totalMatchCondition['created_at'] = {$gte: fromDate};

                //console.log("totalMatchCondition ::::: ", JSON.stringify(totalMatchCondition));
                let totalResults = await registrationModel.aggregate([
                    {"$match": totalMatchCondition},
                    {"$group": {_id:{sroOffice:"$sroOffice", sroNumber:"$sroNumber", district:"$district"}, count:{$sum:1}}},
                ]);

                //console.log(" totalResults ::: ", totalResults);

                let statusWiseMatchCondition = {sroNumber : {$in:sroList}, status:{$in:["PENDING", "COMPLETED"]}, slotDate:slotDateQuery};
                if(numOfDays!="0")
                    statusWiseMatchCondition['created_at'] = {$gte: fromDate};
                
                //console.log("statusWiseMatchCondition ::::: ", JSON.stringify(statusWiseMatchCondition));
                let statusWiseResults = await registrationModel.aggregate([
                    {"$match": statusWiseMatchCondition},
                    {"$group": {_id:{sroOffice:"$sroOffice",status:"$status", sroNumber:"$sroNumber", district:"$district"}, count:{$sum:1}}},
                ]);

                //console.log(" statusWiseResults ::: ", statusWiseResults);
                                    
                tempSroList.forEach(reusltData => {
                    let sroNumberVal = reusltData.parentSroCode;

                    let tempObj= {};
                    tempObj.sroName=reusltData.sroName;
                    tempObj.totalRecords=reusltData.totalCount;
                    tempObj.sroNumber=sroNumberVal;
                    tempObj.created=0;
                    tempObj.completed=0;
                    tempObj.pending=0;
                    tempObj.district=reusltData.districtName;
                    if(totalResults.length>0)
                    {
                        totalResults.forEach(totalResultData => {
                            if((totalResultData._id.sroNumber)==parseInt(sroNumberVal))
                            {
                                tempObj.created=totalResultData.count;
                                return false;
                            }
                        });
                        if(statusWiseResults.length>0)
                        {
                            statusWiseResults.forEach(statusWiseResultData => {
                                if(statusWiseResultData._id.sroNumber==parseInt(sroNumberVal))
                                {
                                    if(statusWiseResultData._id.status=="PENDING")
                                        tempObj.pending=statusWiseResultData.count;
                                    else if(statusWiseResultData._id.status=="COMPLETED")
                                        tempObj.completed=statusWiseResultData.count;
                                }
                                if(tempObj.pending>0 && tempObj.completed>0)
                                {
                                    if((tempObj.pending+tempObj.completed>tempObj.created))
                                        tempObj.created = tempObj.pending+tempObj.completed;
                                    return false;
                                }
                            });
                        }
                    }
                    finalResult.push(tempObj);
                });
            } 
            resolve(finalResult);
        } catch (err) {
            console.log(" error ::: ", err);
            reject(err);
        }
    });
};


exports.getStatisticDetails= (req) => {
        return new Promise(async(resolve, reject) => {
        try {
            const fromDate = new Date();
            fromDate.setDate(fromDate.getDate()-(req.body.noOfDays));

            let userData = req.user;
            let query;
                      
            if(userData.loginType == "officer")
            {
                let sroNumber = parseInt(req.body.sroNumber);
                let officerData = await officerModel.findOne({ _id: ObjectId(userData.userId)});
                if(userData.role=="SRO" && officerData.sroNumber!=sroNumber)
                    reject("Invalid data access.");
                else
                {
                    if (req.body.status!="CREATED") 
                    {
                        if(userData.role=="SRO")
                            query = { status: req.body.status, sroNumber: officerData.sroNumber};
                        else if(userData.role=="DR")
                            query = { status: req.body.status, sroNumber: sroNumber, district:  officerData.district};
                        else if(userData.role=="DIG")
                            query = { status: req.body.status, sroNumber: sroNumber, district: {$in : officerData.subDistrict}};
                        else if(userData.role=="IG")
                            query = { status: req.body.status, sroNumber: sroNumber};
                    }
                    else
                    {
                        if(userData.role=="SRO")
                            query = { sroNumber: officerData.sroNumber, status:{$nin:["DRAFT", "", null]}};
                        else if(userData.role=="DR")
                            query = { sroNumber: sroNumber, district:  officerData.district, status:{$nin:["DRAFT", "", null]}};
                        else if(userData.role=="DIG")
                            query = { sroNumber: sroNumber, district: {$in : officerData.subDistrict, status:{$nin:["DRAFT", "", null]}}};
                        else if(userData.role=="IG")
                            query = { sroNumber: sroNumber, status:{$nin:["DRAFT", "", null]}};
                    }

                    if(req.body.noOfDays!="0")
                        query["created_at"]={ $gte: fromDate };

                    let  slotDateQuery = {
                        $lte: moment().format('YYYY-MM-DD')
                    }
                    query['slotDate']=slotDateQuery;
                    const data = await registrationModel.find(query)
                    let response = [];
                    data.map((d) => {
                        let amOrPm = d.slotTime.replace(/(?:AM|PM)/g, '')
                        let [hrs, rest] = amOrPm.split(":");
                        if (hrs < 9) {
                            hrs = Number(hrs) + 12;
                        }
                        amOrPm = `${hrs}:${rest}`
                        const Obj = {};
                        Obj["id"] = d._id;
                        Obj["appNo"] = d.appNo;
                        Obj["status"] = d.status;
                        Obj["husbandName"] = d.husbandName;
                        Obj["wifeName_beforeMarriage"] = d.wifeName_beforeMarriage;
                        Obj["wifeName_afterMarriage"] = d.wifeName_afterMarriage;
                        Obj["change_wifeName_to_afterMarriage"] = d.change_wifeName_to_afterMarriage;
                        Obj["marriageType"] = d.marriageType;
                        Obj["regDate"] = moment(d.regDate).format('DD-MM-YYYY');
                        Obj["slotDate"] = moment(d.slotDate).format('DD-MM-YYYY');
                        Obj["slotTime"] = amOrPm;
                        if(d.villageScretariatName && d.villageScretariatName.trim().length>0)
                        Obj["assignedTo"] = "VSWS-"+d.villageScretariatName;
                        else
                        Obj["assignedTo"] = "SRO-"+d.sroOffice;
                        Obj["sroOffice"] = d.sroOffice;
                        response = [...response, Obj]
                    });

                    response = await sortBytime(response);
                    response.map((t) => {
                        let [hrs, rest] = t.slotTime.split(":");
                        if (hrs > 12) {
                            hrs = Number(hrs) - 12;
                            rest = rest + 'PM';
                        } else {
                            rest = rest + 'AM';
                        }
                        t.slotTime = `${hrs}:${rest}`;
                    })
                    resolve(response);
                }
            }
            else
                reject("Invalid data access.");
        } catch (err) {
            console.log("Process Error", err);
                reject(err);
        }
    });
};


exports.officerStatisticsdistrictdata = (req) => {
    const reqBody = req.body;
    let searchvalue = reqBody.search;
    return new Promise(async (resolve, reject) => {
        try {
            let userData = req.user;
            var regex;
            if (searchvalue != undefined && searchvalue != null && searchvalue.length > 0)
                regex = new RegExp("^" + searchvalue, "g");
            let officerData = await officerModel.find({ _id: userData.userId });
            if (officerData.length > 0) {
                let dataListQuery;
                let slotDateQuery = { $lte: moment().format('YYYY-MM-DD') }
                if (officerData[0].role == "DR") {
                    dataListQuery = { husbandDistrict: officerData[0].district, slotDate: slotDateQuery, status:{$ne:"DRAFT"} }
                } else if (officerData[0].role == "DIG") {
                    if (regex)
                        dataListQuery = { husbandDistrict: regex, husbandDistrict: { $in: officerData[0].subDistrict }, slotDate: slotDateQuery, status:{$ne:"DRAFT"} };
                    else
                        dataListQuery = { husbandDistrict: { $in: officerData[0].subDistrict }, slotDate: slotDateQuery, status:{$ne:"DRAFT"} };
                } else if (officerData[0].role == "IG") {
                    if (regex)
                        dataListQuery = {husbandName:{"$ne":""}, husbandDistrict: regex, slotDate: slotDateQuery, status:{$ne:"DRAFT"}}
                    else
                        dataListQuery = {husbandName:{"$ne":""}, slotDate: slotDateQuery, status:{$ne:"DRAFT"}};
                }

                if (dataListQuery != undefined) {
                    let tempDistrictList = await registrationModel.aggregate([
                        { "$match": dataListQuery },
                        { "$group": { _id: { husbandDistrict: "$husbandDistrict" }, count: { $sum: 1 } } },
                        { "$project": { _id: 0, districtName: "$_id.husbandDistrict", created: "$count" } },
                        { "$sort": { districtName: 1 } },
                        { $setWindowFields: { output: { totalCount: { $count: {} } } } }
                    ]);
                    dataListQuery["status"] = { $in: ["PENDING", "COMPLETED"] };
                    let statusWiseResults = await registrationModel.aggregate([
                        { "$match": dataListQuery },
                        { "$group": { _id: { status: "$status", district: "$husbandDistrict" }, count: { $sum: 1 } } }
                    ]);
                    let finalResult = [];
                    if (tempDistrictList != undefined && tempDistrictList.length > 0) {
                        tempDistrictList.forEach(reusltData => {
                            let tempObj = {};
                            tempObj.totalRecords = reusltData.totalCount;
                            tempObj.created = reusltData.created;
                            tempObj.completed = 0;
                            tempObj.pending = 0;
                            if(reusltData.districtName.trim().length==0)
                                tempObj.district = "OTHERS";
                            else
                                tempObj.district = reusltData.districtName;
                            if (statusWiseResults.length > 0) {
                                statusWiseResults.forEach(statusWiseResultData => {
                                    if ((statusWiseResultData._id.district) == (reusltData.districtName)) {
                                        if (statusWiseResultData._id.status == "PENDING")
                                            tempObj.pending = statusWiseResultData.count;
                                        else if (statusWiseResultData._id.status == "COMPLETED")
                                            tempObj.completed = statusWiseResultData.count;
                                    }
                                    if (tempObj.pending > 0 && tempObj.completed > 0) {
                                        if ((tempObj.pending + tempObj.completed) > tempObj.created)
                                            tempObj.created = tempObj.pending + tempObj.completed;
                                        return false;
                                    }
                                });
                            }
                            finalResult.push(tempObj);
                        });
                    }
                    resolve(finalResult);
                } else {
                    reject("Unauthorised user to access.");
                }
            }
        } catch (err) {
            console.log(" error ::: ", err);
            reject(err);
        }
    });
};

exports.officerStatisticsMandaldata = (req) => {
    const reqBody = req.body;
    let searchvalue = reqBody.search;
    let districtVal=reqBody.district;
    return new Promise(async (resolve, reject) => {
        try {
            let userData = req.user;
            var regex;
            if (searchvalue != undefined && searchvalue != null && searchvalue.length > 0)
                regex = new RegExp("^" + searchvalue, "g");
            let officerData = await officerModel.find({ _id: userData.userId });
            if (officerData.length > 0) {
                let slotDateQuery = { $lte: moment().format('YYYY-MM-DD') }
                let dataListQuery;
                let isValidCondition = false
                if (officerData[0].role == "DR") {
                    if(officerData[0].district===districtVal)
                        isValidCondition = true;
                } else if (officerData[0].role == "DIG") {
                    if(officerData[0].subDistrict.includes(districtVal))
                        isValidCondition = true;
                } else if (officerData[0].role == "IG") 
                    isValidCondition = true;
                
                if(isValidCondition)
                {
                    dataListQuery = { husbandDistrict: districtVal, slotDate: slotDateQuery, status:{$ne:"DRAFT"} };
                    if (regex)
                        dataListQuery["husbandMandal"]=regex;                    
                }
                
                if (dataListQuery != undefined) {
                    let tempDistrictList = await registrationModel.aggregate([
                        { "$match": dataListQuery },
                        { "$group": { _id: { husbandDistrict: "$husbandDistrict",husbandMandal:"$husbandMandal" }, count: { $sum: 1 } } },
                        { "$project": { _id: 0, districtName: "$_id.husbandDistrict",mandalName:"$_id.husbandMandal", created: "$count" } },
                        { "$sort": { districtName: 1 ,mandalName: 1} },
                        { $setWindowFields: { output: { totalCount: { $count: {} } } } }
                    ]);
                    dataListQuery["status"] = { $in: ["PENDING", "COMPLETED"] };
                    let statusWiseResults = await registrationModel.aggregate([
                        { "$match": dataListQuery },
                        { "$group": { _id: { status: "$status", district: "$husbandDistrict",mandal:"$husbandMandal" }, count: { $sum: 1 } } }
                    ]);
                    let finalResult = [];
                    if (tempDistrictList != undefined && tempDistrictList.length > 0) {
                        tempDistrictList.forEach(reusltData => {
                            let tempObj = {};
                            tempObj.totalRecords = reusltData.totalCount;
                            tempObj.created = reusltData.created;
                            tempObj.completed = 0;
                            tempObj.pending = 0;
                            tempObj.mandal=reusltData.mandalName;
                            tempObj.district = reusltData.districtName;
                            if (statusWiseResults.length > 0) {
                                statusWiseResults.forEach(statusWiseResultData => {
                                    if ((statusWiseResultData._id.mandal) === (reusltData.mandalName)) {
                                        if (statusWiseResultData._id.status == "PENDING")
                                            tempObj.pending = statusWiseResultData.count;
                                        else if (statusWiseResultData._id.status == "COMPLETED")
                                            tempObj.completed = statusWiseResultData.count;
                                    }
                                    if (tempObj.pending > 0 && tempObj.completed > 0) {
                                        if ((tempObj.pending + tempObj.completed) > tempObj.created)
                                            tempObj.created = tempObj.pending + tempObj.completed;
                                        return false;
                                    }
                                });
                            }
                            finalResult.push(tempObj);
                        });
                    }
                    resolve(finalResult);
                } else {
                    reject("Unauthorised user to access.");
                }
            }
        } catch (err) {
            console.log(" error ::: ", err);
            reject(err);
        }
    });
};

exports.officerStatisticsvillagedata = (req) => {
    const reqBody = req.body;
    let searchvalue = reqBody.search;
    let districtVal=reqBody.district;
    let mandalVal=reqBody.mandal;
    return new Promise(async (resolve, reject) => {
        try {
            let userData = req.user;
            var regex;
            if (searchvalue != undefined && searchvalue != null && searchvalue.length > 0)
                regex = new RegExp("^" + searchvalue, "g");
            let officerData = await officerModel.find({ _id: userData.userId });
            if (officerData.length > 0) {
                let dataListQuery;
                let slotDateQuery = { $lte: moment().format('YYYY-MM-DD') }
                let isValidCondition = false
                if (officerData[0].role == "DR") {
                    if(officerData[0].district===districtVal)
                        isValidCondition = true;
                } else if (officerData[0].role == "DIG") {
                    if(officerData[0].subDistrict.includes(districtVal))
                        isValidCondition = true;
                } else if (officerData[0].role == "IG") 
                    isValidCondition = true;

                if(isValidCondition)
                {
                    dataListQuery = {husbandDistrict: districtVal, husbandMandal:mandalVal, slotDate: slotDateQuery, status:{$ne:"DRAFT"}};
                    if (regex)
                        dataListQuery["husbandVillageWard"]=regex;                    
                }

                if (dataListQuery != undefined) {

                    let tempDistrictList = await registrationModel.aggregate([
                        { "$match": dataListQuery },
                        { "$group": { _id: { husbandDistrict: "$husbandDistrict",husbandMandal:"$husbandMandal",husbandVillageWard:"$husbandVillageWard" }, count: { $sum: 1 } } },
                        { "$project": { _id: 0, districtName: "$_id.husbandDistrict",mandalName:"$_id.husbandMandal",husbandVillageWard:"$_id.husbandVillageWard" ,created: "$count" } },
                        { "$sort": { districtName: 1 ,mandalName: 1,husbandVillageWard:1} },
                        { $setWindowFields: { output: { totalCount: { $count: {} } } } }
                    ]);

                    dataListQuery["status"] = { $in: ["PENDING", "COMPLETED"] };

                    let statusWiseResults = await registrationModel.aggregate([
                        { "$match": dataListQuery },
                        { "$group": { _id: { status: "$status", district: "$husbandDistrict",mandal:"$husbandMandal",husbandVillageWard:"$husbandVillageWard" }, count: { $sum: 1 } } }
                    ]);

                    let villageWardList = [];
                    tempDistrictList.forEach(reusltData => {
                        villageWardList.push(reusltData.husbandVillageWard);
                    });

                    let villageWardResult=await masterDataModel.find({revVillageCode:{$in:villageWardList}},{revVillageCode:1,villageName:1})
                    let villageDetails = {};
                    villageWardResult.forEach(villageData => {
                      villageDetails[villageData.revVillageCode] = villageData.villageName
                    });
                    let finalResult = [];
                    if (tempDistrictList != undefined && tempDistrictList.length > 0) {
                        
                        tempDistrictList.forEach(reusltData => {
                            let villageVal = villageDetails[reusltData.husbandVillageWard];
                            let tempObj = {};
                            tempObj.totalRecords = reusltData.totalCount;
                            tempObj.created = reusltData.created;
                            tempObj.completed = 0;
                            tempObj.pending = 0;
                            tempObj.mandal = reusltData.mandalName;
                            tempObj.district = reusltData.districtName;
                            tempObj.village = villageVal;
                            tempObj.villageWard = reusltData.husbandVillageWard;

                            if (statusWiseResults.length > 0) {
                                statusWiseResults.forEach(statusWiseResultData => {
                                    if ((statusWiseResultData._id.husbandVillageWard) === (reusltData.husbandVillageWard)) {
                                        if (statusWiseResultData._id.status == "PENDING")
                                            tempObj.pending = statusWiseResultData.count;
                                        else if (statusWiseResultData._id.status == "COMPLETED")
                                            tempObj.completed = statusWiseResultData.count;
                                    }

                                    if (tempObj.pending > 0 && tempObj.completed > 0) {
                                        if ((tempObj.pending + tempObj.completed) > tempObj.created)
                                            tempObj.created = tempObj.pending + tempObj.completed;
                                        return false;
                                    }
                                });
                            }
                            finalResult.push(tempObj);
                        });
                    }
                    resolve(finalResult);
                } else {
                    reject("Unauthorised user to access.");
                }
            }
        } catch (err) {
            console.log(" error ::: ", err);
            reject(err);
        }
    });
};

exports.getRegistrationsByStatisticValues = (req) => {
    return new Promise(async (resolve, reject) => {
        try {
            let userData = req.user;
            let query;

            if (userData.loginType == "officer" && userData.role != "SRO" && userData.role != "VR") 
            {    
                let districtVal = req.body.district;
                let mandalVal = req.body.mandal;
                let villageWardVal = req.body.villageWard;
                let statusVal = req.body.status;

                if(districtVal!=undefined && districtVal!=null && districtVal.trim().length>0
                     && statusVal!=undefined && statusVal!=null && statusVal.trim().length>0)
                {
                    if(districtVal=="OTHERS")
                        districtVal = "";
                
                    let officerData = await officerModel.findOne({ _id: ObjectId(userData.userId) });

                    if (statusVal != "CREATED") {
                        if (officerData.role == "DR" && (officerData.district==districtVal))
                            query = { status: statusVal, husbandDistrict: districtVal };
                        
                        else if (userData.role == "DIG" && officerData.subDistrict.includes(districtVal))
                            query = { status: statusVal, husbandDistrict: districtVal };
                        
                        else if (userData.role == "IG")
                            query = { status: statusVal, husbandDistrict: districtVal };
                    }
                    else {
                        if (userData.role == "DR" && (officerData.district==districtVal))
                            query = { status: {$in:["PENDING", "NEW", "COMPLETED"]}, husbandDistrict: districtVal };

                        else if (userData.role == "DIG" && officerData.subDistrict.includes(districtVal))
                            query = { status: {$in:["PENDING", "NEW", "COMPLETED"]}, husbandDistrict: districtVal };

                        else if (userData.role == "IG")
                            query = { status: {$in:["PENDING", "NEW", "COMPLETED"]}, husbandDistrict: districtVal };
                    }

                    if(query!=undefined)
                    {
                        let slotDateQuery = {
                            $lte: moment().format('YYYY-MM-DD')
                        }
                        query['slotDate'] = slotDateQuery;
                        
                        if(mandalVal!=undefined && mandalVal!=null)
                            query['husbandMandal'] = mandalVal;

                        if(villageWardVal!=undefined && villageWardVal!=null)
                            query['husbandVillageWard'] = villageWardVal;
        
                        const data = await registrationModel.find(query)
                        let response = [];
                        data.map((d) => {
                            let amOrPm = d.slotTime.replace(/(?:AM|PM)/g, '')
                            let [hrs, rest] = amOrPm.split(":");
                            if (hrs < 9) {
                                hrs = Number(hrs) + 12;
                            }
                            amOrPm = `${hrs}:${rest}`
                            const Obj = {};
                            Obj["id"] = d._id;
                            Obj["appNo"] = d.appNo;
                            Obj["status"] = d.status;
                            Obj["husbandName"] = d.husbandName;
                            Obj["wifeName_beforeMarriage"] = d.wifeName_beforeMarriage;
                            Obj["wifeName_afterMarriage"] = d.wifeName_afterMarriage;
                            Obj["change_wifeName_to_afterMarriage"] = d.change_wifeName_to_afterMarriage;
                            Obj["marriageType"] = d.marriageType;
                            Obj["regDate"] = moment(d.regDate).format('DD-MM-YYYY');
                            Obj["slotDate"] = moment(d.slotDate).format('DD-MM-YYYY');
                            Obj["slotTime"] = amOrPm;
                            if(d.villageScretariatName && d.villageScretariatName.trim().length>0)
                            Obj["assignedTo"] = "VSWS-"+d.villageScretariatName;
                            else
                            Obj["assignedTo"] = "SRO-"+d.sroOffice;
                            Obj["sroOffice"] = d.sroOffice;
                            response = [...response, Obj]
                        });
        
                        response = await sortBytime(response);
                        response.map((t) => {
                            let [hrs, rest] = t.slotTime.split(":");
                            if (hrs > 12) {
                                hrs = Number(hrs) - 12;
                                rest = rest + 'PM';
                            } else {
                                rest = rest + 'AM';
                            }
                            t.slotTime = `${hrs}:${rest}`;
                        })
                        resolve(response);
                    }else
                        reject("Invalid data access.");
                }else
                    reject("Bad Request.");
            }
            else
                reject("Invalid data access.");
        } catch (err) {
            console.log("Process Error", err);
            reject(err);
        }
    });
};

exports.removeBalnkRegistrations =  async ()=> {
    let responseJson = {};
    console.log("Inside of removeBalnkRegistrations ::: ");
    try {
        const currentDate = new Date();
        currentDate.setDate(currentDate.getDate()-1);
        let deletedData = await registrationModel.deleteMany({ created_at:{$lte: currentDate}, status:{$in:["", null]}, husbandName:{$in:["", null]} });
        responseJson["message"] = "Blank registrations have been deleted successfully.";
        responseJson["status"] = "Success";
        responseJson["deletedCount"] = deletedData.deletedCount;
        responseJson["tillDate"] = currentDate;
    } catch (error) {
        responseJson["message"] = error.message;
        responseJson["status"] = "Failure";
        console.log("Error in removeBalnkRegistrations ::: ", error);
    }
    console.log("End of removeBalnkRegistrations ::: ");
    return responseJson;
};


exports.removeOldOTPsAndTokens =  async ()=> {
    let responseJson = {};
    console.log("Inside of removeOldOTPsAndTokens ::: ");
    try {
        const currentDate = new Date();
        currentDate.setDate(currentDate.getDate()-1);
        let otpDeletedData = await otpModel.deleteMany({ updatedAt:{$lte: currentDate} });
        let otpDeletedData1 = await otpModel.deleteMany({ updatedAt:null });
        let tokenDeletedData = await tokenModel.deleteMany({ updatedAt:{$lte: currentDate} });
        //let tokenDeletedData1 = await tokenModel.deleteMany({ updatedAt:null });
        responseJson["message"] = "Old Tokens and OTPs have been deleted successfully.";
        responseJson["status"] = "Success";
        responseJson["deletedCount"] = "OTP : "+(otpDeletedData.deletedCount+ otpDeletedData1.deletedCount)+", Tokens: "+tokenDeletedData.deletedCount;
        responseJson["tillDate"] = currentDate;
    } catch (error) {
        responseJson["message"] = error.message;
        responseJson["status"] = "Failure";
        console.log("Error in removeOldOTPsAndTokens ::: ", error);
    }
    console.log("End of removeOldOTPsAndTokens ::: ");
    return responseJson;
};

