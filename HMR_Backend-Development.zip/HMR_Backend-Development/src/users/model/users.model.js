const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new mongoose.Schema({
    loginId: { type: String, default: "" },
    loginName: { type: String, default: "" },
    loginEmail: { type: String, default: "" },
    loginMobile: { type: String, default: "" },
    loginPassword: { type: String, default: "" },
    loginRPassword: { type: String, default: "" },
    loginType: { type: String, default: "" },
    createdAt: { type: String, default: Date.now },
    updatedAt: { type: String, default: "" },
    status: { type: String, default: "" },
    isValidated:{ type: Boolean, default: false },
    otp:{type:String,default:""},
    lastLogin:{type: String},
    loginAttemptsLeft: { type: Number, default: 5 },
    loginBlockedUntil: { type: Date, default: null },
},{timestamps:true})


module.exports = mongoose.model("users", userSchema);
