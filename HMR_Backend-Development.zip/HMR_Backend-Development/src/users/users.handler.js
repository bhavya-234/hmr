const service = require('./users.controller');
const { Handler } = require('../common/requestHandler');

//FORMAT:  exports.<action>=(req,res)=>Handler(req,res,service.<function>,<successMessage>,<failMessage>);
//exports.getUserAll = (req, res) => { Handler(req, res, service.getUserAll, 'Success', 'User Details access failed') }
exports.logout= (req, res) => { Handler(req.params.id, res, service.logout, 'Success', 'User Details access failed') }
exports.getUserById = (req, res) => { Handler(req.params.id, res, service.getUserById, 'Success', 'User Details access failed') }
exports.saveUser = (req, res) => { Handler(req, res, service.saveUser, 'Success', 'Save Failed'); }
exports.saveRegistrationAsDraft = (req, res) => { Handler(req, res, service.saveRegistrationAsDraft, 'Success', 'Save Failed'); }
exports.getUserList= (req, res) =>  { Handler(req, res, service.getUserList, 'Success', 'User Details access failed') }
exports.singup= (req, res) =>  { Handler(req, res, service.singup, 'Success', 'User signup failed') }
exports.login= (req, res) =>  { Handler(req, res, service.login, 'Success', 'User login failed') }
exports.forgotPassword= (req, res) =>  { Handler(req, res, service.forgotPassword, 'Success', 'User login failed') }
exports.fileUpload= (req, res) =>  { Handler(req, res, service.fileUpload, 'Success', 'Upload failed') }
exports.resetPassword= (req, res) =>  { Handler(req, res, service.resetPassword, 'Success', 'Upload failed') }
exports.resetPasswordByMail= (req, res) =>  { Handler(req, res, service.resetPasswordByMail, 'Success', 'Upload failed') }
exports.getUserByAppNo= (req, res) =>  { Handler(req, res, service.getUserByAppNo, 'Success', 'Upload failed') }
exports.getCertificateRequestsbyAppNo= (req, res) =>  { Handler(req, res, service.getCertificateRequestsbyAppNo, 'Success', 'Upload failed') }
exports.UpdateCertitificateRequestDatabySRO= (req, res) =>  { Handler(req, res, service.UpdateCertitificateRequestDatabySRO, 'Success', 'Upload failed') }
//exports.validateOtp= (req, res) =>  { Handler(req, res, service.validateOtp, 'Success', 'Upload failed') }
exports.emailVerification= (req, res) =>  { Handler(req, res, service.emailVerification, 'Success', 'Upload failed') }
//exports.registrationOtpValidation= (req, res) =>  { Handler(req, res, service.registrationOtpValidation, 'Success', 'Upload failed') }
exports.sampleRegistration= (req, res) =>  { Handler(req, res, service.sampleRegistration, 'Success', 'creation failed') }
exports.getValidReg= (req, res) =>  { Handler(req, res, service.getValidReg, 'Success', 'creation failed') }
exports.officerStatistics= (req, res) =>  { Handler(req, res, service.officerStatistics, 'Success', 'creation failed') }
exports.getStatisticDetails= (req, res) =>  { Handler(req, res, service.getStatisticDetails, 'Success', 'creation failed') }

exports.officerStatisticsMandaldata= (req, res) => { Handler(req, res, service.officerStatisticsMandaldata, 'Success', 'creation failed') }
exports.officerStatisticsvillagedata= (req, res) => { Handler(req, res, service.officerStatisticsvillagedata, 'Success', 'creation failed') }
exports.officerStatisticsdistrictdata= (req, res) => { Handler(req, res, service.officerStatisticsdistrictdata, 'Success', 'creation failed') }
exports.getRegistrationsByStatisticValues=(req, res) => { Handler(req, res, service.getRegistrationsByStatisticValues, 'Success', 'Failure') }
exports.GetRevenueDetailsofHMR=(req, res) => { Handler(req, res, service.GetRevenueDetailsofHMR, 'Success', 'Failure') }
