const express = require('express')
const handler = require('./users.handler');
const fileUpload = require('../common/fileUpload');
const jwt = require('../services/auth.service');
const userController = require('./users.controller');
const router = express.Router();

const cron = require('node-cron');

router.get('/health-check',(req,res)=> {
    res.send("ok with users")
})
router.get('/GetRevenueDetailsofHMR',[handler.GetRevenueDetailsofHMR])
router.get('/userbyAppNo/:id', jwt.verifyUserjwt, [handler.getUserByAppNo]);
router.get('/certificateRequestsbyAppNo/:id', jwt.verifyUserjwt, [handler.getCertificateRequestsbyAppNo]);
router.get('/userById/:id', jwt.verifyjwt,  [handler.getUserById]);
router.post('/saveUser',jwt.verifyUserjwt, [handler.saveUser]);
router.post('/registrationDraftSave',jwt.verifyUserjwt, [handler.saveRegistrationAsDraft]);
router.put('/UpdateCertitificateRequestDatabySRO/:id',jwt.verifyOfficerJwt, [handler.UpdateCertitificateRequestDatabySRO]);

router.get('/getUserRegistrations',jwt.verifyUserjwt,[handler.getUserList]);
router.get('/getUserList',jwt.verifyOfficerJwt,[handler.getUserList]);
router.post('/signup', userController.singup);
router.post('/login', userController.login);
router.post('/forgotPassword', userController.forgotPassword);
router.post('/resetPassword',jwt.verifyOfficerJwt, [handler.resetPassword]);
router.post('/resetPasswordByMail', userController.resetPasswordByMail);
router.post('/:otpType/otpValidation', userController.otpValidation);
router.get('/tokenInvalidate', jwt.tokenInvalidate, userController.logout);
//router.post('/verifyOtp/', [handler.validateOtp]);
//router.post('/registrationOtpValidation', [handler.registrationOtpValidation]);

router.delete('/removeFileUpload/:appNo/:fileName', jwt.verifyUserjwt, userController.removeFileUploadByAppNoAndFileName);
router.post('/fileUpload/:registrationId/:fileName', jwt.verifyUserjwt, fileUpload.uploadStore.fields([
        { name: 'image' }]), [handler.fileUpload]);

router.post('/emailVerification', userController.emailVerification);
router.get('/sampleRegistration', jwt.verifyUserjwt, [handler.sampleRegistration]);
router.get('/getValidReg', [handler.getValidReg]);
router.get('/token',jwt.refreshToken);
router.post('/officerStatistics', jwt.verifyOfficerJwt, [handler.officerStatistics]);
router.post('/getRegistrationByDate', jwt.verifyOfficerJwt,  [handler.getStatisticDetails]);
router.post('/officerStatisticsMandaldata', jwt.verifyOfficerJwt, [handler.officerStatisticsMandaldata]);
router.post('/officerStatisticsdistrictdata', jwt.verifyOfficerJwt, [handler.officerStatisticsdistrictdata]);
router.post('/officerStatisticsvillagedata', jwt.verifyOfficerJwt, [handler.officerStatisticsvillagedata]);
router.post('/getRegistrationsByStatisticValues', jwt.verifyOfficerJwt, [handler.getRegistrationsByStatisticValues]);


//Below one will execute every day midnight
cron.schedule('0 0 0 * * *', async () => {
    let result = await userController.removeBalnkRegistrations();
    console.log("cron job execution status of blank reg ::: ", result);
    result = await userController.removeOldOTPsAndTokens();
    console.log("cron job execution status of old OTPs and Tokens ::: ", result);
});



//Below one will execute every January 1st 0hr 0minuts and 0second
cron.schedule('0 0 0 1 January *', async () => {
    //let result = await userController.removeBalnkRegistrations();
    console.log("cron job execution status ::: ", result);
});


/*
//Below one will execute for every minute
cron.schedule('0 * * * * *', async () => {
    let result = await userController.removeBalnkRegistrations();
    console.log("cron job execution status of blank reg ::: ", result);
    result = await userController.removeOldOTPsAndTokens();
    console.log("cron job execution status of old OTPs and Tokens ::: ", result);
});
*/

module.exports = router;
