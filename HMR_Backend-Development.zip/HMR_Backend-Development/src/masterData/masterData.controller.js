const masterModel = require('./model/masterData.model');
const jwt = require('../services/auth.service');
const fs = require("fs");
const path = require("path");
const officerModel = require('../officer/model/officer.model');
const dbHelper = require('../utils/helper');
const sysConstant = require('../utils/sysConstanst')
exports.masterData = (req) => {
    return new Promise((resolve, reject) => {
        try {
        let filepath = path.join(__dirname, "./state_data.json");
        const jsonString = fs.readFileSync(filepath);
        const customer = JSON.parse(jsonString);
        masterModel.create(customer)
            .then(response => {
                resolve("Data added");
            }).catch(err => reject(err));
        } catch (err) {
            console.log("Process Error", err);
            reject(err);
        }
    });
};

exports.getCategories = (req) => {
    
    let reqKey;
    
    if (req.query.state && req.query.district){
        reqKey ="mandalName";
    }else {
        reqKey ="districtName";
    }
    return new Promise(async (resolve, reject) => {
        try {
            let groupBYQuery = { };
            let projectQuery = { _id: 0};
            let matchCondition = {};
            let sortCondition = {};
            if(reqKey=="mandalName")
            {
                groupBYQuery["mandalName"] = "$mandalName";
                projectQuery["mandalName"] = "$_id.mandalName";
                matchCondition["districtName"]=req.query.district;
                sortCondition["mandalName"]=1;

            }
            else{
                groupBYQuery["districtName"] = "$districtName";
                projectQuery["districtName"] = "$_id.districtName";
                sortCondition["districtName"]=1;
            }

            //console.log("groupBYQuery ::: ", groupBYQuery);
            //console.log("projectQuery ::: ", projectQuery);

            let uniqueData = await masterModel.aggregate([
                { "$match": matchCondition},
                { "$group": { _id: groupBYQuery} },
                { "$project": projectQuery },
                { "$sort": sortCondition }
            ]);
            if(uniqueData.length>0)
            {
                //console.log("uniqueData :::: ", uniqueData)
                let requiredDataList = [];
                uniqueData.map((data) => {
                    requiredDataList.push(data[reqKey]);
                });
                resolve(requiredDataList);
            }
            else
                reject("Feaching failed")
            //console.log(" uniqueData :::: ", uniqueData);
        } catch (err) {
            console.log("Process Error", err);
            reject(err);
        }

    });
    
};

exports.getSroDetailsbyVillage =async (req,res)=>{
	const reqQuery = req?.query;
	let query;
	let details;
    let vsws;
	if(reqQuery.district && !reqQuery.mandalName){
		query = {"districtName":reqQuery.district,"mandalName":{$nin:["",null]}};
		details =await masterModel.distinct("mandalName",query);
	}else if(reqQuery.district && reqQuery.mandalName && !reqQuery.revVillageCode){
		query = {"districtName":reqQuery.district,"mandalName":reqQuery.mandalName, "villageName":{$nin:["",null]}};
		details = await masterModel.aggregate([
			{"$match":query},
			{"$group":{_id:{"revVillageCode":"$revVillageCode",villageName:"$villageName"}}},
			{"$project" : {_id:0, revVillageCode:"$_id.revVillageCode", villageName:"$_id.villageName"}},
            { "$sort" : { villageName:1 } }
		])
	}else if(reqQuery.district && reqQuery.mandalName && reqQuery.revVillageCode){
		query = {"districtName":reqQuery.district,"mandalName":reqQuery.mandalName,"revVillageCode":reqQuery.revVillageCode};
		let masterDataList = await masterModel.find(query);
        let masterDataObj = masterDataList[0];
		//let offcrDetails =await dbHelper.findOneMethod(sysConstant.Col_Officers,{sroNumber:parseInt(sro.parentSroCode)});
		details = {
			sroOffice:masterDataObj.sroName,
			sroNumber:masterDataObj.parentSroCode,
			sroDistrict:masterDataObj.districtName
		}
	}else if(reqQuery.villageCode && !reqQuery.district && !reqQuery.mandalName){
		let vgCodes = reqQuery.villageCode.split(",");
        query = {"revVillageCode":{$in:vgCodes}};
        details = await masterModel.aggregate([
            {"$match" : query}, 
            {"$group" : {_id : {districtName:"$districtName", sroName:"$sroName", parentSroCode:"$parentSroCode"}}}, 
            {"$project" : {_id:0, sroDistrict:"$_id.districtName", sroOffice:"$_id.sroName", sroNumber:"$_id.parentSroCode"}},
            { "$sort" : { sroDistrict:1, sroOffice : 1 } }
        ]);
        query["villageScretariatCode"]={$nin:["",null]};
        vsws = await masterModel.aggregate([
            {"$match" : query}, 
            {"$group" : {_id: { villageScretariatCode: "$villageScretariatCode", villageScretariatName: "$villageScretariatName" }, sroName: {$first: "$sroName"}, parentSroCode: {$first: "$parentSroCode"}, districtName: {$first: "$districtName"} }},
            {"$project": {_id: 0, villageScretariatCode: "$_id.villageScretariatCode", villageScretariatName: "$_id.villageScretariatName", srOffice: "$sroName", sroNumber: "$parentSroCode", sroDistrict: "$districtName" }},
            {"$sort": {villageScretariatName: 1, sroDistrict:1, srOffice : 1}} ]);
	}
	return res.status(200).send({status:true, data: vsws ?  {sroList: details, vswsList: vsws} : details});
}
