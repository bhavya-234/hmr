const express = require('express');
const handler = require('./masterData.handler');
const jwt = require('../services/auth.service');
const masters = require('./masterData.controller');
const router = express.Router();

// exports.routesConfig = (app) => {
//     app.post('/api/v1/masterdata', [handler.masterData]);
//     app.get('/api/categories', [handler.getCategories]);
// 	app.get('/api/vgCats',masters.getSroDetailsbyVillage)
// }


router.post('/masterdata', [handler.masterData]);
router.get('/categories', [handler.getCategories]);
router.get('/vgCats',masters.getSroDetailsbyVillage)

module.exports = router;