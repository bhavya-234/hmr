const express = require('express');
const handler = require('./cast.handler');
const jwt = require('../services/auth.service');
const router = express.Router();

// exports.routesConfig = (app) => {
//     app.post('/api/v1/cast', [handler.addCast]);
//     app.get('/api/castDetails', [handler.castDetails]);
//     app.get('/api/subCastDetails', [handler.subCastDetails]);
    
// }

router.post('/cast', jwt.verifyjwt, [handler.addCast]);
router.get('/castDetails', jwt.verifyjwt, [handler.castDetails]);
router.get('/subCastDetails', jwt.verifyjwt, [handler.subCastDetails]);

module.exports = router;