const castModel = require('./model/cast.model');
const jwt = require('../services/auth.service');
const fs = require("fs");
const path = require("path");

exports.addCast = (req) => {
    try {
        let filepath = path.join(__dirname, "./cast.json");
        const jsonString = fs.readFileSync(filepath);
        const customer = JSON.parse(jsonString);
        return new Promise((resolve, reject) => {
            castModel.create(customer)
                    .then(response => {
                        resolve("Data Added");
                    }).catch(err => reject(err));
        });
    } catch (err) {
        console.log("Process Error" + err.message);
    }
};

exports.castDetails = (req) => {
    try {
        return new Promise((resolve, reject) => {
            castModel.find({})
                .then(response => {
                    if (response.length==0){
                        reject("No Data Found")
                    } else{
                        resolve(response)
                    }
                    
                })
                .catch(err => reject(err));
        });
    } catch (err) {
        console.log("Process Error" + err.message);
    }
};

exports.subCastDetails = (req) => {
    
        return new Promise( async (resolve, reject) => {
            try {
                let finalResult = await castModel.aggregate([
                    {"$match":{}},
                    {"$group":{_id:{"subCastName":"$subCastName"}}},
                    {"$project" : {_id:0, subCastName:"$_id.subCastName"}},
                    { "$sort" : { subCastName:1 } }
                ]) .then(response => { 
                    const finalResult=[];
                    response.filter(x=>{ finalResult.push(x.subCastName.toUpperCase())})
                    resolve(finalResult)
                }).catch(err => {
                    console.log("Process Error", err); 
                    reject(err);
                });
            } catch (err) {
                console.log("Process Error", err);
                reject(err);
            }
        });
    
};