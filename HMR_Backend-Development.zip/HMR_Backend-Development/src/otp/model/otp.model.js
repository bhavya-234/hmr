const mongoose = require("../../services/mongoose.service").mongoose;
const Schema = mongoose.Schema;

const otpSchema = new Schema({
	loginEmail: { type: String },
    otp: { type: String },
	otpType:{type:String},
    status:{type:Boolean},
	isValidated:{type:Boolean},
	sendOtpCount:{type:Number},
	isCount:{type:Number}
},{timestamps:true});

module.exports = mongoose.model("otp", otpSchema, "otp");
