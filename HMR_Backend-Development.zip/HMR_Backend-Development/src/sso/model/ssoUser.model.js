const mongoose = require('mongoose');

const ssoUserSchema = new mongoose.Schema({
    loginId: { type: String, default: "" },
    loginName: { type: String, default: "" },
    loginEmail: { type: String, default: "" },
    loginType: { type: String, default: "sso" },
    createdAt: { type: String, default: Date.now },
    updatedAt: { type: String, default: "" },
    source : { type: String, default: "" },
    lastLogin:{type: String},
    departmentCode : {type: String, default: "" },
    requestId :  {type: String, default: "" },
    redirectionUrl :  {type: String, default: "" },
    serviceId :  {type: String, default: "" },
    serviceSubTypeId: {type: String, default: "" }
},{timestamps:true})


module.exports = mongoose.model("ssousers", ssoUserSchema);
