const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const certificateRequestSchema = new mongoose.Schema({
    createdBy:{
        type:Schema.Types.ObjectId,
        ref:'ssousers'
    },
    appNumber: { type: String, default: "" },
    docNumber: { type: String, default: "" },
    docYear: { type: Number },
    paidAmount: { type: String, default: "5" },
    sroNumber: { type: String },
    paymentType: { type: String, default: "ONLINE" },
    status: { type: String, default: "PENDING" },
    source:{ type: String, default: "" },
    requestId:{ type: String, default: "" },
    departmentCode:{ type: String, default: "" },
    departmentTransaction: {type: String, default: "" }
},{timestamps:true})


module.exports = mongoose.model("certificateRequest", certificateRequestSchema);
