const express = require('express')
const jwt = require('../services/auth.service');
const ssoUserController = require('./ssoUser.controller');
const ssoUserRouter = express.Router();

ssoUserRouter.post('/ssoAuthentication', ssoUserController.ssoAuthentication);
ssoUserRouter.get('/getDetailsByDocNumber', jwt.verifyUserjwt, ssoUserController.getDetailsByDocumentNumber );
ssoUserRouter.post('/addCertificateRequest', jwt.verifyUserjwt, ssoUserController.createCertificateRequest);
ssoUserRouter.get('/getSROCertificateRequests', jwt.verifyOfficerJwt, ssoUserController.getCertificateRequestsForOfficer);
// ssoUserRouter.get('/getAllRequests', jwt.verifyUserjwt, ssoUserController.getCertificateRequestsForSSO);
ssoUserRouter.get('/getCertificateRequestsForSSO', jwt.verifyUserjwt, ssoUserController.getCertificateRequestsForSSO);

module.exports = ssoUserRouter;