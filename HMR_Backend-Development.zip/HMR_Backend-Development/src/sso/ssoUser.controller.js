var cryptoJS = require('crypto-js');
const fetch = require("node-fetch");
var querystring = require('querystring');
const registrationModel = require('../users/model/registration.model');
const ssoUserModel = require('./model/ssoUser.model');
const masterDataModel = require('../masterData/model/masterData.model');
const jwt = require('../services/auth.service');
const moment = require('moment');
const certificateRequestModel = require('./model/certificateRequest.model')
const officerModel = require('../officer/model/officer.model');

exports.ssoAuthentication = async (req, res) => {
  let urlRedirect;
  try {
    console.log("Inside of ssoAuthentication ::::: ");
    let accessTokenResponse = await getSSOToken();
    if (isError(accessTokenResponse)) {
      urlRedirect = ErrorResponseWithRedirectUrl("Internal Server Error", accessTokenResponse.message);
    }
    else if (accessTokenResponse.status == 200) {
      let accessToken = accessTokenResponse.access_token;
      let tokenType = accessTokenResponse.token_type;
      let reqBody = req.body;
      console.log("reqBody ::::: ", reqBody);
      console.log("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: ");
      let tokenId = reqBody.tokenId;
      let requestId = reqBody.requestId;
      let departmentCode = reqBody.departmentId;

      let strToHash = tokenId + "&" + requestId + "&" + departmentCode;
      console.log("strToHash ::::: ", strToHash);
      let hashVal = generateHashValueByString(strToHash);    

      let userInfoResponse = await getSSOTransactionDetails(reqBody, accessToken, tokenType, hashVal);
      if (isError(userInfoResponse)) {
        urlRedirect = ErrorResponseWithRedirectUrl("Internal Server Error", userInfoResponse.message);
      }
      else if (userInfoResponse.status == 200) {
        if(userInfoResponse.result.status == "100"){
          let findQuery = { loginId: userInfoResponse.result.userId, loginEmail: userInfoResponse.result.userEmail };
          let ssoUser = await ssoUserModel.findOne(findQuery);

          if (ssoUser == undefined || ssoUser == null) {
            const ssoUserModelData = new ssoUserModel();
            ssoUserModelData.loginId = userInfoResponse.result.userId;
            ssoUserModelData.loginName = userInfoResponse.result.userEmail;
            ssoUserModelData.loginEmail = userInfoResponse.result.userEmail;
            ssoUserModelData.source = "AP Seva";
            ssoUserModelData.requestId = userInfoResponse.result.requestId;
            ssoUserModelData.departmentCode = userInfoResponse.result.departmentCode;
            ssoUserModelData.redirectionUrl = userInfoResponse.result.redirectionUrl;
            ssoUserModelData.serviceId = userInfoResponse.result.serviceId;
            if (userInfoResponse.result.serviceSubTypeId != "string")
              ssoUserModelData.serviceSubTypeId = userInfoResponse.result.serviceSubTypeId;

            ssoUser = await ssoUserModelData.save();
          }
          else {
            var date = new Date();
            var dateStr =
              ("00" + date.getDate()).slice(-2) + "-" +
              ("00" + (date.getMonth() + 1)).slice(-2) + "-" +
              date.getFullYear() + " " +
              ("00" + date.getHours()).slice(-2) + ":" +
              ("00" + date.getMinutes()).slice(-2) + ":" +
              ("00" + date.getSeconds()).slice(-2);
            let lastLoginUpdate = { lastLogin: dateStr, 
                                    redirectionUrl : userInfoResponse.result.redirectionUrl,
                                    requestId : userInfoResponse.result.requestId,
                                    departmentCode : userInfoResponse.result.departmentCode,
                                    serviceId : userInfoResponse.result.serviceId
                                  };
            await ssoUserModel.findOneAndUpdate(findQuery, { $set: lastLoginUpdate });
          }

          let user = {
            userId: ssoUser._id,
            loginEmail: ssoUser.loginEmail,
            lastLogin: ssoUser.lastLogin,
            loginType: ssoUser.loginType
          }
          const token = await jwt.createToken(user, null);
          user.loginId = ssoUser._id,
          user.loginName = ssoUser.loginName,
          user.token = token;
          user.redirectUrl = ssoUser.redirectionUrl;
          user.requestId = ssoUser.requestId;
          user.departmentCode = ssoUser.departmentCode;
          user.source = "AP Seva";
          user.status = true;

          let base64DataString = Buffer.from(JSON.stringify(user)).toString('base64');
          urlRedirect = process.env.SSO_AUTHENTICATE_REDIRECTION + base64DataString;
        }
        else {
          urlRedirect = ErrorResponseWithRedirectUrl(userInfoResponse.result.status, userInfoResponse.result.reason);
        }
      }
      else {
        urlRedirect = ErrorResponseWithRedirectUrl(userInfoResponse.error, userInfoResponse.error_description);
      }
    }
    else {
      urlRedirect = ErrorResponseWithRedirectUrl(accessTokenResponse.error, accessTokenResponse.error_description);
    }
  } catch (error) {
    console.log(" error :::: ", error);
    urlRedirect = ErrorResponseWithRedirectUrl("Internal Server Error", error.message);
  }
  console.log("urlRedirect URL :::: ", urlRedirect);
  res.writeHead(301, { 'Location': urlRedirect }).end();
}


async function getSSOTransactionDetails(reqBody, accessToken, tokenType, hashVal) {
  let requestBody = {
    "tokenId": reqBody.tokenId, "requestId": reqBody.requestId,
    "departmentCode": reqBody.departmentId, "hash": hashVal
  };
  console.log("Inside of getSSOTransactionDetails method :::: ");
  let userInfoResponse;
  try {
    let requestBodyString = JSON.stringify(requestBody)
    let contentLength = requestBodyString.length;
    let headersData = {
      'Content-Length': contentLength,
      'Content-Type': 'application/json',
      'Authorization': tokenType + " " + accessToken
    }
    userInfoResponse = await ExecuteAPSevaServiceCallWithDetails(process.env.AP_SEVA_GET_TRANSACTION_DETAILS_URL, 'post', requestBodyString, headersData);
  } catch (error) {
    console.log(" error ::::::::::::::::::: ", error);
  }
  console.log("End of getSSOTransactionDetails method :::: ");
  return userInfoResponse;
}


async function getSSOToken() {
  console.log("Inside of getSSOToken method :::: ");
  try {
    let reqData = {
      "grant_type": "client_credentials",
      "client_id": process.env.AP_SEVA_CLIENT_ID,
      "client_secret": process.env.AP_SEVA_CLIENT_SECRET,
      "scope": process.env.AP_SEVA_SCOPE
    };

    let formData = querystring.stringify(reqData);
    let contentLength = formData.length;

    let headersData = {
      'Content-Length': contentLength,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Ocp-Apim-Subscription-Key': process.env.AP_SEVA_SUBSCRIPTION,
    }

    let ssoRepsoneObj = await ExecuteAPSevaServiceCallWithDetails(process.env.AP_SEVA_TOKEN_URL, 'post', formData, headersData);
    console.log("End of getSSOToken method :::: ");
    return ssoRepsoneObj;
  } catch (error) {
    console.log(" Error :::: ", error);
    return error;
  }
}


async function ExecuteAPSevaServiceCallWithDetails(apiUrl, methodType, bodyData, headersData) {
  try {
    const response = await fetch(apiUrl, {
      method: methodType,
      body: bodyData,
      headers: headersData
    });

    let responseData = await response.json();
    responseData.status = response.status;
    console.log("Response Data :::: ", responseData);
    return responseData;
  } catch (error) {
    console.log(" Error :::: ", error);
    return error;
  }
}


function generateHashValueByString(strToHash) {
  let hashVal;
  console.log("Inside of generateHashValueByString method :::: ");
  try {
    let bytes = cryptoJS.HmacSHA256(strToHash, process.env.AP_SSO_HMACSHA256_KEY);
    hashVal = bytes.toString().toUpperCase();
  } catch (error) {
    console.log(" error ::::::::::::::::::: ", error);
  }
  console.log("End of generateHashValueByString method :::: ");
  return hashVal;
}


function ErrorResponseWithRedirectUrl(errorVal, errorMessage) {
  let errorRepsonse = {};
  errorRepsonse["status"] = false;
  errorRepsonse["error"] = errorVal;
  errorRepsonse["errorMessage"] = (errorMessage.split("\r\n"))[0];
  let base64DataString = Buffer.from(JSON.stringify(errorRepsonse)).toString('base64');
  return process.env.SSO_AUTHENTICATE_REDIRECTION + base64DataString
}


let isError = function (e) {
  return e && e.stack && e.message;
}

exports.getDetailsByDocumentNumber = async (req, res) => {
  try {
    const documentNumber = req.query.documentNumber;
    const year = req.query.year;
    const checkDocumentNumber = await certificateRequestModel.find({ docNumber: documentNumber, docYear: year, status: { $ne: 'PROCESSED' } })
    if (checkDocumentNumber.length !== 0) {
      return res.status(400).send({ status: false, message: "You have already raised a request for this  Document Number " })
    }
    if (!documentNumber && !year) {
      return res.status(400).send({ status: false, message: "Please provide Document Number and Year." });
    }
    if (!documentNumber) {
      return res.status(400).send({ status: false, message: "Please enter Document number" });
    }
    if (!year || year === "" || year === null || year === undefined) {
      return res.status(400).send({ status: false, message: "Please select year" });
    }
    let userData = await registrationModel.find({ "documentNumber": documentNumber, "status": "COMPLETED" });
    if (!userData || userData.length === 0) {
      return res.status(404).send({ status: false, message: "User data not found for the given Document Number" });
    }
    const filteredData = userData.filter((item) => {
      const updatedYear = moment(item.updatedAt).format('YYYY');
      return updatedYear === year;
    });
    if (filteredData.length === 0) {
      return res.status(404).send({ status: false, message: "User data not found for the given year" });
    }

    return res.status(200).send({ status: true, data: filteredData });
  } catch (err) {
    console.error(err);
    return res.status(500).send({ status: false, message: "Something went wrong" });
  }
};

exports.createCertificateRequest = async (req, res) => {
  try {
    let loginUser = req.user;
    let reqBody = req.body;
    if (!reqBody.departmentTransaction) {
      return res.status(400).send({ status: false, message: "Department transaction is required." });
    }
    reqBody["createdBy"] = loginUser.userId;
    const newCertificateRequest = new certificateRequestModel(reqBody);
    const saveCertificateRequest = await newCertificateRequest.save();
    return res.status(200).send({ status: true, message: "Certificate Request Sent Successfully", data: saveCertificateRequest })
  }
  catch (err) {
    console.error("Error:", err);
    return res.status(500).send({ status: false, message: "Something went wrong" });
  }
}

exports.getCertificateRequestsForOfficer = async (req, res) => {
  try {
    let loginUser = req.user;

    let officerData = await officerModel.findOne({ _id: loginUser.userId});
    const sroNumber = officerData.sroNumber;
    const reqStatus = req.query.status; 
    let query = { sroNumber: sroNumber};
    if(reqStatus!=undefined && reqStatus!=null && reqStatus!="")
      query["status"] = reqStatus;
    
    const certificateRequests = await certificateRequestModel.find(query);
    if (!certificateRequests || certificateRequests.length === 0) {
      return res.status(400).send({ status: false, message: "Data not found." });
    }
    return res.status(200).send({ status: true, data: certificateRequests });
  } catch (err) {
    console.error("Error:", err);
    return res.status(500).send({ status: false, message: "Something went wrong. Please try again later." });
  }
}

exports.getCertificateRequestsForSSO = async (req, res) => {
  try {
    let loginUser = req.user;
    const reqStatus = req.query.status; 
    let findQuery = {createdBy:loginUser.userId};
    if(reqStatus!=undefined && reqStatus!=null && reqStatus!="")
      findQuery["status"] = reqStatus;

    const totalList = await certificateRequestModel.find(findQuery);
    if (!totalList || totalList.length === 0) {
      return res.status(400).send({ status: false, message: "Data not found." })
    }
    return res.status(200).send({ status: true, data: totalList })
  }
  catch (err) {
    console.error("Error:", err);
    return res.status(500).send({ status: false, message: "Something went wrong. Please try again later." });
  }
}


exports.updateStatusToAPSevaWithDetails = async (applicationId, applicationType, remarks, transactionType, currentLevel) => {
  try {
    let transactionackid = "HMR"+(Date.now());
    let updateJSON = {
      "requestId": "",
      "departmentCode": "",
      "redirectionRequestData": {
        "transactionType": transactionType,
        "departmentTransactionId": applicationId,
        "serviceCode": "HMR",
        "subServiceCode": "HMR",
        "serviceDescription": "Hindu Marriage Registartion",
        "statusCode": "",
        "statusDescription": "",
        "slaDays": "0",
        "subSLADays": "0",
        "applicantID": applicationId,
        "applicantMobileNumber": "",
        "applicantEmail": "test@test.com",
        "currentLevel": currentLevel,
        "districtCode": "",
        "mandalCode": "",
        "secretariatCode": "",
        "panchayatCode": null,
        "officerName": "",
        "officerMobileNumber": "0000000000",
        "transactionackid":transactionackid,
        "timestamp": "",
        "remarks": remarks
      },
      "hash": ""
    }
    
    let registrationObject;
    if(applicationType == "certificateDownload") {
      let certificateObject = await certificateRequestModel.findOne({appNumber:applicationId});

      updateJSON.redirectionRequestData.timestamp = (certificateObject.updatedAt).toISOString();
      registrationObject = await registrationModel.findOne({appNo:applicationId});
      updateJSON.redirectionRequestData.secretariatCode = certificateObject.sroNumber+"";     
      updateJSON.redirectionRequestData.statusDescription = certificateObject.status;
      updateJSON.redirectionRequestData.statusCode = certificateObject.status;
      updateJSON.redirectionRequestData.departmentTransactionId = applicationId;
      updateJSON.requestId = certificateObject.requestId;
      updateJSON.departmentCode = certificateObject.departmentCode;
    }
    else {
      registrationObject = await registrationModel.findOne({appNo:applicationId});
      updateJSON.redirectionRequestData.timestamp = (registrationObject.updatedAt).toISOString();
      updateJSON.redirectionRequestData.statusDescription = registrationObject.status;
      updateJSON.redirectionRequestData.statusCode = registrationObject.status;
      updateJSON.redirectionRequestData.departmentTransactionId = applicationId;
      updateJSON.requestId = registrationObject.requestId;
      updateJSON.departmentCode = registrationObject.departmentCode;
      if(registrationObject.villageScretariatCode)
        updateJSON.redirectionRequestData.secretariatCode = registrationObject.villageScretariatCode+"";
      else
        updateJSON.redirectionRequestData.secretariatCode = registrationObject.sroNumber+"";
    }

    
    //await ssoUserModel.findOne({requestId:updateJSON.requestId});

    let sroCode = registrationObject.sroNumber+"";
    let mestarData = await masterDataModel.findOne({parentSroCode: sroCode});
    let officerName = "SR "+registrationObject.sroOffice;
    updateJSON.redirectionRequestData.officerName = officerName;
    updateJSON.redirectionRequestData.mandalCode = mestarData.revMandalCode;
    updateJSON.redirectionRequestData.districtCode = mestarData.revDistCode;
    updateJSON.redirectionRequestData.applicantMobileNumber = registrationObject.husbandMobile;

    let dateArray = (updateJSON.redirectionRequestData.timestamp).split(".");
    let timeStampVal = dateArray.join(".");
    timeStampVal = timeStampVal.replace("."+(dateArray[dateArray.length-1]),"");
    console.log(timeStampVal);
    
    let hashCodeString = updateJSON.requestId+"&"+updateJSON.departmentCode+"&"+transactionType
                         +"&"+applicationId+"&HMR&HMR&Hindu Marriage Registartion&"
                         +updateJSON.redirectionRequestData.statusCode+"&"
                         +updateJSON.redirectionRequestData.statusDescription+"&0&0&"
                         +applicationId+"&"+updateJSON.redirectionRequestData.applicantMobileNumber
                         +"&test@test.com&"+currentLevel+"&"+mestarData.revDistCode+"&"
                         +mestarData.revMandalCode+"&"+updateJSON.redirectionRequestData.secretariatCode+
                         "&&"+officerName+"&0000000000&"+transactionackid+"&"+timeStampVal+"&"+remarks;
    
    let hashVal = generateHashValueByString(hashCodeString);    
    updateJSON.hash = hashVal;

    let accessTokenResponse = await getSSOToken();
    if (!isError(accessTokenResponse)) {
      let accessToken = accessTokenResponse.access_token;
      let tokenType = accessTokenResponse.token_type;

      let requestBodyString = JSON.stringify(updateJSON)
      console.log("Update Transaction Request :::: ", requestBodyString);
      let contentLength = requestBodyString.length;
      let headersData = {
        'Content-Length': contentLength,
        'Content-Type': 'application/json',
        'Authorization': tokenType + " " + accessToken
      }
      let updateTransactionResponse = await ExecuteAPSevaServiceCallWithDetails(process.env.AP_SEVA_UPDATE_TRANSACTION_URL, 'post', requestBodyString, headersData);
      console.log("updateTransactionResponse :::: ", updateTransactionResponse);
    }
       
  } catch (error) {
    console.log(" Error :::: ", error);
  }


}
