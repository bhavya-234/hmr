import { useEffect } from "react"
import { useRouter } from 'next/router';
import { useAppDispatch } from '../src/redux/hooks';
import { LoadingAction } from '../src/redux/commonSlice';
import { saveLoginDetails } from '../src/redux/loginSlice';
import styles from '../styles/404.module.css';


function SSOLoginHandler() {

  const router = useRouter();
  const dispatch = useAppDispatch()
  const Loading = (value: boolean) => { dispatch(LoadingAction({ enable: value })); }

  useEffect(() =>{
    Loading(true); 
    let [rest,encodeData]=window.location.href.split("?"); 
    localStorage.clear();
    if(encodeData != undefined && encodeData != null)
    {
      let buff = Buffer.from(encodeData, 'base64')
      let dataString = buff.toString();
      let data = JSON.parse(dataString);
      console.log("data ::::: ", data);

      console.log(data);
      console.log(" data.status ::: ", data.status);
      if(data.status === true)
      {
        let query = {
          loginId: data.loginId,
          redirectUrl: data.redirectUrl,
          loginEmail: data.loginEmail,
          loginName: data.loginName,
          lastLogin:data.lastLogin,
          token: data.token,
          loginType: data.loginType,
          status: data.status,
          requestId:data.requestId,
          departmentCode:data.departmentCode,
          source:data.source,
          registrationDetails: []
        }
        localStorage.setItem("loginDetails", JSON.stringify(query));
        dispatch(saveLoginDetails(query));
      
        router.push("/SSODashboard");
      }
      else{
        document.getElementById("unauthorizedAccessId").style.display = "block";
        let errorHeaderText = document.getElementById("errorDescriptionId").innerHTML
        document.getElementById("errorDescriptionId").innerHTML  = "<b>Error From AP Seva API </b>: "+data.errorMessage;
      }
    }
    else
      router.push("/LoginPage");
    
    Loading(false); 
  }, []);
  
  return (
    <div>
      <div className={styles.container}>
        <div style={{display:"none"}} id="unauthorizedAccessId">
          <h1>401 - Unauthorized Access</h1>
          <br></br>
          <br></br>
          <h4 id="errorDescriptionId"></h4>
        </div>
      </div>
      <br></br>
    </div>
  )
}

export default SSOLoginHandler;