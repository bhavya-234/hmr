import React, { useState, useEffect } from 'react'
import styles from '../styles/pages/ViewUserDetails.module.scss';
import { useRouter } from 'next/router';
import { Table } from 'react-bootstrap';
import TableInputText from '../src/components/TableInputText';
import TableText from '../src/components/TableText';
import { GetCertificateRequestsByAppNo, UploadDoc, SaveUser, DefaceStatus, GetVerificationStatus, UpdateCertificateRequest, downloadFileByNameAndAppNo } from '../src/axios';
import { useAppSelector, useAppDispatch } from '../src/redux/hooks';
import { LoadingAction, PopupAction } from '../src/redux/commonSlice';
import { Row, Col } from 'react-bootstrap'
import { handleLogOut } from '../utils';

const initialUserDetails = {
    husbandAadhar: "",
    wifeAadhar: "",
    husbandPassport: "",
    wifePassport: "",
    husbandAadharOtp: "",
    wifeAadharOtp: "",
    husbandDOI: "",
    husbandDOE: "",
    wifeDOI: "",
    wifeDOE: "",
    husbandName: "",
    husbandReligion: "",
    husbandCaste: "",
    husbandDateofBirth: "",
    husbandMobile: "",
    husbandMarriageAge: "",
    husbandRankorProfession: "",
    husbandCountry: "",
    husbandState: "",
    husbandDistrict: "",
    husbandMandal: "",
    husbandVillageWard: "",
    husbandAddress: "",
    husbandOffice: "",
    husbandRelationship: "",
    husbandFatherName: "",
    husbandMotherName: "",
    wifeName_beforeMarriage: "",
    wifeName_afterMarriage: "",
    change_wifeName_to_afterMarriage: "",
    wifeReligion: "",
    wifeCaste: "",
    wifeDateofBirth: "",
    wifeMobile: "",
    wifeMarriageAge: "",
    wifeRankorProfession: "",
    wifeCountry: "",
    wifeState: "",
    wifeDistrict: "",
    wifeMandal: "",
    wifeVillageWard: "",
    wifeAddress: "",
    wifeOffice: "",
    wifeRelationship: "",
    wifeFatherName: "",
    wifeMotherName: "",
    isWifeDivorce: "",
    marriageDate: "",
    marriageCountry: "",
    marriageState: "",
    marriageDistrict: "",
    marriageMandal: "",
    marriageVillageWard: "",
    marriageAddress: "",
    marriageType: "",
    regDate: "",
    appNo: "",
    status: "",
    sroOffice: "",
    slotDate: "",
    slotTime: "",
    certificateCopies: "",
    casteType: "",
    loginLabel: "",
    loginName: "",
    loginEmail: "",
    loginMobile: "",
    loginPassword: "",
    loginRPassword: "",
    doc_final_regForm: "",
    doc_final_regForm_upload: "",
    documentNumber: "",
    updatedAt: "",
    documents: [],
}

const SSOCertificateRequestsDetails = () => {
    let initialLoginDetails = useAppSelector((state) => state.login.loginDetails);
    const [LoginDetails, setLoginDetails] = useState(initialLoginDetails);
    const dispatch = useAppDispatch();
    const router = useRouter();
    const [UserDetails, setUserDetails] = useState<any>(initialUserDetails);
    const [payData, setPayData] = useState<any>({})
    const [showInputs, setShowInputs] = useState(false);
    const [showForm, setShowForm] = useState(false);
    const ShowAlert = (type, message, redirect) => { dispatch(PopupAction({ enable: true, type: type, message: message, redirect: redirect })); }
    const Loading = (value: boolean) => { dispatch(LoadingAction({ enable: value })); }

    const GetCertificateRequestDetails = async (registrationId: any, loginType: any) => {
        Loading(true);
        let data = await GetCertificateRequestsByAppNo(registrationId, loginType);
        Loading(false);
        if (data) {
            if ((data.data.paymentType && data.data.paymentType == "PAY ONLINE") ||
                (data.data.transactionId && data.data.transactionId.length > 0)) {
                if ((data.data.transactionId).indexOf("_") > -1 && (data.data.payStatus != undefined && !data.data.payStatus))
                    setShowForm(false);
                else
                    setShowForm(true);
            }
            else
                setShowForm(true);

            let data2 = { ...data.data, registrationId: registrationId }
            setUserDetails(data2);
        }
    }

    useEffect(() => {
        let data: any = localStorage.getItem("loginDetails");
        data = JSON.parse(data);
        if (data && data.token) {
            GetCertificateRequestDetails(localStorage.getItem("registrationId"), data.loginType);
            setLoginDetails(data)
        }
        else {
            handleLogOut()
        }
    }, [])

    const ShiftToLocation = (location: string) => {
        router.push({
            pathname: location,
        })
    }

    const DisplayTable = (key: any, value: any) => {
        return (
            <div className={styles.AddressClassForDiv} style={{ display: 'flex' }}>
                <div className={styles.KeyContainer} >
                    <text className={styles.keyText}>{key}</text>
                </div>
                <div>:</div>
                {key == "Address" ?
                    <div className={styles.ValueContainer}>
                        <text className={styles.valueText}>{value}</text>
                    </div>
                    :
                    <div className={styles.ValueContainer}>
                        <text className={styles.valueText}>{value}</text>
                    </div>
                }
            </div>
        );
    }

    const GetVerificationTransactionStatus = async (deptTransID: any) => {
        Loading(true);
        let result = await GetVerificationStatus(deptTransID, "certRequest");
        Loading(false);
        if (result && result.status) {
            setShowInputs(true);
            setShowForm(false);
            setPayData({ ...result.data })
            ShowAlert(true, result.message, "");
        }
        else {
            setShowInputs(false);
            return ShowAlert(false, result.message, "");
        }
    }

    const GetDefaceStatus = async (deptTransID: any) => {
        Loading(true);
        let result = await DefaceStatus(deptTransID);
        Loading(false);
        if (result && result.status) {
            setShowForm(true)
            return ShowAlert(true, result.message, "");
        }
        else {
            setShowForm(false);
            return ShowAlert(false, result.message, "");
        }
    }

    const GoBack = () => {
        if (LoginDetails.loginType == "officer")
            ShiftToLocation("/OfficeDashboard");
        else if (LoginDetails.loginType == "sso")
            ShiftToLocation("/SSODashboard");
        else
            ShiftToLocation("/UserDashboard");
    }

    const ChangeDateFormat = (Date: string) => {
        if (Date) {
            let Arry = Date.split('-');
            return (Arry[2] + "-" + Arry[1] + "-" + Arry[0])
        }
        return Date;

    }

    const UpdatedCertificateRequestData = async () => {
        Loading(true);
        let result = await UpdateCertificateRequest(UserDetails.registrationId);
        Loading(false)
        if (result && result.status) {
            if (result.data.length > 0) {
                return ShowAlert(true, result.data, "/OfficeDashboard");
            }
            else {
                return ShowAlert(false, result.data, "");
            }
        }
    }


    return (
        <div>
            <div className={styles.Navbar}>
                <text className={styles.NavbarText}> Welcome : {LoginDetails.loginName.toUpperCase()}</text>
                <text className={styles.NavbarText}> Last Login : {LoginDetails.lastLogin}</text>
                <div style={{ cursor: 'pointer' }} onClick={() => { handleLogOut() }} ><text className={styles.NavbarText}> Logout </text></div>
            </div>
            <div className={styles.Container}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <text className={styles.DashboardTitleText}>{LoginDetails.loginType && LoginDetails.loginType.toUpperCase() == "SSO" ? 'Raised Registration Details' : "User Certificate Requests Details"}</text>
                    {LoginDetails.loginType &&
                        <div style={{ display: 'flex' }}>
                            {(UserDetails && UserDetails.cert_url == "" && LoginDetails.loginType.toUpperCase() == "OFFICER" && LoginDetails.role &&
                                ((LoginDetails.role === "SRO" && (UserDetails.villageScretariatCode == "" || UserDetails.villageScretariatCode == null)) ||
                                    (LoginDetails.role === "VR" && UserDetails.villageScretariatCode))) ? <div className={styles.EditButton} onClick={() => {
                                        if (UserDetails.status == "DRAFT") {
                                            localStorage.setItem("redirectFrom", "SSOCertificateRequestsDetails");
                                            localStorage.setItem("Prieview", JSON.stringify(UserDetails));
                                            ShiftToLocation("/SSORegistration")
                                        } else {
                                            ShiftToLocation("/OfficerUserUpdate")
                                        }
                                    }}><text className={styles.NavbarText}>Edit</text></div> : null}
                            <div className={styles.EditButton} onClick={GoBack}><text className={styles.NavbarText}>Back</text></div>
                        </div>
                    }
                </div>
                <div style={{ width: '100%' }}>
                    <div style={{ display: 'flex' }}>
                        <div className={styles.ListContainer}>
                            <text className={styles.TitleText}>Certificate Requests Details</text>
                            {DisplayTable("Document Number", UserDetails.docNumber)}
                            {DisplayTable("Document Year", UserDetails.docYear)}
                            {DisplayTable("Certificate Request Date", UserDetails.createdAt)}
                            {DisplayTable("Application Number", UserDetails.appNumber)}
                        </div>
                    </div>
                    <div style={{ display: 'flex' }}>
                        <div className={styles.ListComponentContainer}>
                            <text className={styles.TitleText}>Husband Details</text>
                            {DisplayTable(" Name", UserDetails.husbandName)}
                            {DisplayTable(" Religion", UserDetails.husbandReligion)}
                            {DisplayTable(" Caste", UserDetails.husbandOtherCaste ? UserDetails.husbandOtherCaste : UserDetails.husbandCaste)}
                            {DisplayTable(" Date of Birth", ChangeDateFormat(UserDetails.husbandDateofBirth))}
                            {DisplayTable(" Mobile Number", UserDetails.husbandMobile)}
                            {DisplayTable(" Country", UserDetails.husbandCountry)}
                            {DisplayTable(" State", UserDetails.husbandState)}
                            {DisplayTable("Address", UserDetails.husbandAddress)}
                            {DisplayTable("Relationship", UserDetails.husbandRelationship)}
                            {DisplayTable(" Father Name", UserDetails.husbandFatherName)}
                            {DisplayTable(" Mother Name", UserDetails.husbandMotherName)}
                        </div>
                        <div className={styles.ListComponentContainer}>
                            <text className={styles.TitleText}>Wife Details</text>
                            {DisplayTable("Name Before Marriage", UserDetails.wifeName_beforeMarriage)}
                            {DisplayTable("Name After Marriage", UserDetails.wifeName_afterMarriage == '' ? ' N/A ' : UserDetails.wifeName_afterMarriage)}
                            {DisplayTable("Request to Change Name", UserDetails.change_wifeName_to_afterMarriage)}
                            {DisplayTable("Religion", UserDetails.wifeReligion)}
                            {DisplayTable("Caste", UserDetails.wifeOtherCaste ? UserDetails.wifeOtherCaste : UserDetails.wifeCaste)}
                            {DisplayTable("Date of Birth", ChangeDateFormat(UserDetails.wifeDateofBirth))}
                            {DisplayTable("Mobile Number", UserDetails.wifeMobile)}
                            {DisplayTable("Country", UserDetails.wifeCountry)}
                            {DisplayTable("State", UserDetails.wifeState)}
                            {DisplayTable("Address", UserDetails.wifeAddress)}
                            {DisplayTable("Relationship", UserDetails.wifeRelationship)}
                            {DisplayTable("Father Name", UserDetails.wifeFatherName)}
                            {DisplayTable("Mother Name", UserDetails.wifeMotherName)}
                        </div>
                    </div>
                </div>
            </div>
            {LoginDetails.loginType && LoginDetails.role && LoginDetails.role === "SRO" && UserDetails.status == "PENDING" ?
                <div style={{ marginLeft: '3rem' }}>
                    <Row style={{ margin: '1rem' }}>
                        <Col>
                            <div style={{ position: 'relative' }}>
                                <TableText label=" Dept. Transaction ID :" required={true} LeftSpace={false} />
                                <div style={{ position: 'absolute', top: '0rem', left: '160px', width: '50%' }}>
                                    <TableInputText type='text' placeholder='' required={true} name={'departmentTransaction'} value={UserDetails.departmentTransaction} onChange={(e) => { setUserDetails({ ...UserDetails, departmentTransaction: e.target.value }) }} />
                                </div>
                            </div>
                        </Col>
                        <Col >
                            <div className={styles.EditButton} style={{ width: '35%' }} onClick={(e) => { GetVerificationTransactionStatus(UserDetails.departmentTransaction) }} ><text className={styles.NavbarText}>Verify Transaction</text></div>
                        </Col>
                    </Row>
                    {showInputs && (
                        <div>
                            <Row style={{ margin: '1rem' }} >
                                <Col>
                                    <div style={{ position: 'relative' }}>
                                        <TableText label="Amount Paid(₹)" required={false} LeftSpace={false} />
                                        <div style={{ position: 'absolute', top: '0rem', left: '143px' }}>
                                            {/* <TableInputText type='number' placeholder="" required={true} name={'amount'} value={payData.amount ? payData.amount : ''} onChange={() => { }} /> */}
                                            <TableText label={payData.amount ? (': \u00A0\u00A0\u00A0'+ payData.amount) : ''} required={false} LeftSpace={false} textTransform={'uppercase'} />
                                        </div>
                                    </div>
                                </Col>
                                <Col >
                                    <div className={styles.EditButton} style={{ width: '35%' }} onClick={(e) => { GetDefaceStatus(UserDetails.departmentTransaction) }} ><text className={styles.NavbarText}>Deface Transaction</text></div>
                                </Col>
                            </Row>
                            {showForm &&
                                <div style={{ display: 'flex', justifyContent: 'center', margin: '3rem' }}>
                                    <div className={styles.EditButton2} style={{ backgroundColor: '#005177' }} onClick={UpdatedCertificateRequestData}><text className={styles.NavbarText}>Complete Certificate Request Process</text></div>
                                </div>
                            }
                        </div>
                    )}
                </div> :
                <div style={{ margin: '1rem' }}>
                    {UserDetails.status === "COMPLETED" && LoginDetails.loginType && LoginDetails.loginType.toUpperCase() === "SSO" ?
                        <div style={{ display: 'flex', justifyContent: 'center', margin: '3rem' }}>
                            <div onClick={() => downloadFileByNameAndAppNo("doc_final_regForm", UserDetails.appNo, LoginDetails.loginType)} className={styles.EditButton2}><text className={styles.NavbarText}>Download Marriage Certificate </text></div>
                        </div> : null}
                </div>
            }
            {/* <pre>{JSON.stringify(UserDetails, null, 2)}</pre> */}
        </div>
    )
}

export default SSOCertificateRequestsDetails;