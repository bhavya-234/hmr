import React, { Fragment, useEffect, useState, useRef } from 'react'
import { Col, Row } from 'react-bootstrap'
import styles from '../styles/pages/UserDashboard.module.scss';
import { useRouter } from 'next/router';
import TableInputText from '../src/components/TableInputText'
import TableText from '../src/components/TableText';
import TableDropdown from '../src/components/TableDropdown';
import style from '../styles/pages/ViewUserDetails.module.scss';
import { GetPaymentStatus, GetUserByDocNo, createCertificateRequest, GetAllCertificateRequestsForSSO } from '../src/axios';
import { useAppSelector, useAppDispatch } from '../src/redux/hooks';
import { LoadingAction, PopupAction } from '../src/redux/commonSlice';
import { DataGrid, GridColDef, GridValueGetterParams } from '@mui/x-data-grid';
import { GetUserRegistrations } from '../src/axios';
import { handleLogOut } from '../utils';

const datagridSx = {
  borderRadius: 2,
  "& .MuiDataGrid-main": { borderRadius: 2, marginTop: "-1%" },
  "& .MuiDataGrid-columnHeaders": {
    color: "#FFFFFF",
    fontStyle: "bold",
    fontSize: 16,
    background: "linear-gradient(90deg, #394C91 0.86%, #27D3E0 100%)",
    minHeight: "11% !important",
    maxHeight: "11% !important",
    marginTop: "1%"
  },
};

const columns: GridColDef[] = [
  { field: 'appNo', headerName: 'Application No.', flex: 1 },
  { field: 'husbandName', headerName: 'Husband Name', flex: 1 },
  { field: 'wifeName_beforeMarriage', headerName: 'Wife Name', flex: 1 },
  { field: 'assignedTo', headerName: 'Assigned To', flex: 1 },
  { field: 'regDate', headerName: 'Reg. Date', flex: 1 },
  { field: 'status', headerName: 'Status', flex: 1 }
];

const certificatecolumns: GridColDef[] = [
  { field: 'appNumber', headerName: 'Application Number', flex: 1 },
  { field: 'docNumber', headerName: 'Document Number', flex: 1 },
  { field: 'docYear', headerName: 'Document Year', flex: 1 },
  { field: 'source', headerName: 'Request From', flex: 1 },
  { field: 'status', headerName: 'Status', flex: 1 },
  { field: 'createdAt', headerName: 'Request Date', flex: 1 },
]


const SSODashboard = () => {
  const initialUserDetails = {
    husbandAadhar: "",
    wifeAadhar: "",
    husbandPassport: "",
    wifePassport: "",
    husbandAadharOtp: "",
    wifeAadharOtp: "",
    husbandDOI: "",
    husbandDOE: "",
    wifeDOI: "",
    wifeDOE: "",
    husbandName: "",
    husbandReligion: "",
    husbandCaste: "",
    husbandDateofBirth: "",
    husbandMobile: "",
    husbandMarriageAge: "",
    husbandRankorProfession: "",
    husbandCountry: "",
    husbandState: "",
    husbandDistrict: "",
    husbandMandal: "",
    husbandVillageWard: "",
    husbandAddress: "",
    husbandOffice: "",
    husbandRelationship: "",
    husbandFatherName: "",
    husbandMotherName: "",
    wifeName_beforeMarriage: "",
    wifeName_afterMarriage: "",
    change_wifeName_to_afterMarriage: "",
    wifeReligion: "",
    wifeCaste: "",
    wifeDateofBirth: "",
    wifeMobile: "",
    wifeMarriageAge: "",
    wifeRankorProfession: "",
    wifeCountry: "",
    wifeState: "",
    wifeDistrict: "",
    wifeMandal: "",
    wifeVillageWard: "",
    wifeAddress: "",
    wifeOffice: "",
    wifeRelationship: "",
    wifeFatherName: "",
    wifeMotherName: "",
    isWifeDivorce: "",
    marriageDate: "",
    marriageCountry: "",
    marriageState: "",
    marriageDistrict: "",
    marriageMandal: "",
    marriageVillageWard: "",
    marriageAddress: "",
    marriageType: "",
    regDate: "",
    appNo: "",
    status: "",
    sroOffice: "",
    slotDate: "",
    slotTime: "",
    certificateCopies: "",
    casteType: "",
    loginKey: "",
    loginLabel: "",
    loginName: "",
    loginEmail: "",
    loginMobile: "",
    loginPassword: "",
    loginRPassword: "",
    doc_final_regForm: "",
    doc_final_regForm_upload: "",
    documentNumber: "",
    updatedAt: "",
    isHusbandDivorcee: "",
    isHusbandWidower: "",
    radio_isHusbandDivorcee: "",
    isWifeWidow: "",
    radio_isWifeDivorcee: "",
    isWifeDivorcee: "",
    Year: "",
    paymentType: "PAY AT SRO",
    district: "",
    radio_office: "",
    documents: [],
  }
  const [UserDetails, setUserDetails] = useState<any>(initialUserDetails);
  const [display, setDisplay] = useState(false)
  let initialLoginDetails = useAppSelector((state) => state.login.loginDetails);
  const [LoginDetails, setLoginDetails] = useState(initialLoginDetails);
  const [showInputs, setShowInputs] = useState(false);
  const [view, setView] = useState(false);
  const [payData, setPayData] = useState<any>({})
  const ShowAlert = (type, message, redirect) => { dispatch(PopupAction({ enable: true, type: type, message: message, redirect })); }
  const Loading = (value: boolean) => { dispatch(LoadingAction({ enable: value })); }
  const dispatch = useAppDispatch();
  const [activeTab, setActiveTab] = useState(0)
  const [actTab, setActTab] = useState(0)
  const router = useRouter();
  const [Selectedstatus, setSelectedStatus] = useState("COMPLETED")
  const [search, setsearch] = useState({ year: "", documentNumber: "" })
  const onChangeSearch = (e: any) => {
    setsearch({ ...search, [e.target.name]: e.target.value.toUpperCase() })
  }
  const [tableHeight, settableHeight] = useState(200)
  // const ShiftToLocation = (location: string, query: {}) => {
  //   router.push({
  //     pathname: location,
  //     // query: query,
  //   })
  // }


  useEffect(() => {
    if (!LoginDetails && !(LoginDetails.registrationDetails) && LoginDetails.registrationDetails != "") {
      let rowCount = LoginDetails.registrationDetails.length;
      if (rowCount > 10 && rowCount < 20) {
        settableHeight((250 + (10 * rowCount)))
      }
      else if (rowCount > 20) {
        settableHeight((10 * rowCount) + 150)
      }
      else if (rowCount > 5 && rowCount < 10) {
        settableHeight(350)
      }
      else { settableHeight(300) }
    }
    else { settableHeight(300) }
  }, [LoginDetails.registrationDetails])


  const GetUserRegistrationsList = async (loginData: any) => {
    let regData = await GetUserRegistrations();
    if (regData && regData.status) {
      let data = regData.data;
      if (data!)
        loginData.registrationDetails = data;
    }
    setLoginDetails(loginData);
    Loading(false);
  }

  useEffect(() => {
    Loading(true);
    let data: any = localStorage.getItem("loginDetails");
    if (data) {
      data = JSON.parse(data);
      if (data && data.token && (data.loginType == "SSO" || data.loginType == "sso")) {
        //setLoginDetails(data);
        GetUserRegistrationsList(data);
      } else {
        handleLogOut()
      }
    }
    else {
      handleLogOut()
    }
  }, [])

  const ChangeDateFormat = (Date: string) => {
    if (Date) {
      let Arry = Date.split('-');
      return (Arry[2] + "-" + Arry[1] + "-" + Arry[0])
    }
    return Date;
  }
  const DisplayTable = (key: any, value: any) => {
    return (
      <div className={style.AddressClassForDiv} style={{ display: 'flex' }}>
        <div className={style.KeyContainer} >
          <text className={style.keyText}>{key}</text>
        </div>
        <div>:</div>
        {key == "Address" ?
          <div className={style.ValueContainer}>
            <text className={style.valueText}>{value}</text>
          </div>
          :
          <div className={style.ValueContainer}>
            <text className={style.valueText}>{value}</text>
          </div>
        }
      </div>
    );
  }
  const handlePaymentLinkClick = () => {
    let paymentRedirectUrl = process.env.PAYMENT_GATEWAY_URL + "igrsPayment?paymentData=";
    let paymentLink = document.createElement("a");

    let srNumber = UserDetails.sroNumber;
    if (srNumber != undefined && srNumber != null) {
      let PaymentJSON = {
        "type": "hmr",
        "source": "HMR",
        "deptId": UserDetails.appNo,
        "rmName": LoginDetails.loginName,
        "sroNumber": srNumber,
        "rf": 100
      }
      let encodedData = Buffer.from(JSON.stringify(PaymentJSON), 'utf8').toString('base64')
      paymentLink.href = paymentRedirectUrl + encodedData;
      paymentLink.target = "_blank";
      paymentLink.click();
      setTimeout(function () { paymentLink.remove(); }, 1000);
    }
  };
  const GetTransactionStatus = async (applicationNumber: any) => {
    Loading(true);
    let result = await GetPaymentStatus(applicationNumber, 100);
    Loading(false);
    if (result && result.status) {
      setShowInputs(true);
      setPayData({ ...result.data })
    } else {
      ShowAlert(false, result.message, "");
    }
  }
  const getYearsArray = () => {
    const currentYear = new Date().getFullYear();
    const startYear = 2023;
    const yearsArray = [];
    for (let year = startYear; year <= currentYear; year++) {
      yearsArray.push({ label: year, value: year });
    }
    return yearsArray;
  };

  const GetUserDetailsByDocNo = async () => {
    let docNo: any = search?.documentNumber || '';
    let year: any = search?.year || '';
    Loading(true);
    try {
      let result: any = await GetUserByDocNo(docNo, year);
      Loading(false);
      if (result && result.status) {
        if (Array.isArray(result.data) && result.data.length > 0) {
          setUserDetails(result.data[0]);
          setDisplay(true);
          setView(false)
          setShowInputs(false)
        } else {
          setDisplay(false);
          ShowAlert(false, result && result.data.message, "")
        }
      }
    } catch (error) {
      Loading(false);
      console.error(error);
      setDisplay(false);
      ShowAlert(false, error.message, "");
    }
  };

  const submitCertificateRequest = async () => {
    const reqData = {
      source: LoginDetails.source,
      requestId: LoginDetails.requestId,
      departmentCode: LoginDetails.departmentCode,
      appNumber: UserDetails?.appNo,
      docNumber: UserDetails?.documentNumber,
      docYear: search.year,
      sroNumber: UserDetails.sroNumber,
      departmentTransaction: payData && payData.deptTransID ? payData.deptTransID : '',
      paidAmount: payData && payData.amount ? payData.amount : 0,
    }
    Loading(true);
    const result: any = await createCertificateRequest(reqData)
    Loading(false)
    if (result && result.status) {
      ShowAlert(true, "Certificate Request Sent Successfully", "")
      setView(true);
      setsearch({
        year: "",
        documentNumber: "",
      });
    }
    else {
      ShowAlert(false, "Unable to send request", "")
    }
  }

  const CallGetUserListbySSO = async (status: string) => {
    Loading(true);
    let result = await GetAllCertificateRequestsForSSO(status);
    Loading(false);
    if (result && result.status) {
      if (result.data.length > 0) {
        setUserDetails(result.data.map((o, i) => {
          return { ...o, id: i }
        }));
      } else {
        setUserDetails([]);
      }
    } else {
      setUserDetails([]);
    }
  };

  useEffect(() => {
    CallGetUserListbySSO(Selectedstatus);
  }, [Selectedstatus]);

  const CertificateRequestsdetails = (id: any) => {
    localStorage.setItem("registrationId", id);
    router.push({
      pathname: '/SSOCertificateRequestsDetails',
    })
  }

  return (
    <div>
      <div className={styles.Navbar}>
        <text className={styles.NavbarText}> Welcome : {LoginDetails.loginName.toUpperCase()} </text>
        <text className={styles.NavbarText}> Last Login : {LoginDetails.lastLogin}</text>
        <div style={{ cursor: 'pointer' }} onClick={() => { handleLogOut() }} ><text className={styles.NavbarText}> Logout </text></div>
      </div>
      <div className={styles.Container}>
        <div className={styles.titlecontainer}>
          <text className={styles.TitleText1}> AP Seva Dashboard </text>
          <div className={styles.button} onClick={() => {
            localStorage.removeItem("registrationId");
            localStorage.removeItem("redirectFrom");
            localStorage.removeItem("Prieview");
            router.push("/SSORegistration");
            }}>New Registration</div>
        </div>
        <div className={styles.tabcontainer}>
          {
            ['REGISTERED APPLICATIONS', 'DOWNLOAD CERTIFICATE'].map((o, i) => {
              return (
                <button key={o} className={i === activeTab ? styles.activeButton : styles.deactiveButton} onClick={() => {
                  if (i < 1) {
                  } else {
                  }
                  setActiveTab(i);
                }}>{o}</button>
              )
            })
          }
        </div>
        {activeTab === 1 ?
          <div>
            <div className={styles.tabcontainer} style={{ margin: "2rem" }}>
              {
                ['RAISE A REQUEST', 'RAISED REQUESTS'].map((o, i) => {
                  return (
                    <button key={o} className={i === actTab ? styles.activeButton : styles.deactiveButton} onClick={() => {
                      if (i === 1) {
                        CallGetUserListbySSO(Selectedstatus);
                      } else {

                      }
                      setActTab(i);
                    }}>{o}</button>
                  )
                })
              }
            </div>
            <div style={{ cursor: 'pointer', justifySelf: 'flex-end' ,margin:"-1rem 3rem -1rem 0rem"}}>
              {actTab === 1 ?
                <div className="text-end">
                  <select
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    name="plan" id="plan" value={Selectedstatus} className={styles.DropDown}>
                    <option value="COMPLETED" selected >COMPLETED</option>
                    <option value="PENDING" >PENDING </option>
                    <option value="PROCESSED">PROCESSED</option>
                    <option value="">ALL</option>
                  </select>
                </div>
                : null
              }

            </div>

            <div style={{ justifyContent: 'center' }}>
              {actTab < 1 ?
                <div className={display ? styles.Container : styles.container}>
                  <div className='mx-3 mt-2 d-flex' >
                    <div className='mx-3 my-1'><TableText label='Document Number :' required={false} LeftSpace={false} /></div>
                    <div className='mx-1 my-1' style={{ width: "20%" }}><TableInputText placeholder='Ex: HM/SR**/** ...' required={false} value={search.documentNumber} name="documentNumber" type='text' onChange={onChangeSearch} /></div>
                    <div className='mx-4 my-1'><TableText label='Registered Year :' required={false} LeftSpace={false} /></div>
                    <div className='mx-1 my-1' style={{ width: "15%" }}><TableDropdown required={true} options={getYearsArray()} name='year' value={search.year} onChange={onChangeSearch} /></div>
                    <div className='mx-4' ><button style={{ width: "100%" }} className={styles.searchbutton} onClick={GetUserDetailsByDocNo}>Search</button></div>
                  </div>
                  {display &&
                    <div>
                      {!view &&
                        <div>
                          <div style={{ width: '100%' }}>
                            <div style={{ display: 'flex' }}>
                              <div className={style.ListComponentContainer}>
                                <text className={style.TitleText}>Slot Details</text>
                                {DisplayTable("Application Number", UserDetails?.appNo)}
                                {DisplayTable("Date of Registration", UserDetails?.regDate)}
                                {UserDetails?.villageScretariatName != null && UserDetails.villageScretariatName != undefined && UserDetails?.villageScretariatName != "" ? DisplayTable("Village Secretariat Name", UserDetails?.villageScretariatName) : null}
                                {DisplayTable("SRO Office", UserDetails?.sroOffice)}
                                {DisplayTable("Slot Date", ChangeDateFormat(UserDetails?.slotDate))}
                                {DisplayTable("Slot Time", UserDetails?.slotTime)}
                                {DisplayTable("Number of Certificate Copies", UserDetails?.certificateCopies)}
                              </div>
                              <div className={style.ListComponentContainer}>
                                <text className={style.TitleText}>Marriage Details</text>
                                {DisplayTable("Date of Marriage", ChangeDateFormat(UserDetails?.marriageDate))}
                                {DisplayTable("Husband Age at the time of Marriage", UserDetails?.husbandMarriageAge)}
                                {DisplayTable("Wife Age at the time of Marriage", UserDetails?.wifeMarriageAge)}
                                {DisplayTable("Place of Marriage", UserDetails?.marriageAddress)}
                                {DisplayTable("Status", UserDetails?.status)}
                              </div>
                            </div>
                            <div style={{ display: 'flex' }}>
                              <div className={style.ListComponentContainer}>
                                <text className={style.TitleText}>Husband Details</text>
                                {DisplayTable(" Name", UserDetails?.husbandName)}
                                {DisplayTable(" Religion", UserDetails?.husbandReligion)}
                                {DisplayTable(" Caste", UserDetails?.husbandOtherCaste ? UserDetails?.husbandOtherCaste : UserDetails?.husbandCaste)}
                                {DisplayTable(" Date of Birth", ChangeDateFormat(UserDetails?.husbandDateofBirth))}
                                {DisplayTable(" Mobile Number", UserDetails?.husbandMobile)}
                                {DisplayTable(" Country", UserDetails?.husbandCountry)}
                                {DisplayTable(" State", UserDetails?.husbandState)}
                                {DisplayTable("Address", UserDetails?.husbandAddress)}
                                {DisplayTable("Relationship", UserDetails?.husbandRelationship)}
                                {DisplayTable(" Father Name", UserDetails?.husbandFatherName)}
                                {DisplayTable(" Mother Name", UserDetails?.husbandMotherName)}
                                {DisplayTable(" Is Husband a Widower", UserDetails?.isHusbandWidower)}
                                {DisplayTable(" Is Husband a Divorcee", UserDetails?.radio_isHusbandDivorcee)}
                                {UserDetails?.husbandAadhar === null || UserDetails?.husbandAadhar === undefined || UserDetails?.husbandAadhar === "" ? DisplayTable(" Passport Number", UserDetails?.husbandPassport) : DisplayTable("Aadhaar Number", UserDetails?.husbandAadhar)}
                                {UserDetails?.husbandPassport != null && UserDetails?.husbandPassport != undefined && UserDetails?.husbandDOI != "" ? DisplayTable(" Passport Date of Issue", UserDetails?.husbandDOI) : null}
                                {UserDetails?.husbandPassport != null && UserDetails?.husbandPassport != undefined && UserDetails?.husbandPassport != "" ? DisplayTable(" Passport Date of Expiry", UserDetails?.husbandDOE) : null}
                                {UserDetails?.radio_isHusbandDivorcee == "YES" && DisplayTable(" Husband Divorcee Date", ChangeDateFormat(UserDetails?.isHusbandDivorcee))}
                              </div>

                              <div className={style.ListComponentContainer}>
                                <text className={style.TitleText}>Wife Details</text>
                                {DisplayTable("Name Before Marriage", UserDetails?.wifeName_beforeMarriage)}
                                {DisplayTable("Name After Marriage", UserDetails?.wifeName_afterMarriage == '' ? ' N/A ' : UserDetails?.wifeName_afterMarriage)}
                                {DisplayTable("Request to Change Name", UserDetails?.change_wifeName_to_afterMarriage)}
                                {DisplayTable("Religion", UserDetails?.wifeReligion)}
                                {DisplayTable("Caste", UserDetails?.wifeOtherCaste ? UserDetails?.wifeOtherCaste : UserDetails?.wifeCaste)}
                                {DisplayTable("Date of Birth", ChangeDateFormat(UserDetails?.wifeDateofBirth))}
                                {DisplayTable("Mobile Number", UserDetails?.wifeMobile)}
                                {DisplayTable("Country", UserDetails?.wifeCountry)}
                                {DisplayTable("State", UserDetails?.wifeState)}
                                {DisplayTable("Address", UserDetails?.wifeAddress)}
                                {DisplayTable("Relationship", UserDetails?.wifeRelationship)}
                                {DisplayTable("Father Name", UserDetails?.wifeFatherName)}
                                {DisplayTable("Mother Name", UserDetails?.wifeMotherName)}
                                {DisplayTable("Is Wife a Widow", UserDetails?.isWifeWidow)}
                                {DisplayTable("Is Wife a Divorcee", UserDetails?.radio_isWifeDivorcee)}
                                {UserDetails?.wifeAadhar === null || UserDetails?.wifeAadhar === undefined || UserDetails?.wifeAadhar === "" ? DisplayTable(" Passport Number", UserDetails?.wifePassport) : DisplayTable(" Aadhaar Number", UserDetails?.wifeAadhar)}
                                {UserDetails?.wifePassport != null && UserDetails?.wifePassport != undefined && UserDetails?.wifePassport != "" ? DisplayTable(" Passport Date of Issue", UserDetails?.wifeDOI) : null}
                                {UserDetails?.wifePassport != null && UserDetails?.wifePassport != undefined && UserDetails?.wifePassport != "" ? DisplayTable(" Passport Date of Expiry", UserDetails?.wifeDOE) : null}
                                {UserDetails?.radio_isWifeDivorcee == "YES" && DisplayTable("Wife Divorcee Date", ChangeDateFormat(UserDetails?.isWifeDivorcee))}
                              </div>
                            </div>
                          </div>

                          <div>
                            <div className='mx-3'>
                              <div>
                                <text className={styles.UploadText}>Amount Payable: </text>
                                <text className={styles.UploadText} style={{ color: 'red', fontWeight: 'bold', justifyContent: "center" }} >{" Rs 100/-"}</text>
                              </div>
                              <div>
                                <text className={styles.UploadText} style={{ fontWeight: 'bold' }}>Payment Link : </text>
                                <a href='javascript:void(0)' onClick={() => handlePaymentLinkClick()} rel="noreferrer" className={styles.UploadText} >Click here to Pay</a>
                                <div>
                                  <text className={styles.UploadText} style={{ fontWeight: 'bold' }}>Payment Guidelines: </text>
                                  <a href='https://drive.google.com/file/d/1tUGzbUDrErXABENRBSQXlzrYgTj0v10D/view?usp=sharing' target="_blank" rel="noreferrer" className={styles.UploadText} >View Payment Instructions</a>
                                </div>
                                <div>
                                  <text className={styles.UploadText} style={{ color: 'red' }} >*Please make the payment by clicking on the payment link and click on verify payment status to proceed.</text>
                                </div>
                                <div>
                                  <text className={styles.UploadText} style={{ fontWeight: 'bold' }}>Verify Payment Status: </text>
                                  <a href='javascript:void(0)' onClick={(e) => { GetTransactionStatus(UserDetails.appNo) }} rel="noreferrer" >Click Here to Verify</a>
                                  {showInputs && (
                                    <div>
                                      <Row style={{ margin: '1rem' }} >
                                        <Col>
                                          <div style={{ position: 'relative' }}>
                                            <TableText label="Dept. Transaction ID:" required={false} LeftSpace={false} />
                                            <div style={{ position: 'absolute', top: '0rem', left: '170px', width: '60%' }}>
                                              <TableInputText disabled={true} type='text' placeholder="" required={true} name={'deptTransID'} value={payData.deptTransID ? payData.deptTransID : ''} onChange={() => { }} />
                                            </div>
                                          </div>
                                        </Col>
                                        <Col>
                                          <div style={{ position: 'relative' }}>
                                            <TableText label="Amount Paid(₹):" required={false} LeftSpace={false} />
                                            <div style={{ position: 'absolute', top: '0rem', left: '140px', width: '50%' }}>
                                              <TableInputText disabled={true} type='number' placeholder="" required={true} name={'amount'} value={payData.amount ? `${payData.amount}.00` : ''} onChange={() => { }} />
                                            </div>
                                          </div>
                                        </Col>
                                      </Row>
                                      <div style={{ display: 'flex', justifyContent: 'center', margin: "2rem" }}>
                                        <button className={styles.button} onClick={submitCertificateRequest}>Submit</button>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      }
                      {view &&
                      <div className={styles.container}/>
                      }
                    </div>
                  }
                </div> :
                <div style={{ height: "400px", margin: '2rem 3rem 0rem 3rem', }}>
                  <DataGrid
                    className={styles.GridTable}
                    onRowClick={(e) => { CertificateRequestsdetails(e.row._id) }}
                    rows={UserDetails}
                    columns={certificatecolumns}
                    pageSize={50}
                    rowsPerPageOptions={[20]}
                    sx={datagridSx}
                    rowHeight={35}
                  />
                </div>
              }
            </div>
          </div>
          :
          <div>
            <div className={styles.Container}>
              <div style={{ height: '400px', margin: '4px', marginTop: '0', marginBottom: '6rem', display: 'flex', justifyContent: 'center', cursor: 'pointer' }}>
                {LoginDetails.registrationDetails && LoginDetails.registrationDetails.length ?
                  <DataGrid
                    className={styles.GridTable}
                    onRowClick={(e) => {
                      localStorage.setItem("registrationId", e.row.id);
                      if (e.row.status == "DRAFT") {
                        localStorage.setItem("redirectFrom", "SSORegistration");
                        //localStorage.setItem("isFromDashboard", "Yes");
                        router.push("/SSORegistration")
                      }
                      else
                        router.push("/ViewUserDetails")
                    }}
                    rows={LoginDetails.registrationDetails}
                    columns={columns}
                    pageSize={20}
                    rowsPerPageOptions={[20]}
                    sx={datagridSx}
                    rowHeight={35}
                  /> :
                  <DataGrid
                    className={styles.GridTable}
                    rows={LoginDetails}
                    columns={columns}
                    pageSize={20}
                    rowsPerPageOptions={[20]}
                    sx={datagridSx}
                    rowHeight={35}
                  />
                }
              </div>
            </div>
            {/* <pre>{JSON.stringify(LoginDetails, null, 2)}</pre> */}
          </div>
        }
      </div>
    </div>
  )
}
export default SSODashboard